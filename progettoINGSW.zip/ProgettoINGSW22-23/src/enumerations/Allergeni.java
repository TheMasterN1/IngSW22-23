package enumerations;

public enum Allergeni {
	Glutine,Sesamo,Crostacei,Pesce,Arachidi,Uova,Soia,Latte,Sedano,Senape,Lupini,Molluschi
}
