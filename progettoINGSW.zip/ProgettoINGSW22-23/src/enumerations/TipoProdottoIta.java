package enumerations;

public enum TipoProdottoIta {
	Primo, Secondo, Contorno, Dolce, Antipasto, Bibita
}
