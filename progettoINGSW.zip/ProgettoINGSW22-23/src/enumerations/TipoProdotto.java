package enumerations;

public enum TipoProdotto {
	Primo, Secondo, Contorno, Dolce, Antipasto, Bibita
}
