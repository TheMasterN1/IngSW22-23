package controllers;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;

import MariaDbDAO.IngredienteDAO;
import MariaDbDAO.ProdottoDAO;
import application.CustomButton;
import application.Translator;
import dto.ProdottoEng;
import dto.ProdottoIta;
import enumerations.TipoProdottoEng;
import enumerations.TipoProdottoIta;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class MenuController extends ExtendedController {
	@FXML private Pane pane;
	@FXML private CustomButton addButton;
	@FXML private CustomButton button_language;
	@FXML private TextField txt_cerca_prodotto;
	@FXML private TextField txt_nome_prodotto = new TextField();
	@FXML private TextArea txt_descrizione_prodotto;
	@FXML private TextArea txt_allergeni;
	@FXML private TextField txt_costo;
	@FXML private FlowPane products_box;
	@FXML private ComboBox<Object> comboBox_cerca_prod = new ComboBox<>();
	@FXML private ComboBox<TipoProdottoIta> comboBox_categoria = new ComboBox<>();
	@FXML private Spinner<String> spinner_qta = new Spinner<>();
	
	private ImageView flag = new ImageView(new Image(getClass().getResourceAsStream("../files/italy.png")));
	private ImageView flag2 = new ImageView(new Image(getClass().getResourceAsStream("../files/united-kingdom.png")));
	private boolean italian = true;
	private ArrayList<ProdottoIta> prodottiIta = new ArrayList<>();
	private ArrayList<ProdottoEng> prodottiEng = new ArrayList<>();
	private Thread thread;
	public static ProdottoIta prodotto = new ProdottoIta();
	ProdottoDAO foodStorageDAO = new ProdottoDAO();
	IngredienteDAO ingredienteDAO = new IngredienteDAO();
	
	@FXML
	public void initialize() {
		try {
			thread = new Thread(()-> {
				try {
					ResultSet rs2 = foodStorageDAO.ListaProdotti();
					while(rs2.next()) {
						prodottiEng.add(new ProdottoEng(rs2.getFloat(1), Translator.Translate("","en",rs2.getString(2)), Translator.Translate("","en",rs2.getString(6)),
								Translator.Translate("","en",rs2.getString(3)), rs2.getInt(4), TipoProdottoIta.valueOf(rs2.getString(5))));
					}
				} catch (Exception e) {e.printStackTrace();}
			});
			thread.start();
			ResultSet rs = foodStorageDAO.ListaProdotti();
			while(rs.next()) {
				prodottiIta.add(new ProdottoIta(rs.getFloat(1), rs.getString(2), rs.getString(6), rs.getString(3), rs.getInt(4), TipoProdottoIta.valueOf(rs.getString(5))));
			}
		} catch (Exception e) {e.printStackTrace();}
		
		buildData("", TipoProdottoIta.Primo);
		setPane(pane);
		
		flag.setPreserveRatio(true); flag2.setPreserveRatio(true); 
		flag.setFitHeight(50); flag2.setFitHeight(50);
		flag.setFitWidth(50); flag2.setFitWidth(50);
		
		comboBox_cerca_prod.setItems(FXCollections.observableArrayList(italian ? TipoProdottoIta.values() : TipoProdottoEng.values()));
		comboBox_cerca_prod.getSelectionModel().select(0);;
		comboBox_categoria.setItems(FXCollections.observableArrayList(TipoProdottoIta.values()));
		
		button_language.setGraphic(flag);
		button_language.setOnMouseClicked(arg0 -> {
			italian = !italian;
			button_language.setGraphic(italian ? flag : flag2);
			comboBox_cerca_prod.setItems(FXCollections.observableArrayList(italian ? TipoProdottoIta.values() : TipoProdottoEng.values()));
			comboBox_cerca_prod.getSelectionModel().select(0);;
		});
		
		if(!isAdmin)
			pane.getChildren().remove(addButton);
		
		txt_cerca_prodotto.textProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> arg0, String arg1, String arg2) {
				if (italian)
					buildData(arg2, comboBox_cerca_prod.getSelectionModel().getSelectedItem());
				else 
					buildDataEng(arg2, comboBox_cerca_prod.getSelectionModel().getSelectedItem());
			}
		});
		
		comboBox_cerca_prod.valueProperty().addListener(new ChangeListener<Object>() {
			@Override
			public void changed(ObservableValue<? extends Object> arg0, Object arg1, Object arg2) {
				if (italian)
					buildData(txt_cerca_prodotto.getText(), arg2);
				else 
					buildDataEng(txt_cerca_prodotto.getText(), arg2);
			}
		});
	}
	
	private void setProdotto(String id) throws Exception {
		ResultSet rs = foodStorageDAO.ListaProdotti_specifica(id); 
		while (rs.next()) {
			prodotto.setName(rs.getString(2));
			prodotto.setCosto(rs.getFloat(1));
			prodotto.setDescrizione(rs.getString(3));
			prodotto.setProdottoID(Integer.valueOf(rs.getString(4)));
			prodotto.setCategoria(TipoProdottoIta.valueOf(rs.getString(5)));
			prodotto.setAllergeni(rs.getString(6));
		}
	}

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "HomePageScene");
	}

	@FXML
	public void addDish(ActionEvent event) throws IOException, InterruptedException {
		changeSceneNotFullscreen(event, "AddDishMenuScene");
	}

	@FXML
	public void removeProduct(Event arg0) throws IOException, InterruptedException {
		if (alertClass.alertlog("Rimuovere il prodotto "+prodotto.getName()+" ?").showAndWait()
				.get() == ButtonType.OK) {
			try {
				foodStorageDAO.RimuoviProdotto(prodotto.getProdottoID());
				prodotto = new ProdottoIta();
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
	}

	@SuppressWarnings("static-access")
	public void buildData(String searched, Object type) {
		try {
			products_box.getChildren().removeAll(products_box.getChildren());
			for(ProdottoIta prod : prodottiIta) {
				TipoProdottoIta tipo = TipoProdottoIta.valueOf(type.toString());
				if((!searched.equals("") && !prod.getName().contains(searched)) || !(prod.getCategoria()==tipo)) {
					continue;
				}
				AnchorPane item = new AnchorPane();
				item.setPrefSize(400, 400);
				
				Text costoProdotto = new Text(prod.getCosto()+"�");
				Text nomeProdotto = new Text(prod.getName());
				Separator separator = new Separator(Orientation.HORIZONTAL);
				Text descrizioneProdotto = new Text(prod.getDescrizione());
				Separator separator2 = new Separator(Orientation.HORIZONTAL);
				item.setId(String.valueOf(prod.getProdottoID()));
				Text ricettaProdotto = new Text("RICETTA:\n");
				Separator separator3 = new Separator(Orientation.HORIZONTAL);
				Text categoriaProdotto = new Text(prod.getCategoria().toString());
				Text allergeniProdotto = new Text("*pu� contenere tracce di: "+ prod.getAllergeni());
				
				CustomButton removebutton = new CustomButton(); removebutton.setId("removeButton"); removebutton.setPrefSize(50, 50);
				CustomButton editbutton = new CustomButton(); editbutton.setId("editButton"); editbutton.setPrefSize(50, 50);
				
				nomeProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 30)); nomeProdotto.setFill(Color.WHITE);
				costoProdotto.setFont(Font.font("MontSerrat",FontWeight.NORMAL, 20)); costoProdotto.setFill(Color.WHITE);
				descrizioneProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 15)); descrizioneProdotto.setFill(Color.WHITE);;
				ricettaProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 15)); ricettaProdotto.setFill(Color.WHITE);
				allergeniProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 12)); allergeniProdotto.setFill(Color.WHITE);
				categoriaProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 20)); categoriaProdotto.setFill(Color.WHITE);
				
				ResultSet rs2 = foodStorageDAO.getRicetta(item.getId());
				
				while(rs2.next()) {
					ResultSet rs3 = ingredienteDAO.ListaIngredientiSpecificaID(rs2.getString(2));
					rs3.next();
					ricettaProdotto.setText(ricettaProdotto.getText() + " " + rs2.getString(3) + " " + rs3.getString(1) + ";\n");
				}
				
				removebutton.setOnMouseClicked(new EventHandler<Event>() {
					@Override
					public void handle(Event arg0) {
						try {
							setProdotto(item.getId());
							removeProduct(arg0);
							buildData(searched, comboBox_cerca_prod.getSelectionModel().getSelectedItem());
						} catch (Exception e) {e.printStackTrace();}
					}
				});
				
				editbutton.setOnMouseClicked(new EventHandler<Event>() {
					@Override
					public void handle(Event arg0) {
						try {
							setProdotto(item.getId());
							changeSceneNotFullscreen(arg0, "AddDishMenuScene");} catch (IOException e1) {}
						catch (Exception e) {e.printStackTrace();}
						buildData(searched, comboBox_cerca_prod.getSelectionModel().getSelectedItem());
					}
				});

				item.getChildren().addAll(nomeProdotto, costoProdotto, descrizioneProdotto, ricettaProdotto, allergeniProdotto, categoriaProdotto, removebutton, editbutton,
						separator, separator2, separator3);
				item.setTopAnchor(nomeProdotto, 10.0);
				item.setTopAnchor(costoProdotto, 20.0);  item.setRightAnchor(costoProdotto, 0.0);
				item.setTopAnchor(separator, 41.0); item.setLeftAnchor(separator, 0.0); item.setRightAnchor(separator, 0.0); 
				item.setTopAnchor(categoriaProdotto, 42.0);
				item.setTopAnchor(separator2, 63.0); item.setLeftAnchor(separator2, 0.0); item.setRightAnchor(separator2, 0.0); 
				item.setTopAnchor(descrizioneProdotto, 64.0); 
				item.setTopAnchor(separator3, 125.0); item.setLeftAnchor(separator3, 0.0); item.setRightAnchor(separator3, 0.0); 
				item.setTopAnchor(ricettaProdotto, 126.0); 
				item.setBottomAnchor(allergeniProdotto, 100.0);
				item.setBottomAnchor(removebutton, 20.0); item.setLeftAnchor(removebutton, 20.0);
				item.setBottomAnchor(editbutton, 20.0); item.setRightAnchor(editbutton, 20.0);
				
				if (!isAdmin) {
					item.getChildren().removeAll(removebutton, editbutton);
				}
				products_box.getChildren().add(item);
			}
			
			products_box.setVgap(20);
			products_box.setHgap(20);
			products_box.setPadding(new Insets(20));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("static-access")
	public void buildDataEng(String searched, Object type) {
		try {
			thread.join();
			products_box.getChildren().removeAll(products_box.getChildren());
			for(ProdottoEng prod : prodottiEng) {
				TipoProdottoEng tipo = TipoProdottoEng.valueOf(type.toString());
				if((!searched.equals("") && !prod.getName().contains(searched)) || !(prod.getCategoria()==tipo)) {
					continue;
				}
				AnchorPane item = new AnchorPane();
				item.setPrefSize(400, 400);
				
				Text costoProdotto = new Text(prod.getCosto()+"�");
				Text nomeProdotto = new Text(prod.getName());
				Separator separator = new Separator(Orientation.HORIZONTAL);
				Text descrizioneProdotto = new Text(prod.getDescrizione());
				Separator separator2 = new Separator(Orientation.HORIZONTAL);
				item.setId(String.valueOf(prod.getProdottoID()));
				Text ricettaProdotto = new Text("RECEIPT:\n");
				Separator separator3 = new Separator(Orientation.HORIZONTAL);
				Text categoriaProdotto = new Text(prod.getCategoria().toString());
				Text allergeniProdotto = new Text("*may contains traces of:"+ prod.getAllergeni());
				
				CustomButton removebutton = new CustomButton(); removebutton.setId("removeButton"); removebutton.setPrefSize(50, 50);
				CustomButton editbutton = new CustomButton(); editbutton.setId("editButton"); editbutton.setPrefSize(50, 50);
				
				nomeProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 30)); nomeProdotto.setFill(Color.WHITE);
				costoProdotto.setFont(Font.font("MontSerrat",FontWeight.NORMAL, 20)); costoProdotto.setFill(Color.WHITE);
				descrizioneProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 15)); descrizioneProdotto.setFill(Color.WHITE);;
				ricettaProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 15)); ricettaProdotto.setFill(Color.WHITE);
				allergeniProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 12)); allergeniProdotto.setFill(Color.WHITE);
				categoriaProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 20)); categoriaProdotto.setFill(Color.WHITE);
				
				ResultSet rs2 = foodStorageDAO.getRicetta(item.getId());
				
				while(rs2.next()) {
					ResultSet rs3 = ingredienteDAO.ListaIngredientiSpecificaID(rs2.getString(2));
					rs3.next();
					ricettaProdotto.setText(ricettaProdotto.getText() + " " + rs2.getString(3) + " " + Translator.Translate("", "en", rs3.getString(1)) + ";\n");
				}
				
				removebutton.setOnMouseClicked(new EventHandler<Event>() {
					@Override
					public void handle(Event arg0) {
						try {
							setProdotto(item.getId());
							removeProduct(arg0);
							buildDataEng(searched, comboBox_cerca_prod.getSelectionModel().getSelectedItem());
						} catch (Exception e) {e.printStackTrace();}
					}
				});
				
				editbutton.setOnMouseClicked(new EventHandler<Event>() {
					@Override
					public void handle(Event arg0) {
						try {
							setProdotto(item.getId());
							changeSceneNotFullscreen(arg0, "AddDishMenuScene");
							buildDataEng(searched, comboBox_cerca_prod.getSelectionModel().getSelectedItem());
						} catch (Exception e) {e.printStackTrace();}
					}
				});

				item.getChildren().addAll(nomeProdotto, costoProdotto, descrizioneProdotto, ricettaProdotto, allergeniProdotto, categoriaProdotto, removebutton, editbutton,
						separator, separator2, separator3);
				item.setTopAnchor(nomeProdotto, 10.0);
				item.setTopAnchor(costoProdotto, 20.0);  item.setRightAnchor(costoProdotto, 0.0);
				item.setTopAnchor(separator, 41.0); item.setLeftAnchor(separator, 0.0); item.setRightAnchor(separator, 0.0); 
				item.setTopAnchor(categoriaProdotto, 42.0);
				item.setTopAnchor(separator2, 63.0); item.setLeftAnchor(separator2, 0.0); item.setRightAnchor(separator2, 0.0); 
				item.setTopAnchor(descrizioneProdotto, 64.0); 
				item.setTopAnchor(separator3, 125.0); item.setLeftAnchor(separator3, 0.0); item.setRightAnchor(separator3, 0.0); 
				item.setTopAnchor(ricettaProdotto, 126.0); 
				item.setBottomAnchor(allergeniProdotto, 100.0);
				item.setBottomAnchor(removebutton, 20.0); item.setLeftAnchor(removebutton, 20.0);
				item.setBottomAnchor(editbutton, 20.0); item.setRightAnchor(editbutton, 20.0);
				
				if (!isAdmin) {
					item.getChildren().removeAll(removebutton, editbutton);
				}
				products_box.getChildren().add(item);
			}
			
			products_box.setVgap(20);
			products_box.setHgap(20);
			products_box.setPadding(new Insets(20));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
