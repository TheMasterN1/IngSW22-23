package controllers;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import MariaDbDAO.ProdottoDAO;
import application.CustomButton;
import dto.Prodotto;
import enumerations.TipoProdotto;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.util.Callback;

public class MenuController extends ExtendedController {
	@FXML private Pane pane;
	@FXML private CustomButton addButton;
	@FXML private TableView<ObservableList<String>> tableMagazzino = new TableView<ObservableList<String>>();
	@FXML private TextField txt_cerca_prodotto;
	@FXML private TextField txt_nome_prodotto = new TextField();
	@FXML private TextArea txt_descrizione_prodotto;
	@FXML private TextArea txt_allergeni;
	@FXML private TextField txt_costo;
	@FXML private ComboBox<TipoProdotto> comboBox_cerca_prod = new ComboBox<>();
	@FXML private Spinner<String> spinner_qta = new Spinner<>();
	@FXML private ComboBox<TipoProdotto> comboBox_categoria = new ComboBox<>();

	public static Prodotto prodotto = new Prodotto();
	ProdottoDAO foodStorageDAO = new ProdottoDAO();
	
	@FXML
	public void initialize() {
		buildData();
		setPane(pane);
		
		if(!isAdmin)
			pane.getChildren().remove(addButton);
		
		tableMagazzino.setRowFactory(tv->{
			TableRow<ObservableList<String>> row = new TableRow<>();
			row.setOnMouseClicked(event -> {
				ContextMenu menu = new ContextMenu();
				MenuItem remove = new MenuItem("Rimuovi");
				MenuItem modify = new MenuItem("Modifica");
				menu.getItems().addAll(remove, modify);
				
				try {
					prodotto.setCosto(Float.parseFloat(row.getItem().get(0).toString()));
					prodotto.setName(row.getItem().get(1).toString());
					prodotto.setDescrizione(row.getItem().get(2).toString());
					prodotto.setProdottoID(Integer.parseInt(row.getItem().get(3).toString()));
					prodotto.setQuantita(Integer.parseInt(row.getItem().get(4).toString()));
					prodotto.setCategoria(row.getItem().get(5).toString());
					prodotto.setAllergeni(row.getItem().get(6).toString());
				} catch(Exception e) {}
		
				remove.setOnAction(e -> {
					try {removeProduct(e);} catch (IOException e1) {}
					catch (InterruptedException e1) {}
				});

				modify.setOnAction(e -> {
					try {changeSceneNotFullscreen(event, "AddDishMenuScene");} catch (IOException e1) {}
					catch (InterruptedException e1) {}
				});

				tableMagazzino.setContextMenu(menu);
			});
			prodotto.setName(null);
			prodotto.setDescrizione(null);
			prodotto.setCosto(0);
			prodotto.setProdottoID(0);
			prodotto.setQuantita(0);
			prodotto.setCategoria(null);
			prodotto.setAllergeni(null);
			return row;
		});
	}

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "HomePageScene");
	}

	@FXML
	public void addDish(ActionEvent event) throws IOException, InterruptedException {
		changeSceneNotFullscreen(event, "AddDishMenuScene");
	}

	@FXML
	public void removeProduct(ActionEvent event) throws IOException, InterruptedException {
		if (alertClass.alertlog("Rimuovere il prodotto "+prodotto.getName()+" ?").showAndWait()
				.get() == ButtonType.OK) {
			try {
				foodStorageDAO.RimuoviProdotto(prodotto.getProdottoID());
				rebuildData();
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
	}

	private void rebuildData(){
		FXCollections.observableArrayList();
		try {
			ResultSet rs = foodStorageDAO.ListaProdotti();
			ObservableList<ObservableList<String>> data = FXCollections.observableArrayList();

			tableMagazzino.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);
				
			while (rs.next()) {
				//Iterate Row
				ObservableList<String> row = FXCollections.observableArrayList();
				for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
					//Iterate Column
					row.add(rs.getString(i));
				}
				data.add(row);

			}

			//FINALLY ADDED TO TableView
			tableMagazzino.setItems(data);
		} catch (SQLException ex) {
			throw new RuntimeException(ex);
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	@SuppressWarnings("unchecked")
	@FXML
	public void buildData() {

		comboBox_cerca_prod.setItems(FXCollections.observableArrayList(TipoProdotto.values()));
		comboBox_categoria.setItems(FXCollections.observableArrayList(TipoProdotto.values()));

		try {
			ResultSet rs = foodStorageDAO.ListaProdotti();
			ObservableList<ObservableList<String>> data = FXCollections.observableArrayList();

			tableMagazzino.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);
			for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {

				final int j = i;
				TableColumn<ObservableList<String>, String> col = new TableColumn<>(rs.getMetaData().getColumnName(i + 1));
				col.setCellValueFactory((Callback<TableColumn.CellDataFeatures<ObservableList<String>, String>, ObservableValue<String>>) param -> {
					if (param.getValue().get(j) != null) {
						return new SimpleStringProperty(param.getValue().get(j).toString());
					} else {
						return null;
					}
				});
				tableMagazzino.getColumns().addAll(col);
			}

			while (rs.next()) {
				//Iterate Row
				ObservableList<String> row = FXCollections.observableArrayList();
				for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
					//Iterate Column
					row.add(rs.getString(i));
				}
				data.add(row);
			}

			//FINALLY ADDED TO TableView
			tableMagazzino.setItems(data);
			
			FilteredList<ObservableList<String>> filteredData = new FilteredList<>(data, b->true);

			txt_cerca_prodotto.textProperty().addListener((observable, oldValue, newValue ) ->{
				filteredData.setPredicate(dato->{
					if(newValue == null || newValue.isEmpty()){
						return true;
					}

					String lowerCaseFilter =  newValue.toLowerCase();

					if(dato.get(1).toString().toLowerCase().indexOf(lowerCaseFilter)!=-1){
						return true;
					}  else{
						return false;
					}
				});
			});

			SortedList<ObservableList<String>> sortedList = new SortedList<>(filteredData);
			sortedList.comparatorProperty().bind(tableMagazzino.comparatorProperty());
			tableMagazzino.setItems(sortedList);
		} catch (SQLException ex) {
			throw new RuntimeException(ex);
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}
}
