package controllers;

import MariaDbDAO.IngredienteDAO;
import application.CustomButton;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import java.io.IOException;

public class AddFoodStorageController extends ExtendedController {

	IngredienteDAO ingredienteDAO = new IngredienteDAO();
	
	@FXML private Pane pane;
	@FXML private CustomButton addButton;
	@FXML private TableView<ObservableList<String>> tableMagazzino = new TableView<ObservableList<String>>();
	@FXML private Spinner<Integer> spinner_qta = new Spinner<>();
	@FXML private  TextField txt_nome_prodotto = new TextField();
	@FXML private TextField txt_cerca_prodotto;
	@FXML private ComboBox<String> comboBox_cerca_prod;

	@FXML
	public void cancelAdd(ActionEvent event) throws IOException, InterruptedException {
		closeAndReEnable(event);
	}
	
	@FXML
	private void addQtIngredient(ActionEvent event) throws IOException, InterruptedException  {
		alertClass.notifyAddQt();
		if(txt_nome_prodotto.getText().length()>0 && Integer.parseInt(spinner_qta.getValue().toString())>0){
			try {
				if(FoodStorageController.ingrediente.getIngredienteId()>0){
					ingredienteDAO.UpdateIngredienti(FoodStorageController.ingrediente.getIngredienteId(),txt_nome_prodotto.getText().toString(), Integer.parseInt(spinner_qta.getValue().toString()));
				}
				else {
					ingredienteDAO.InserisciIngrediente(txt_nome_prodotto.getText().toString(), Integer.parseInt(spinner_qta.getValue().toString()));
				}
				closeAndReEnable(event);
				} catch (Exception e) {
					throw new RuntimeException(e);
			}
		}
		else{
			Alert a = new Alert(Alert.AlertType.ERROR);
			a.setTitle("ERRORE");
			a.setContentText("errore, campi mancanti o sbagliati");
			a.show();
		}
	}

	@FXML
	void initialize() {
		if(!isAdmin)
			pane.getChildren().remove(addButton);

		if(FoodStorageController.ingrediente.getIngredienteId()!=0){
			txt_nome_prodotto.setText(FoodStorageController.ingrediente.getNome());
			spinner_qta.getValueFactory().setValue(FoodStorageController.ingrediente.getQuantita());
		}
	}
}