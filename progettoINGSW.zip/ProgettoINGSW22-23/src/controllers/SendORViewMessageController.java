package controllers;

import application.CustomButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.ResultSet;

import MariaDbDAO.NotificheDAO;
import MariaDbDAO.UtenteDAO;

public class SendORViewMessageController extends ExtendedController {
	
	@FXML private Pane pane;
	@FXML private CustomButton confirmButton;
	@FXML private TextField txt_oggetto;
	@FXML private TextArea txt_testo_messaggio;
	int idNotifiche;
	int idUtente;
	
	NotificheDAO notificheDAO = new NotificheDAO();
	UtenteDAO utenteDAO = new UtenteDAO();

	@FXML
	public void initialize() {
		try {
			if (!isAdmin)
				pane.getChildren().remove(confirmButton);

			if (NotificationController.notifiche != null) {
				txt_oggetto.setText(NotificationController.notifiche.getOggetto());
				txt_testo_messaggio.setText(NotificationController.notifiche.getTesto());
				idNotifiche = NotificationController.notifiche.getIDnotifiche();
				idUtente = NotificationController.notifiche.getIdUtente();
				notificheDAO.UpdateVisualizzazione(idUtente, idNotifiche);
			} else {
				idNotifiche = 0;
				idUtente = 0;
			}
		}catch (Exception e){
			e.printStackTrace();
		}
	}

	@FXML
	public void send(ActionEvent event) throws IOException, InterruptedException {
		close(event);
		try {
			if (txt_oggetto != null && txt_testo_messaggio != null) {
				if (txt_oggetto.getText().length() == 0) {
					txt_oggetto.setText("<NO OGGETTO>");
				}
				if (txt_testo_messaggio.getText().length() == 0) {
					txt_testo_messaggio.setText("<TESTO MESSAGGIO VUOTO>");
				}

				if( idNotifiche>0 && idUtente>0) {
					notificheDAO.InserisciMessaggio(idNotifiche, txt_oggetto.getText(), txt_testo_messaggio.getText(), idUtente);
				}
				else{
					notificheDAO.InserisciMessaggio(0, txt_oggetto.getText(), txt_testo_messaggio.getText(), idUtente);
				}
				ResultSet idNotifica = notificheDAO.MaxIDMessaggi();
				ResultSet resultSetListaUtenti = utenteDAO.IDListaUtenti();
				while(idNotifica.next()) {
					resultSetListaUtenti.beforeFirst();
					while (resultSetListaUtenti.next()) {
						notificheDAO.inserimentoMessaggioPerVisualizzazione(resultSetListaUtenti.getInt(1), idNotifica.getInt(1));
					}
				}
			}
		} catch (Exception e){
			e.printStackTrace();
			Alert a = new Alert(Alert.AlertType.ERROR);
			a.setTitle("ERRORE");
			a.setContentText("errore, controllare esistano utenti e verificare i campi immessi");
			a.show();
		}
	}
	
	@FXML
	public void close(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		enableStage();
		stage.hide();
	}
}
