package controllers;

import java.io.IOException;
import java.sql.ResultSet;

import MariaDbDAO.OrdiniDAO;
import MariaDbDAO.TavoloDAO;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.ImageCursor;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class SalaController extends ExtendedController {
	
	TavoloDAO tavoloDAO = new TavoloDAO();
	OrdiniDAO ordineDAO = new OrdiniDAO();
	
	@FXML private FlowPane tables_box;
	@FXML private Label label_id;
	@FXML private Pane pane;
	private Image img = new Image(getClass().getResourceAsStream(("../files/dining-table.png")));
	
	@FXML
	public void initialize() {
		try {
			setPane(pane);
			ResultSet rs = tavoloDAO.ListaTavolo(utente.getIdSala());
			
			while(rs.next()) {
				
				Rectangle table = new Rectangle(250,250);
				table.setFill(new ImagePattern(img));
				table.setCursor(new ImageCursor(mouse));
				
				Text text = new Text(String.valueOf(rs.getInt("tavoloID")));
				text.setFont(Font.font(250));
				text.setOpacity(0.5);
				
				int count = rs.getInt("tavoloID");
				ResultSet hasordine = ordineDAO.CountOrdinazioniTavolo(count);
				hasordine.next();
				
				text.setFill((hasordine.getInt(1)>0) ? Color.ORANGE : Color.DARKBLUE);
				
				StackPane stack = new StackPane();
				stack.getChildren().addAll(table, text);
				
				stack.setOnMouseClicked(new EventHandler<Event>() {
					@Override
					public void handle(Event event) {
						try {
							chosen_table = count;
							changeSceneNotFullscreen(event, "AddOrdersScene");
						} catch (IOException e) {
							e.printStackTrace();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				});
				
				tables_box.getChildren().add(stack);
			}
			tables_box.setVgap(20);
			tables_box.setHgap(20);
			tables_box.setPadding(new Insets(20));
			label_id.setText("Sala: " + utente.getIdSala());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "HomePageScene");
	}
	
	@FXML
	public void addOrders(ActionEvent even) throws IOException, InterruptedException {
		changeSceneNotFullscreen(even, "AddOrdersScene");
	}
}
