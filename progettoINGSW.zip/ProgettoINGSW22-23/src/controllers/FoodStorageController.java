package controllers;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;

import MariaDbDAO.IngredienteDAO;
import MariaDbDAO.ProdottoDAO;
import application.CustomButton;
import dto.Ingrediente;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class FoodStorageController extends ExtendedController {

	IngredienteDAO ingredienteDAO = new IngredienteDAO();
	ProdottoDAO foodStorageDAO = new ProdottoDAO();

	@FXML private Pane pane;
	@FXML private CustomButton addButton;
	@FXML private TextField txt_cerca_prodotto;
	@FXML private FlowPane ingredients_box;

	public static Ingrediente ingrediente = new Ingrediente();
	private ArrayList<Ingrediente> ingredienti = new ArrayList<Ingrediente>();

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "HomePageScene");
	}

	@FXML
	public void addIngredient(ActionEvent event) throws IOException, InterruptedException {
		try {
			changeSceneNotFullscreen(event, "AddIngredientScene");
		} catch (Exception e){
			e.printStackTrace();
		}
	}

	@FXML
	public void removeIngredient(Event arg0) throws IOException, InterruptedException {
		if (alertClass.alertlog("Rimuovere l'ingrediente "+ ingrediente.getNome() +"?").showAndWait()
				.get() == ButtonType.OK) {
			try {
				ingredienteDAO.RimuoviIngrediente(ingrediente.getIngredienteId());
				buildData("");
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
	}

	@FXML
	void initialize() {
		try {
			ResultSet rs = ingredienteDAO.ListaIngredienti();
			while(rs.next()) {
				ingredienti.add(new Ingrediente(rs.getString(1), rs.getInt(2), rs.getInt(3)));
			}
		} catch (Exception e) {e.printStackTrace();}
		
		buildData("");
		setPane(pane);
		
		if(!isAdmin)
			pane.getChildren().remove(addButton);
		
		txt_cerca_prodotto.textProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> arg0, String arg1, String arg2) {
				buildData(arg2);
			}
		});
	}

	@SuppressWarnings("static-access")
	public void buildData(String searched) {
		try {
			ingredients_box.getChildren().removeAll(ingredients_box.getChildren());
			for(Ingrediente food : ingredienti) {
				if(!searched.equals("") && !food.getNome().contains(searched)) {
					continue;
				}
				AnchorPane item = new AnchorPane();
				item.setPrefSize(300, 200);
				
				Text nomeIngrediente = new Text(food.getNome());
				Text quantit� = new Text("Disponibili in dispensa: "+food.getQuantita());
				item.setId(String.valueOf(food.getIngredienteId()));
				CustomButton removebutton = new CustomButton(); removebutton.setId("removeButton"); removebutton.setPrefSize(50, 50);
				CustomButton editbutton = new CustomButton(); editbutton.setId("editButton"); editbutton.setPrefSize(50, 50);
				
				nomeIngrediente.setFont(Font.font("MontSerrat", food.getQuantita()==0 ? FontWeight.THIN : FontWeight.BOLD, 20)); nomeIngrediente.setFill(Color.WHITE);
				quantit�.setFont(Font.font("MontSerrat", food.getQuantita()==0 ? FontWeight.THIN : FontWeight.BOLD, 20)); quantit�.setFill(Color.WHITE);
				
				removebutton.setOnMouseClicked(new EventHandler<Event>() {
					@Override
					public void handle(Event arg0) {
						try {
							ingrediente.setNome(nomeIngrediente.getText());
							ingrediente.setIngredienteId(Integer.parseInt(item.getId()));
							ingrediente.setQuantita(Integer.parseInt(quantit�.getText().substring(25)));
							removeIngredient(arg0);
							ingrediente = new Ingrediente();
						} catch (Exception e) {
							e.printStackTrace();
						}			
					}
				});
				
				editbutton.setOnMouseClicked(new EventHandler<Event>() {
					@Override
					public void handle(Event arg0) {
						try {
							ingrediente.setNome(nomeIngrediente.getText());
							ingrediente.setIngredienteId(Integer.parseInt(item.getId()));
							ingrediente.setQuantita(Integer.parseInt(quantit�.getText().substring(25)));
							changeSceneNotFullscreen(arg0, "AddIngredientScene");
							ingrediente = new Ingrediente();
						} catch (Exception e) {
							e.printStackTrace();
						}	
					}
				});
				
				item.getChildren().addAll(nomeIngrediente, quantit�, removebutton, editbutton);
				item.setTopAnchor(nomeIngrediente, 20.0); item.setLeftAnchor(nomeIngrediente, 20.0);
				item.setTopAnchor(quantit�, 50.0); item.setLeftAnchor(quantit�, 20.0);
				item.setBottomAnchor(removebutton, 20.0); item.setLeftAnchor(removebutton, 20.0);
				item.setBottomAnchor(editbutton, 20.0); item.setRightAnchor(editbutton, 20.0);
				ingredients_box.getChildren().add(item);
			}
			
			ingredients_box.setVgap(20);
			ingredients_box.setHgap(20);
			ingredients_box.setPadding(new Insets(20));
					
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}
}