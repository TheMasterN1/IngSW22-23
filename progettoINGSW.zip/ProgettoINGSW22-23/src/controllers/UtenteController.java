package controllers;

import MariaDbDAO.UtenteDAO;
import enumerations.TipoUtente;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.IOException;

public class UtenteController extends ExtendedController {

	
	UtenteDAO utenteDAO = new UtenteDAO();
	
	@FXML TextField txt_nome;
	@FXML TextField txt_cognome;
	@FXML TextField txt_username;
	@FXML TextField txt_password;
	@FXML TextField txt_conferma_password;
	@FXML Button exit_btn;
	@FXML Button ok_btn;
	@FXML ImageView profilepic;
	@FXML TextField txt_ruolo;

	@FXML
	private void initialize() {
		int i = TipoUtente.valueOf(utente.getRuolo()).ordinal();
		
		switch (i) {
		case 0: {profilepic.setImage(new Image(getClass().getResourceAsStream("../files/admin.png")));} break;
		case 1: {profilepic.setImage(new Image(getClass().getResourceAsStream("../files/cooker.png")));} break;
		case 2: {profilepic.setImage(new Image(getClass().getResourceAsStream("../files/supervisor.png")));} break;
		case 3: {profilepic.setImage(new Image(getClass().getResourceAsStream("../files/waiter.png")));} break;
		}
		
		if(utente!=null){
			if(utente.getUsername()!=null) {
				txt_username.setText(utente.getUsername());
			}
			if(utente.getPassword()!=null) {
				txt_password.setText(utente.getPassword());
			}

			if(utente.getRuolo()!=null){
				txt_ruolo.setText(utente.getRuolo());
				txt_ruolo.setEditable(false);
			}
		}
		disableStage();
	}

	@FXML
	public void okBtn(ActionEvent event) {

		try {
			if (txt_username != null && txt_username.getText().length() > 0 && txt_password.getText().length() > 0 && txt_conferma_password.getText().length() > 0) {
				if (txt_password.getText().equals(txt_conferma_password.getText())) {
					utenteDAO.UpdateUtente(utente.getId(),txt_username.getText(), txt_password.getText(), utente.getRuolo(), utente.getIdSala());
					closeAndReEnable(event);
				} else {
					alertClass.alertlog("errore, campi mancanti o sbagliati").showAndWait();
				}
			} else {
				alertClass.alertlog("errore, campi mancanti o sbagliati").showAndWait();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		closeAndReEnable(event);
	}
	
}
