package controllers;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import MariaDbDAO.NotificheDAO;
import application.CustomButton;
import dto.Notifiche;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.util.Callback;

public class NotificationController extends ExtendedController {

	@FXML private Pane pane;
	@FXML private CustomButton addButton;
	@FXML private TextField txt_cerca_testo;
	@FXML private TableView<ObservableList<String>> tableNotifiche = new TableView<ObservableList<String>>();
	@FXML private RadioButton check_readen;
	public static Notifiche notifiche;
	NotificheDAO notificheDAO = new NotificheDAO();
	ResultSet rs;

	@FXML
	public void initialize() {
		if(!isAdmin)
			pane.getChildren().remove(addButton);

		buildData();
		setPane(pane);
				
		tableNotifiche.setRowFactory(tv->{
			TableRow<ObservableList<String>> row = new TableRow<>();
			row.setOnMouseClicked(event -> {
				try {
					notifiche = new Notifiche(Integer.parseInt(row.getItem().get(0).toString()), row.getItem().get(1).toString(), row.getItem().get(2).toString(), utente.getId());
					changeSceneNotFullscreen(event, "SendNotificationScene");
				} catch (IOException e) {
					throw new RuntimeException(e);
				} catch (InterruptedException e) {
					throw new RuntimeException(e);
				}
			});
			return row;
		});	
		
		check_readen.setOnMouseClicked(arg0 -> {
			rebuildData();
		});
	}
	
	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "HomePageScene");
	}

	@FXML
	public void create(ActionEvent event) throws IOException, InterruptedException {
		setPane(pane);
		disableStage();
		changeSceneNotFullscreen(event, "SendNotificationScene");
	}

	@FXML
	public void cancel(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "NotificationScene");
	}

	@FXML
	public void send(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "NotificationScene");
	}

	@SuppressWarnings("unchecked")
	@FXML
	public void buildData() {
		try {
			rs = notificheDAO.ListaMessaggiSpecifici(utente.getId());
			
			ObservableList<ObservableList<String>> data = FXCollections.observableArrayList();

			tableNotifiche.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);
			
			for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {

				final int j = i;
				TableColumn<ObservableList<String>, String> col = new TableColumn<>(rs.getMetaData().getColumnName(i + 1));
				col.setCellValueFactory((Callback<TableColumn.CellDataFeatures<ObservableList<String>, String>, ObservableValue<String>>) param -> {
					if (param.getValue().get(j) != null) {
						return new SimpleStringProperty(param.getValue().get(j).toString());
					} else {
						return null;
					}
				});
				tableNotifiche.getColumns().addAll(col);
			}

			while (rs.next()) {
				//Iterate Row
				ObservableList<String> row = FXCollections.observableArrayList();
				for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
					//Iterate Column
					row.add(rs.getString(i));
				}
				data.add(row);
			}

			FilteredList<ObservableList<String>> filteredData = new FilteredList<>(data, b->true);

			txt_cerca_testo.textProperty().addListener((observable, oldValue, newValue ) ->{
				filteredData.setPredicate(dato->{
					if(newValue == null || newValue.isEmpty()){
						return true;
					}

					String lowerCaseFilter =  newValue.toLowerCase();

					if(dato.get(1).toString().toLowerCase().indexOf(lowerCaseFilter)!=-1){
						return true;
					}
					else{
						return false;
					}
				});
			});

			SortedList<ObservableList<String>> sortedList = new SortedList<>(filteredData);
			sortedList.comparatorProperty().bind(tableNotifiche.comparatorProperty());

			//FINALLY ADDED TO TableView
			tableNotifiche.setItems(sortedList);
			
		} catch (SQLException ex) {
			throw new RuntimeException(ex);
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}
	
	@FXML
	public void rebuildData() {
		try {
			if(!check_readen.isSelected())
				rs = notificheDAO.ListaMessaggiSpecifici(utente.getId());
			else
				rs = notificheDAO.ListaNotificheVisualizzate(utente.getId());
			
			ObservableList<ObservableList<String>> data = FXCollections.observableArrayList();

			tableNotifiche.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);

			while (rs.next()) {
				//Iterate Row
				ObservableList<String> row = FXCollections.observableArrayList();
				for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
					//Iterate Column
					row.add(rs.getString(i));
				}
				data.add(row);
			}
			
			tableNotifiche.setItems(data);
			
		} catch (SQLException ex) {
			throw new RuntimeException(ex);
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}
}