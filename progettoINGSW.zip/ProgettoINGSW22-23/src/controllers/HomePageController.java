package controllers;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import MariaDbDAO.NotificheDAO;
import application.CustomButton;
import enumerations.TipoUtente;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class HomePageController extends ExtendedController {

	@FXML private Label datetime = new Label();
	@FXML private Circle countNotify;
	@FXML private Pane image;
	@FXML private CustomButton dipendentButton, ordersButton;
	NotificheDAO notificheDAO = new NotificheDAO();

	@FXML
	public void initialize() {
		setPane(image);

		if(!isAdmin)
			image.getChildren().remove(dipendentButton);
		
		if(utente.getRuolo().equals(TipoUtente.Addetto_Sala.toString()))
			ordersButton.setText("Sala");
		
		try {
			ResultSet rs = notificheDAO.CheckDaVisualizzare(utente.getId());
			rs.next();
			if(rs.getInt("Count(*)")==0)
				image.getChildren().remove(countNotify);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
			
	}

	public HomePageController() {
		KeyFrame update = new KeyFrame(Duration.seconds(1.0), event -> {
			datetime.setText(getTime(Locale.ITALY));
		});
		Timeline timeline = new Timeline(update);
		timeline.setCycleCount(Animation.INDEFINITE);
		timeline.play();
	}

	@FXML
	private void register(ActionEvent event) throws IOException, InterruptedException {
		changeSceneNotFullscreen(event, "RegisterDipendentScene");
	}
	
	@FXML
	private void seeProfile(ActionEvent event) throws IOException, InterruptedException {
		changeSceneNotFullscreen(event, "ProfileScene");
	}

	@FXML
	public void logout(ActionEvent event) throws IOException, InterruptedException {
		Alert alert = alertClass.alertlog("Vuoi disconnetterti?");
		if (alert.showAndWait().get() == ButtonType.OK) {
			close(event);
			changeSceneNotFullscreen(event, "LoginScene");
		}
	}

	@FXML
	public void openNotify(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "NotificationScene");
	}

	@FXML
	public void seeFood(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "FoodStorageScene");
	}

	@FXML
	public void seeMenu(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "MenuScene");
	}

	@FXML
	public void seeOrders(ActionEvent event) throws IOException, InterruptedException {
		if(utente.getRuolo().equals(TipoUtente.Addetto_Sala.toString()))
			changeSceneFullscreen(event, "SalaScene");
		else
			changeSceneFullscreen(event, "OrdersScene");
	}
	
	public String getTime(Locale local) {
		SimpleDateFormat sdf = new SimpleDateFormat("EEEE d MMMM yyyy HH:mm:ss", local);
		Date now = new Date();
		String strDate = sdf.format(now);
		return strDate;
	}

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "HomePageScene");
	}
	
	@FXML
	public void close(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.hide();
	}

}
