package controllers;

import java.io.IOException;
import java.sql.ResultSet;
import MariaDbDAO.*;
import application.dbConnection;
import enumerations.TipoUtente;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class MainController extends ExtendedController {

	dbConnection db = new dbConnection();
	UtenteDAO utenteDAO = new UtenteDAO();

	@FXML private TextField usertext;
	@FXML private PasswordField passwordtext;

	@FXML
	public void checkLog(ActionEvent event) throws IOException, InterruptedException {
		try {
			ResultSet rs = utenteDAO.ListaUtente(usertext.getText(), passwordtext.getText());
			boolean isNew = false;
			while (rs.next()){
				setUtente(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4), (Integer) rs.getObject(5));
				isNew = rs.getString(6).equals("N") ? false : true;
			}
			setIsAdmin((TipoUtente.valueOf(utente.getRuolo()).ordinal()==0) ? true : false);
			changeSceneFullscreen(event, "HomePageScene");	
			if(isNew) {
				checkPassword();
			}
		
		} catch (Exception e) {
			alertClass.alertlog("I campi Username/Password sono errati. \nSi prega di controllare le credenziali e ritentare l'accesso ").show();
		}
	}
	
	private void checkPassword() throws Exception {
		if(alertClass.askNewPassword().showAndWait().get()==ButtonType.OK) {
			utente.setPassword(alertClass.setNewPassword());
		}
		utenteDAO.UpdateUtente(utente.getId(), utente.getUsername(), utente.getPassword(), utente.getRuolo(), utente.getIdSala());
	}

	@FXML
	public void close(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.hide();
	}
}