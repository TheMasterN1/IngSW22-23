package controllers;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import MariaDbDAO.IngredienteDAO;
import MariaDbDAO.ProdottoDAO;
import enumerations.Allergeni;
import enumerations.TipoProdottoIta;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class AddDishMenuController extends ExtendedController {

	ProdottoDAO prodottoDAO = new ProdottoDAO();
	IngredienteDAO foodStorageDAO = new IngredienteDAO();

	@FXML private TextField txt_nome_prodotto = new TextField();
	@FXML private TextArea txt_descrizione_prodotto;
	@FXML private ListView<Allergeni> txt_allergeni;
	@FXML private Spinner<Double> txt_costo = new Spinner<>();
	@FXML private ComboBox<TipoProdottoIta> comboBox_categoria = new ComboBox<>();
	@FXML private FlowPane table_ricetta;
	
	@FXML
	public void initialize() {
		txt_allergeni.setItems(FXCollections.observableArrayList(Allergeni.values()));
		txt_allergeni.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		txt_allergeni.setTooltip(new Tooltip("Tenere premuto CTRL per la multi-selezione"));
		
		txt_descrizione_prodotto.setWrapText(true);
		
		comboBox_categoria.setItems(FXCollections.observableArrayList(TipoProdottoIta.values()));
		
		if(MenuController.prodotto.getProdottoID()!=0){
			txt_nome_prodotto.setText(MenuController.prodotto.getName());
			txt_descrizione_prodotto.setText(MenuController.prodotto.getDescrizione());
			txt_costo.getValueFactory().setValue(Double.valueOf(MenuController.prodotto.getCosto()));
			comboBox_categoria.setValue(MenuController.prodotto.getCategoria());
		}
		
		try {
			ResultSet rs = foodStorageDAO.ListaIngredienti();
			while (rs.next()) {

				Text nomeProdotto = new Text(rs.getString(1));
				nomeProdotto.setFont(Font.font("System", FontWeight.BOLD, 12));
				nomeProdotto.setFill(Color.WHITE);
				
				Spinner<Integer> quantitaProdotto = new Spinner<>(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 5, 0, 1));
				
				GridPane stack = new GridPane();
				stack.add(nomeProdotto, 0, 0);
				stack.add(quantitaProdotto, 1, 0);
				stack.setHgap(20);
				table_ricetta.getChildren().add(stack);
			}
		}catch (SQLException ex) {
			throw new RuntimeException(ex);
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
		
		table_ricetta.setVgap(20);
		table_ricetta.setHgap(20);
		table_ricetta.setPadding(new Insets(20));		

	}
	
	@FXML
	public void cancelAdd(ActionEvent event) throws IOException, InterruptedException {
		closeAndReEnable(event);
	}

	@SuppressWarnings("unchecked")
	@FXML
	private void addQtProduct(ActionEvent event) throws IOException, InterruptedException  {
		alertClass.notifyAddQt();
		if(txt_nome_prodotto.getText().length()>0 && txt_descrizione_prodotto.getText().length()>0 && txt_nome_prodotto.getText().length()>0 &&
				Float.parseFloat(txt_costo.getValue().toString())>0 && comboBox_categoria.getValue()!=null){
			try {
				//TODO metti update se parti da MENU per modifica
				prodottoDAO.InserisciProdotto(Float.parseFloat(txt_costo.getValue().toString()), txt_nome_prodotto.getText().toString(), txt_allergeni.getSelectionModel().getSelectedItems().toString(),  txt_descrizione_prodotto.getText(), comboBox_categoria.getValue().toString());
				for(Node ricetta : table_ricetta.getChildren()) {
					GridPane pane = (GridPane) ricetta;
					
					Text nome = (Text) pane.getChildren().get(0);
					
					Spinner<Integer> quantit� = (Spinner<Integer>) pane.getChildren().get(1);
					
					if(quantit�.getValue()==0)
						continue;

					prodottoDAO.InserisciRicetta(txt_nome_prodotto.getText(),nome.getText(), quantit�.getValue().intValue());
				}
				closeAndReEnable(event);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		else{
			Alert a = new Alert(Alert.AlertType.ERROR);
			a.setTitle("ERRORE");
			a.setContentText("errore, campi mancanti o sbagliati");
			a.show();
		}
	}
}
