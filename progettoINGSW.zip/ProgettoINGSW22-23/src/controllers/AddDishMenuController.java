package controllers;

import java.io.IOException;

import MariaDbDAO.ProdottoDAO;
import enumerations.Allergeni;
import enumerations.TipoProdotto;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.Spinner;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;

public class AddDishMenuController extends ExtendedController {

	ProdottoDAO prodottoDAO = new ProdottoDAO();
	
	
	@FXML private TextField txt_nome_prodotto = new TextField();
	@FXML private TextArea txt_descrizione_prodotto;
	@FXML private ListView<Allergeni> txt_allergeni;
	@FXML private Spinner<Double> txt_costo = new Spinner<>();
	@FXML private Spinner<Integer> spinner_qta = new Spinner<>();
	@FXML private ComboBox<TipoProdotto> comboBox_categoria = new ComboBox<>();
	
	@FXML
	public void initialize() {
		txt_allergeni.setItems(FXCollections.observableArrayList(Allergeni.values()));
		txt_allergeni.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		txt_allergeni.setTooltip(new Tooltip("Tenere premuto CTRL per la multi-selezione"));
		
		comboBox_categoria.setItems(FXCollections.observableArrayList(TipoProdotto.values()));
		
		if(MenuController.prodotto.getProdottoID()!=0){
			txt_nome_prodotto.setText(MenuController.prodotto.getName());
			txt_descrizione_prodotto.setText(MenuController.prodotto.getDescrizione());
			txt_costo.getValueFactory().setValue(Double.valueOf(MenuController.prodotto.getCosto()));
			spinner_qta.getValueFactory().setValue(MenuController.prodotto.getQuantita());
			comboBox_categoria.setValue(TipoProdotto.valueOf(MenuController.prodotto.getCategoria()));
		}
	}
	
	@FXML
	public void cancelAdd(ActionEvent event) throws IOException, InterruptedException {
		closeAndReEnable(event);
	}

	@FXML
	private void addQtProduct(ActionEvent event) throws IOException, InterruptedException  {
		alertClass.notifyAddQt();
		if(txt_nome_prodotto.getText().length()>0 && txt_descrizione_prodotto.getText().length()>0 && txt_nome_prodotto.getText().length()>0 &&
				Float.parseFloat(txt_costo.getValue().toString())>0 && comboBox_categoria.getValue()!=null){
			try {
				prodottoDAO.InserisciProdotto(Float.parseFloat(txt_costo.getValue().toString()), txt_nome_prodotto.getText().toString(), txt_allergeni.getSelectionModel().getSelectedItems().toString(),  txt_descrizione_prodotto.getText(), Integer.parseInt(spinner_qta.getValue().toString()), comboBox_categoria.getValue().toString());
				closeAndReEnable(event);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		else{
			Alert a = new Alert(Alert.AlertType.ERROR);
			a.setTitle("ERRORE");
			a.setContentText("errore, campi mancanti o sbagliati");
			a.show();
		}
	}
}
