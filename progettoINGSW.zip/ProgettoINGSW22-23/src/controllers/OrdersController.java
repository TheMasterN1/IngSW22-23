package controllers;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.util.Callback;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import MariaDbDAO.IngredienteDAO;
import MariaDbDAO.OrdiniDAO;

public class OrdersController extends ExtendedController {

	OrdiniDAO ordiniDAO = new OrdiniDAO();
	IngredienteDAO ingredienteDAO = new IngredienteDAO();
	
	@FXML private Pane pane;
	@FXML private TableView<ObservableList<String>> tableOrdini = new TableView<ObservableList<String>>();
	@FXML private TextField txt_descrizione = new TextField();

	@FXML
	public void initialize() {
		setPane(pane);
		buildDataTable();	
		
		tableOrdini.setRowFactory(tv->{
			TableRow<ObservableList<String>> row = new TableRow<>();
			row.setOnMouseClicked(event -> {
				if(row.getItem().get(1).equals("0"))
					emptyOrder(row.getItem().get(0));
				else
					satisfyOrdine(row.getItem().get(0));
			});
			return row;
		});
	}
	
	private void emptyOrder(String string) {
		alertClass.alertlog("L'ordine n� " + string + " non ha ordinazioni attive").showAndWait();
	}

	private void satisfyOrdine(String string) {
		if (alertClass.alertlog("Soddisfare l'ordine n� " + string +"?").showAndWait()
				.get() == ButtonType.OK) {
			try {
				ordiniDAO.RimuoviOrdinazioni(string);				
				rebuildData();
			} catch (Exception ex) {
				throw new RuntimeException(ex);
			}
		}
	}

	private void rebuildData() {
		try {
		ResultSet rs = ordiniDAO.ListaOrdini();
		ObservableList<ObservableList<String>> data = FXCollections.observableArrayList();

		tableOrdini.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);

		while (rs.next()) {
			//Iterate Row
			ObservableList<String> row = FXCollections.observableArrayList();
			for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
				//Iterate Column
				row.add(rs.getString(i));
			}
			data.add(row);
		}

		//FINALLY ADDED TO TableView
		tableOrdini.setItems(data);	
		} catch (SQLException ex) {
			throw new RuntimeException(ex);
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "HomePageScene");
	}

	@SuppressWarnings("unchecked")
	@FXML
	public void buildDataTable() {
		try {
			ResultSet rs = ordiniDAO.ListaOrdini();
			ObservableList<ObservableList<String>> data = FXCollections.observableArrayList();

			tableOrdini.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);
			for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {

				final int j = i;
				TableColumn<ObservableList<String>, String> col = new TableColumn<>(rs.getMetaData().getColumnName(i + 1));
				col.setCellValueFactory((Callback<TableColumn.CellDataFeatures<ObservableList<String>, String>, ObservableValue<String>>) param -> {
					if (param.getValue().get(j) != null) {
						return new SimpleStringProperty(param.getValue().get(j).toString());
					} else {
						return null;
					}
				});

				tableOrdini.getColumns().addAll(col);
			}

			while (rs.next()) {
				//Iterate Row
				ObservableList<String> row = FXCollections.observableArrayList();
				for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
					//Iterate Column
					row.add(rs.getString(i));
				}
				data.add(row);
			}
			
			FilteredList<ObservableList<String>> filteredData = new FilteredList<>(data, b->true);

			txt_descrizione.textProperty().addListener((observable, oldValue, newValue ) ->{
				filteredData.setPredicate(dato->{
					if(newValue == null || newValue.isEmpty()){
						return true;
					}

					String lowerCaseFilter =  newValue.toLowerCase();

					if(dato.get(3).toString().indexOf(lowerCaseFilter)!=-1){
						return true;
					}
					else{
						return false;
					}
				});
			});

			SortedList<ObservableList<String>> sortedList = new SortedList<>(filteredData);
			sortedList.comparatorProperty().bind(tableOrdini.comparatorProperty());

			//FINALLY ADDED TO TableView
			tableOrdini.setItems(sortedList);
			
			for(Node node : tableOrdini.lookupAll(".table-row-cell")) {
				TableRow<ObservableList<String>> row = (TableRow<ObservableList<String>>) node;
				row.setFont(row.getItem().get(1).equals("0") ? Font.font("System", FontWeight.EXTRA_LIGHT, 12) : Font.font("System", FontWeight.BOLD, 12));
			}
		} catch (SQLException ex) {
			throw new RuntimeException(ex);
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}
}