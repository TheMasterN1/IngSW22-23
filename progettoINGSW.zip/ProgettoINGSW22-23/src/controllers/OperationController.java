package controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;

import java.io.IOException;
import java.sql.ResultSet;

import MariaDbDAO.SalaDAO;
import MariaDbDAO.UtenteDAO;
import enumerations.TipoUtente;

public class OperationController extends ExtendedController {

	SalaDAO salaDAO = new SalaDAO();
	UtenteDAO utenteDAO = new UtenteDAO();
	
	@FXML private Pane pane;
	@FXML private Label sala;
	@FXML private ChoiceBox<Integer> choicesala;
	@FXML private TextField txt_username;
	@FXML private PasswordField txt_password;
	@FXML private PasswordField txt_conferma_password;
	@FXML private ChoiceBox<TipoUtente> choiceRuolo;
	
	@FXML
	public void initialize() {

		pane.getChildren().remove(sala);
		pane.getChildren().remove(choicesala);

		choiceRuolo.setItems(FXCollections.observableArrayList(TipoUtente.values()));

		if(choicesala!=null) {
			ObservableList<Integer> items = FXCollections.observableArrayList();
			try {
				ResultSet resultSet = salaDAO.GetAllSale();
				while (resultSet.next()) {
					items.add(resultSet.getInt(1));
				}

				choicesala.setItems(items);
			} catch (Exception e) {
				e.printStackTrace();
			}

			choiceRuolo.setOnAction(event -> {
				if(choiceRuolo.getSelectionModel().getSelectedItem().equals(TipoUtente.Addetto_Sala)){
					pane.getChildren().add(sala);
					pane.getChildren().add(choicesala);
				}
				else{
					pane.getChildren().remove(sala);
					pane.getChildren().remove(choicesala);
				}
			});

		}

	}
	
	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		closeAndReEnable(event);
	}
	@FXML
	public void addUser(ActionEvent event) throws IOException, InterruptedException{
		try {
			if (txt_username != null && txt_username.getText().length() > 0 && txt_password != null && txt_password.getText().length() > 0 && txt_conferma_password != null &&
					txt_conferma_password.getText().length() > 0 && choiceRuolo != null && choiceRuolo.getSelectionModel().getSelectedItem() != null) {
				if (txt_password.getText().equals(txt_conferma_password.getText())) {
					if(choicesala!=null && choicesala.getSelectionModel().getSelectedItem()!=null) {
						utenteDAO.InserisciUtente(txt_username.getText(), txt_password.getText(), choiceRuolo.getSelectionModel().getSelectedItem().toString(), Integer.parseInt(choicesala.getSelectionModel().getSelectedItem().toString()));
					}
					else{
						utenteDAO.InserisciUtente(txt_username.getText(), txt_password.getText(), choiceRuolo.getSelectionModel().getSelectedItem().toString(), null);
						closeAndReEnable(event);
					}
				} else {
					Alert a = new Alert(Alert.AlertType.ERROR);
					a.setTitle("ERRORE");
					a.setContentText("errore, campi mancanti o sbagliati");
					a.show();
				}
			} else {
				Alert a = new Alert(Alert.AlertType.ERROR);
				a.setTitle("ERRORE");
				a.setContentText("errore, campi mancanti o sbagliati");
				a.show();
			}
		}catch (Exception e){
			e.printStackTrace();
		}
	}
}
