package controllers;

import MariaDbDAO.ProdottoDAO;
import MariaDbDAO.TavoloDAO;
import MariaDbDAO.OrdiniDAO;
import application.CustomButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AddOrdersController extends ExtendedController {
	
	OrdiniDAO ordiniDAO = new OrdiniDAO();
	ProdottoDAO prodottoDAO = new ProdottoDAO();
	TavoloDAO tavoloDAO = new TavoloDAO();
	
	@FXML private Pane pane;
	@FXML private CustomButton addButton;
	@FXML private ComboBox<Integer> choice_tables = new ComboBox<>();
	@FXML private FlowPane table_ordinazione;

	@FXML
	public void initialize() {
		
		if(!isAdmin)
			pane.getChildren().remove(addButton);

        buildComboBox();

		try {
			ResultSet rs = prodottoDAO.ListaProdotti();
			while (rs.next()) {

				Text nomeProdotto = new Text(rs.getString(2));
				nomeProdotto.setFont(Font.font("System", FontWeight.BOLD, 12));
				nomeProdotto.setFill(Color.WHITE);
				
				Spinner<Integer> quantitaProdotto = new Spinner<>(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 5, 0, 1));
				
				GridPane stack = new GridPane();
				stack.add(nomeProdotto, 0, 0);
				stack.add(quantitaProdotto, 1, 0);
				stack.setHgap(20);
				table_ordinazione.getChildren().add(stack);
			}
		}catch (SQLException ex) {
			throw new RuntimeException(ex);
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
		
		table_ordinazione.setVgap(20);
		table_ordinazione.setHgap(20);
		table_ordinazione.setPadding(new Insets(20));		

	}
	
	@FXML
	public void cancelAdd(ActionEvent event) throws IOException, InterruptedException {
		closeAndReEnable(event);
	}

	@SuppressWarnings("unchecked")
	@FXML
	public void confirmAdd(ActionEvent event) throws IOException, InterruptedException {
		alertClass.notifyAdd();
			try {
				for(Node ricetta : table_ordinazione.getChildren()) {
					GridPane pane = (GridPane) ricetta;
					
					Text nome = (Text) pane.getChildren().get(0);
					
					Spinner<Integer> quantit� = (Spinner<Integer>) pane.getChildren().get(1);
					
					if(quantit�.getValue()==0)
						continue;
					ordiniDAO.InserisciOrdinazione(nome.getText(), quantit�.getValue(), choice_tables.getValue());
				}
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		closeAndReEnable(event);
	}

	@FXML
	public void buildComboBox(){

		ResultSet rs;
		try{
			rs = tavoloDAO.ListaTavoliSingoli(utente.getIdSala());
			while(rs.next()){
				choice_tables.getItems().add(rs.getInt(1));
			}

			choice_tables.setValue(chosen_table);

		} catch (Exception e){
			e.printStackTrace();
		}
	}
}
