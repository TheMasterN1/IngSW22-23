package controllers;

import MariaDbDAO.ProdottoDAO;
import MariaDbDAO.TavoloDAO;
import MariaDbDAO.OrdiniDAO;
import application.ComboBoxItemWrap;
import application.CustomButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AddOrdersController extends ExtendedController {
	
	OrdiniDAO ordiniDAO = new OrdiniDAO();
	ProdottoDAO foodStorageDAO = new ProdottoDAO();
	TavoloDAO tavoloDAO = new TavoloDAO();
	
	@FXML private Pane pane;
	@FXML private CustomButton addButton;
	@FXML private ComboBox<ComboBoxItemWrap<String>> comboBoxProdotti;
	@FXML private TableView<ObservableList<String>> tableOrdini = new TableView<ObservableList<String>>();
	@FXML private ComboBox<String> choice_tables = new ComboBox<>();
	@FXML private TextField txt_costo = new TextField();
	@FXML private TextField txt_descrizione = new TextField();
	
	@FXML
	public void initialize() {
		
		if(!isAdmin)
			pane.getChildren().remove(addButton);

        buildComboBox();

		ObservableList<ComboBoxItemWrap<String>> options = FXCollections.observableArrayList();

		try {
			ResultSet rs = foodStorageDAO.ListaProdotti();
			while (rs.next()) {
				options.add(new ComboBoxItemWrap<>(rs.getString(4)+")"+rs.getString(2)));
			}
		}catch (SQLException ex) {
			throw new RuntimeException(ex);
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}

		comboBoxProdotti.setCellFactory( c -> {
			ListCell<ComboBoxItemWrap<String>> cell = new ListCell<>(){
				@Override
				protected void updateItem(ComboBoxItemWrap<String> item, boolean empty) {
					super.updateItem(item, empty);
					if (!empty) {
						final CheckBox comboBoxProdotti = new CheckBox(item.toString());
						comboBoxProdotti.selectedProperty().bind(item.checkProperty());
						setGraphic(comboBoxProdotti);
					}
				}
			};

			cell.addEventFilter(MouseEvent.MOUSE_RELEASED, event -> {
				cell.getItem().checkProperty().set(!cell.getItem().checkProperty().get());
				StringBuilder sb = new StringBuilder();
				comboBoxProdotti.getItems().filtered( f-> f!=null).filtered( f-> f.getCheck()).forEach( p -> {
					sb.append("; "+p.getItem());
				});
				final String string = sb.toString();
				comboBoxProdotti.setPromptText(string.substring(Integer.min(2, string.length())));
			});

			return cell;
		});

		comboBoxProdotti.setItems(options);
	}
	
	@FXML
	public void cancelAdd(ActionEvent event) throws IOException, InterruptedException {
		closeAndReEnable(event);
	}

	@FXML
	public void confirmAdd(ActionEvent event) throws IOException, InterruptedException {
		alertClass.notifyAdd();
		if(txt_costo.getText().length()>0 && choice_tables.getValue().length()>0 && comboBoxProdotti.getPromptText()!=null && comboBoxProdotti.getPromptText().length()>0){
			try {
				String[] parts = comboBoxProdotti.getPromptText().split("\\)|\\;");
				for(int i =0 ; i<=parts.length-1;i+=2){
					ordiniDAO.InserisciOrdine(Double.parseDouble(txt_costo.getText().toString()), Integer.parseInt(parts[i].trim()), Integer.parseInt(choice_tables.getSelectionModel().getSelectedItem()) );
				}
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
		else{
			Alert a = new Alert(Alert.AlertType.ERROR);
			a.setTitle("ERRORE");
			a.setContentText("errore, campi mancanti o sbagliati");
			a.show();
		}
		closeAndReEnable(event);
	}

	@FXML
	public void buildComboBox(){

		ResultSet rs;
		try{
			rs = tavoloDAO.ListaTavoliSingoli(utente.getIdSala());
			while(rs.next()){
				choice_tables.getItems().add(String.valueOf(rs.getInt(1)));
			}

			choice_tables.setPromptText(String.valueOf(chosen_table));

		} catch (Exception e){
			e.printStackTrace();
		}
	}
}
