package application;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.ImageCursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;

public class Login extends Application {
	@Override
	public void start(Stage stage) {
		try {
			Image image = new Image(getClass().getResourceAsStream("../files/mitten.png"));
			Parent root = FXMLLoader.load(getClass().getResource("../scenes/LoginScene.fxml"));
			stage.initStyle(StageStyle.TRANSPARENT);
			stage.setResizable(false);
			stage.getIcons().add(new Image(getClass().getResourceAsStream("../files/logochef.jpg")));
			Scene scene = new Scene(root);
			scene.setFill(Color.TRANSPARENT);
			stage.setScene(scene);
			scene.setCursor(new ImageCursor(image));
			stage.centerOnScreen();
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
