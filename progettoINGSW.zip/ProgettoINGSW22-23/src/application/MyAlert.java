package application;

import controllers.ExtendedController;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextInputDialog;
import javafx.scene.paint.Color;
import javafx.stage.StageStyle;

public class MyAlert {
	Alert alert;
	
	public MyAlert()  {
		alert = new Alert(AlertType.NONE);
		setAll();
	}

	private void setAll() {
		alert.initStyle(StageStyle.TRANSPARENT);
		alert.setGraphic(null);
		alert.setHeaderText(null);
		alert.setResizable(false);
		alert.getDialogPane().getScene().setFill(Color.TRANSPARENT);
		alert.getDialogPane().getStylesheets().add(getClass().getResource("../styleSheet/StyleAlert.css").toExternalForm());
	}

	public Alert alertlog(String text) {
		alert = new Alert(AlertType.CONFIRMATION);
		setAll();
		alert.initOwner(ExtendedController.getPane().getScene().getWindow());
		alert.setContentText(text);
		return alert;
	}
	
	public Alert askNewPassword() {
		alert = new Alert(AlertType.CONFIRMATION);
		setAll();
		alert.setContentText("Benvenuto, siamo orgogliosi di farti entrare a far parte famiglia di Ratatouille23. Prima di entrare, vuoi resettare la password?");
		return alert;
	}
	
	public String setNewPassword() {
		TextInputDialog dialog = new TextInputDialog();
		dialog.initStyle(StageStyle.TRANSPARENT);
		dialog.setGraphic(null);
		dialog.setHeaderText(null);
		dialog.setResizable(false);
		dialog.getDialogPane().lookupButton(ButtonType.CANCEL).setVisible(false);;
		dialog.getDialogPane().getScene().setFill(Color.TRANSPARENT);
		dialog.getDialogPane().getStylesheets().add(getClass().getResource("../styleSheet/StyleAlert.css").toExternalForm());
		dialog.setContentText("Imposta la nuova password");
		
		String newPass;
		while(true) {
			newPass = dialog.showAndWait().get();
			if(newPass.isBlank()) {
				alertlog("Inserire la password correttamente").showAndWait();
			} else
				break;
		}
		alertlog("Password settata con successo").showAndWait();
		return newPass;
	}

	public void notifyAdd() {
		//se l'ingrediente gia esiste alertType.Warning altrimenti alertType.Info
	}

	public void notifyAddQt() {
		//aggiunta quantit� all'ingrediente selezionato
	}
	
}
