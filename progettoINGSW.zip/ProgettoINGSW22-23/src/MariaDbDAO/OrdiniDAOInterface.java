package MariaDbDAO;

import java.sql.ResultSet;

public interface OrdiniDAOInterface {
	ResultSet InserisciOrdine(double costOrdine, int prodID, int tavoloID) throws Exception;

	ResultSet RimuoviOrdine(int id) throws Exception;

	ResultSet UpdateOrdini(int costOrdine, int costoNuovo) throws Exception;

	ResultSet ListaOrdini() throws Exception;

	ResultSet ListaOrdiniSpecifica(int id, int comboBoxChoice) throws Exception;

	ResultSet IdProdottiOrdine() throws Exception;

	ResultSet CountOrdinazioniTavolo(int idTavolo) throws Exception;
}
