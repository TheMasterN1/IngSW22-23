package MariaDbDAO;

import java.sql.ResultSet;

public interface OrdiniDAOInterface {
	ResultSet RimuoviOrdine(int id) throws Exception;

	ResultSet UpdateOrdini(int costOrdine, int costoNuovo) throws Exception;

	ResultSet ListaOrdini() throws Exception;

	ResultSet ListaOrdiniSpecifica(int id, int comboBoxChoice) throws Exception;

	ResultSet IdProdottiOrdine() throws Exception;

	ResultSet CountOrdinazioniTavolo(int idTavolo) throws Exception;

	ResultSet InserisciOrdinazione(String nome, int quantita, int tavoloID) throws Exception;

	ResultSet ListaOrdiniPerTavolo(int tavoloID) throws Exception;
}
