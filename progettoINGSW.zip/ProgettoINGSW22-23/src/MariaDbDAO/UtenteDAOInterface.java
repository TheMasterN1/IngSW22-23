package MariaDbDAO;

import java.sql.ResultSet;

public interface UtenteDAOInterface {
	ResultSet InserisciUtente(String username, String password, String ruolo, Integer IDSala)
			throws Exception;

	ResultSet RimuoviUtente(String nome) throws Exception;

	ResultSet ListaUtente(String nome, String pass) throws Exception;

	int UpdateUtente(int id, String username, String password, String ruolo, Integer IDSala)
			throws Exception;

	 ResultSet IDListaUtenti()throws Exception;
}
