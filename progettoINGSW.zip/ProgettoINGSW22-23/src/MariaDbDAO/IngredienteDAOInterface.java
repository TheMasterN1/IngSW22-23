package MariaDbDAO;

import java.sql.ResultSet;

public interface IngredienteDAOInterface {
	ResultSet InserisciIngrediente(String nome, int quantita) throws Exception;

	ResultSet RimuoviIngrediente(int nome) throws Exception;

	ResultSet UpdateIngredienti(int id_plu,String nome, int quantita) throws Exception;

	ResultSet ListaIngredienti() throws Exception;

	ResultSet ListaIngredientiSpecifica(String prodotto) throws Exception;
}
