package MariaDbDAO;

import application.dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UtenteDAO implements UtenteDAOInterface {

	@Override
	public ResultSet InserisciUtente(String username, String password, String ruolo, Integer IDSala)
			throws Exception {
		Connection con = null;
		String sql = "Insert into utente(username, password, ruolo, IDsala, nuovoUtente) VALUES(?,?,?,?,?)";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, username);
		p1.setString(2, password);
		p1.setString(3, ruolo);
		p1.setInt(4, IDSala);
		p1.setString(5, "Y");
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public int UpdateUtente(int id, String username, String password, String ruolo, Integer IDSala)
			throws Exception {
		Connection con = null;
		String sql = "Update utente set username=?, password=?, ruolo=?, nuovoUtente=? where utente.id= ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, username);
		p1.setString(2, password);
		p1.setString(3, ruolo);
		p1.setString(4, "N");
		p1.setInt(5, id);
		int rs1 = p1.executeUpdate();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet RimuoviUtente(String nome) throws Exception {
		Connection con = null;
		String sql = "delete from utente where utente.username = ? ";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, nome);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet ListaUtente(String nome, String pass) throws Exception {
		Connection con = null;
		String sql = "select * from utente where username = ? AND password = ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, nome.trim());
		p1.setString(2, pass.trim());
		ResultSet rs1 = p1.executeQuery();
		rs1.beforeFirst();
		con.close();
		return rs1;
	}

	public ResultSet IDListaUtenti() throws Exception{
		Connection con = null;
		String sql = "select id from utente";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}
}
