package MariaDbDAO;

import java.sql.ResultSet;

public interface NotificheDAOInterface {
	ResultSet InserisciMessaggio(int id, String oggetto, String testo, int idUtente) throws Exception;

	ResultSet inserimentoMessaggioPerVisualizzazione(int idUtente, int idNotifica) throws Exception;

	ResultSet RimuoviMessaggio(int id) throws Exception;

	ResultSet RimuoviMessaggioVisualizzazione(int id) throws Exception;

	ResultSet UpdateTestoMessaggio(int id, int idUtente, String oggetto, String testo) throws Exception;

	ResultSet ListaMessaggi() throws Exception;

	ResultSet ListaMessaggiSpecifici(int idUtente) throws Exception;

	ResultSet UpdateVisualizzazione(int idUtente, int idNotifiche) throws Exception ;

	ResultSet MaxIDMessaggi() throws Exception;
	
	ResultSet CheckVisualizzato(int idUtente, int idNotifiche) throws Exception;

	ResultSet CheckDaVisualizzare(int idUtente) throws Exception;
}
