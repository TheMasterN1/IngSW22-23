package MariaDbDAO;

import application.dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MenuDAO implements MenuDAOInterface {
	@Override
	public ResultSet InserisciMenu(int menuID, int prodID) throws Exception {
		Connection con = null;
		String sql = "Insert into menu VALUES(?,?)";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, menuID);
		p1.setInt(2, prodID);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet RimuoviMenu(int id) throws Exception {
		Connection con = null;
		String sql = "delete from menu where menu.menuID=? ";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, id);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet UpdateMenu(int prodID, int menuID) throws Exception {
		Connection con = null;
		String sql = "Update menu set prodottoID=? where menu.menuID= ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, prodID);
		p1.setInt(2, menuID);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet ListaMenu() throws Exception {
		Connection con = null;
		String sql = "select * from menu";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}
}
