package MariaDbDAO;

import java.sql.ResultSet;

public interface ProdottoDAOInterface {
	ResultSet InserisciProdotto(float costo, String nome, String allergeni, String descrizione, int quantita,
			String categoria) throws Exception;

	ResultSet RimuoviProdotto(int id) throws Exception;

	ResultSet UpdateProdotti(String nome, int quantita) throws Exception;

	ResultSet ListaProdotti() throws Exception;

	ResultSet ListaProdotti_specifica(String nome, String comboBoxChoice) throws Exception;
}
