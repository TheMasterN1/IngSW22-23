package MariaDbDAO;

import java.sql.ResultSet;

public interface ProdottoDAOInterface {
	ResultSet RimuoviProdotto(int id) throws Exception;

	ResultSet UpdateProdotti(String nome, int quantita) throws Exception;

	ResultSet ListaProdotti() throws Exception;

	ResultSet InserisciRicetta(String prodotto, String ingrediente, Integer quantita) throws Exception;

	ResultSet ListaProdottiPerNome(String nome) throws Exception;

	ResultSet ListaProdotti_specifica(String nome) throws Exception;

	ResultSet InserisciProdotto(float costo, String nome, String allergeni, String descrizione, String categoria)
			throws Exception;
}
