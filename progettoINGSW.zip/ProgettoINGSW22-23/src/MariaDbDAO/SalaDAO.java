package MariaDbDAO;

import application.dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class SalaDAO implements SalaDAOInterface {

	@Override
	public ResultSet InserisciSala(int salaID, int quantitaTavoli, int tavoloID) throws Exception {
		Connection con = null;
		String sql = "Insert into sala VALUES(?,?,?)";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, salaID);
		p1.setInt(2, quantitaTavoli);
		p1.setInt(3, tavoloID);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet RimuoviSala(int id) throws Exception {
		Connection con = null;
		String sql = "delete from sala where sala.salaID=? ";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, id);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet ListaSala(int salaID) throws Exception {
		Connection con = null;
		String sql = "select * from sala where sala.salaID=?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, salaID);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet GetAllSale() throws Exception {
		Connection con = null;
		String sql = "select salaID from sala";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}
}
