package MariaDbDAO;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import application.dbConnection;

public class ProdottoDAO implements ProdottoDAOInterface {

	@Override
	public ResultSet InserisciProdotto(float costo, String nome, String allergeni, String descrizione, int quantita,
			String categoria) throws Exception {
		Connection con = null;
		String sql = "Insert into prodotto(costo, nome, descrizione, quantita, categoria, allergeni) VALUES(?,?,?,?,?,?)";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setFloat(1, costo);
		p1.setString(2, nome);
		p1.setString(3, descrizione);
		p1.setInt(4, quantita);
		p1.setString(5, categoria);
		p1.setString(6, allergeni.substring(1, allergeni.length()-1));

		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet RimuoviProdotto(int id) throws Exception {
		Connection con = null;
		String sql = "delete from prodotto where prodottoID=? ";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, id);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet UpdateProdotti(String nome, int quantita) throws Exception {
		Connection con = null;
		String sql = "Update prodotto set quantita=? where prodotto.nome= ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, quantita);
		p1.setString(2, nome);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet ListaProdotti() throws Exception {
		Connection con = null;
		String sql = "select * from prodotto";
		try {
			con = dbConnection.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		PreparedStatement p1 = con.prepareStatement(sql);
		ResultSet rs1 = p1.executeQuery();
		con.close();

		return rs1;
	}

	@Override
	public ResultSet ListaProdotti_specifica(String nome, String comboBoxChoice) throws Exception {
		Connection con = null;
		String sql="";
		ResultSet rs1 =null;
		try {
			con = dbConnection.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(nome.length()>0) {
			sql = "select * from prodotto WHERE prodotto.nome=?";
		}

		if(sql.length()>0){
			if(comboBoxChoice.length()>0) {
				sql = sql + " AND prodotto.categoria=?";
				PreparedStatement p1 = con.prepareStatement(sql);
				p1.setString(1, nome);
				p1.setString(2, comboBoxChoice);
				rs1 = p1.executeQuery();
			}
			else{
				PreparedStatement p1 = con.prepareStatement(sql);
				p1.setString(1, nome);
				rs1 = p1.executeQuery();
			}
		}
		else{
			sql = "select * from prodotto WHERE prodotto.categoria=?";
			PreparedStatement p1 = con.prepareStatement(sql);
			p1.setString(1, comboBoxChoice);
			 rs1 = p1.executeQuery();
		}
		con.close();

		return rs1;
	}

}
