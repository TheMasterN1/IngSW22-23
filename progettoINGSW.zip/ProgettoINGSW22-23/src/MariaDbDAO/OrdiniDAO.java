package MariaDbDAO;

import application.dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class OrdiniDAO implements OrdiniDAOInterface {

	@Override
	public ResultSet InserisciOrdine(double costOrdine, int prodID, int tavoloID) throws Exception {
		Connection con = null;
		String sql = "INSERT INTO ordine (costoOrdine,prodId,tavoloID) VALUES(?,?,?)";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setDouble(1, costOrdine);
		p1.setInt(2, prodID);
		p1.setInt(3, tavoloID);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet RimuoviOrdine(int id) throws Exception {
		Connection con = null;
		String sql = "delete from ordine where ordine.ordineId=? ";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, id);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet UpdateOrdini(int costOrdine, int costoNuovo) throws Exception {
		Connection con = null;
		String sql = "Update ordine set costoOrdine=? where ordine.costoOrdine= ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, costoNuovo);
		p1.setInt(2, costOrdine);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet ListaOrdini() throws Exception {
		Connection con = null;
		String sql = "select * from ordine";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet IdProdottiOrdine() throws Exception {
		Connection con = null;
		String sql = "select prodottoID from ordinazione";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet CountOrdinazioniTavolo(int idTavolo) throws Exception {
		Connection con = null;
		String sql = "select costoOrdine from ordine where tavoloID=?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, idTavolo);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet ListaOrdiniSpecifica(int id, int comboBoxChoice) throws Exception {
		Connection con = null;
		String sql="";
		ResultSet rs1 =null;
		try {
			con = dbConnection.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(id>0) {
			sql = "select * from ordine WHERE ordine.ordineId=?";
		}

		if(sql.length()>0){
			if(comboBoxChoice>0) {
				sql = sql + " AND ordine.prodId=?";
				PreparedStatement p1 = con.prepareStatement(sql);
				p1.setInt(1, id);
				p1.setInt(2, comboBoxChoice);
				rs1 = p1.executeQuery();
			}
			else{
				PreparedStatement p1 = con.prepareStatement(sql);
				p1.setInt(1, id);
				rs1 = p1.executeQuery();
			}
		}
		else{
			sql = "select * from ordine WHERE ordine.prodId=?";
			PreparedStatement p1 = con.prepareStatement(sql);
			p1.setInt(1, comboBoxChoice);
			rs1 = p1.executeQuery();
		}
		con.close();

		return rs1;
	}

	public void RimuoviOrdinazioni(int chosen_table) throws Exception {
		Connection con = null;
		String sql = "delete from ordinazione where tavoloID = ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, chosen_table);
		p1.executeQuery();
		con.close();
	}
}