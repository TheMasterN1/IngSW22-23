package MariaDbDAO;

import application.dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class NotificheDAO implements NotificheDAOInterface {
	@Override
	public ResultSet InserisciMessaggio(int id, String oggetto, String testo, int idUtente) throws Exception {
		Connection con = null;
		String sql = "Insert into bacheca(IDnotifica,oggetto, testo, IDutente) VALUES(?,?,?,?)";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1,id);
		p1.setString(2, oggetto);
		p1.setString(3, testo);
		p1.setInt(4, idUtente);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	public ResultSet inserimentoMessaggioPerVisualizzazione(int idUtente, int idNotifica) throws Exception{
		Connection con = null;
		String sql = "INSERT  into visualizzazione(ID, IDnotifica, visualizzato) SELECT ?,?,? WHERE NOT EXISTS(Select ID, IDnotifica from visualizzazione where visualizzazione.ID = ? AND visualizzazione.IDnotifica = ?)";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, idUtente);
		p1.setInt(2, idNotifica);
		p1.setInt(3, 0);
		p1.setInt(4, idUtente);
		p1.setInt(5, idNotifica);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet RimuoviMessaggio(int id) throws Exception {
		Connection con = null;
		String sql = "delete from bacheca where bacheca.IDnotifica=? ";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, id);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	public ResultSet RimuoviMessaggioVisualizzazione(int id) throws Exception {
		Connection con = null;
		String sql = "delete from visualizzazione where visualizzazione.IDnotifica=? ";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, id);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}



	@Override
	public ResultSet ListaMessaggi() throws Exception {
		Connection con = null;
		String sql = "select * from bacheca";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet ListaMessaggiSpecifici(int idUtente) throws Exception {
		Connection con = null;
		String sql = "select bacheca.IDnotifica, bacheca.oggetto, bacheca.testo from bacheca";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, idUtente);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}



	public ResultSet MaxIDMessaggi()throws Exception{
		Connection con = null;
		String sql = "select IDnotifica from bacheca";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet UpdateTestoMessaggio(int id, int idUtente, String oggetto, String testo) throws Exception {
		Connection con = null;
		String sql = "Update bacheca set oggetto=? AND testo=?   where bacheca.IDnotifica= ? AND bacheca.IDutente = ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, oggetto);
		p1.setString(2, testo);
		p1.setInt(3, id);
		p1.setInt(4, idUtente);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet UpdateVisualizzazione(int idUtente, int idNotifiche) throws Exception {
		Connection con = null;
		String sql = "update visualizzazione set visualizzato = ?  where ID = ? AND IDnotifica=?";

		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, "Y");
		p1.setInt(2, idUtente);
		p1.setInt(3, idNotifiche);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet CheckVisualizzato(int idUtente, int idNotifiche) throws Exception {
		Connection con = null;
		String sql = "Select visualizzato from visualizzazione where ID = ? AND IDnotifica=?";

		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, idUtente);
		p1.setInt(2, idNotifiche);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}
	
	@Override
	public ResultSet CheckDaVisualizzare(int idUtente) throws Exception {
		Connection con = null;
		String sql = "Select Count(*) from visualizzazione where ID = ? AND visualizzato=?";

		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, idUtente);
		p1.setString(2, "N");
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

}
