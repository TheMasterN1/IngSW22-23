package dto;

public class Ingrediente {

    String nome;

    int ingredienteId;

    int quantita;
    
    public Ingrediente(String nome, int ingredienteId, int quantita) {
		super();
		this.nome = nome;
		this.ingredienteId = ingredienteId;
		this.quantita = quantita;
	}

	public Ingrediente() {}

	public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIngredienteId() {
        return ingredienteId;
    }

    public void setIngredienteId(int ingredienteId) {
        this.ingredienteId = ingredienteId;
    }

    public int getQuantita() {
        return quantita;
    }

    public void setQuantita(int quantita) {
        this.quantita = quantita;
    }
}
