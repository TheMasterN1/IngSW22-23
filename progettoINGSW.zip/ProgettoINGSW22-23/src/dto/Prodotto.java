package dto;

public class Prodotto {
    float costo;
    String name;
    String allergeni;
    String descrizione;
    String categoria;
    int prodottoID;
    int quantita;

    public Prodotto(float costo, String name, String allergeni, String descrizione, int prodottoID, int quantita){
        this.costo = costo;
        this.name = name;
        this.allergeni = allergeni;
        this.descrizione=descrizione;
        this.prodottoID = prodottoID;
        this.quantita = quantita;
    }

    public Prodotto(){}

	public float getCosto() {
        return costo;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAllergeni() {
        return allergeni;
    }

    public void setAllergeni(String allergeni) {
        this.allergeni = allergeni;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public int getProdottoID() {
        return prodottoID;
    }

    public void setProdottoID(int prodottoID) {
        this.prodottoID = prodottoID;
    }

    public int getQuantita() {
        return quantita;
    }

    public void setQuantita(int quantita) {
        this.quantita = quantita;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

}
