package dto;

public class Notifiche {
    int IDnotifiche;
    String oggetto;
    String testo;
    int idUtente;


    public Notifiche(int IDnotifiche, String oggetto, String testo, int idUtente){
        this.IDnotifiche = IDnotifiche;
        this.oggetto=oggetto;
        this.testo = testo;
        this.idUtente = idUtente;
    }

    public int getIDnotifiche() {
        return IDnotifiche;
    }

    public void setIDnotifiche(int IDnotifiche) {
        this.IDnotifiche = IDnotifiche;
    }

    public String getOggetto() {
        return oggetto;
    }

    public void setOggetto(String oggetto) {
        this.oggetto = oggetto;
    }

    public String getTesto() {
        return testo;
    }

    public void setTesto(String testo) {
        this.testo = testo;
    }

    public int getIdUtente() {
        return idUtente;
    }

    public void setIdUtente(int idUtente) {
        this.idUtente = idUtente;
    }
}
