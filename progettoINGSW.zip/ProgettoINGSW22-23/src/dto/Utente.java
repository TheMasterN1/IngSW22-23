package dto;

public class Utente {
    String username;
    String password;
    int id;
    String ruolo;
    Integer idSala;

    public Utente(String username, String password, int id, String ruolo, Integer idSala){
        this.username = username;
        this.password = password;
        this.id = id;
        this.ruolo = ruolo;
        this.idSala = idSala;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRuolo() {
        return ruolo;
    }

    public void setRuolo(String ruolo) {
        this.ruolo = ruolo;
    }

    public int getIdSala() {
        return idSala;
    }

    public void setIdSala(int idSala) {
        this.idSala = idSala;
    }
}
