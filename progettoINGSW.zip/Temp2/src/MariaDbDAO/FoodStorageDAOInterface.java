package MariaDbDAO;

import java.sql.ResultSet;

public interface FoodStorageDAOInterface {
	int InserisciProdotto(float costo, String nome, String allergeni, String descrizione, int quantita,
			String categoria) throws Exception;

	ResultSet RimuoviProdotto(String nome) throws Exception;

	ResultSet UpdateProdotti(String nome, int quantita) throws Exception;

	ResultSet ListaProdotti(String nome) throws Exception;
}
