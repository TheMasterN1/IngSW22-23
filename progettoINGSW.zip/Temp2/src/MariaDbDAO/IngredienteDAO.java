package MariaDbDAO;

import application.dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class IngredienteDAO implements IngredienteDAOInterface {

	@Override
	public ResultSet InserisciIngrediente(String nome, int ingredienteID, int quantita, int prodID) throws Exception {
		Connection con = null;
		String sql = "Insert into ingrediente VALUES(?,?,?,?)";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, nome);
		p1.setInt(2, ingredienteID);
		p1.setInt(3, quantita);
		p1.setInt(4, prodID);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet RimuoviIngrediente(String nome) throws Exception {
		Connection con = null;
		String sql = "delete from ingrediente where ingrediente.nome=? ";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, nome);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet UpdateIngredienti(String nome, int quantita) throws Exception {
		Connection con = null;
		String sql = "Update ingrediente set quantita=? where ingrediente.nome= ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, quantita);
		p1.setString(2, nome);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet ListaIngredienti(String nome) throws Exception {
		Connection con = null;
		String sql = "select * from ingrediente";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet ListaIngredientiSpecifica(int prodotto) throws Exception {
		Connection con = null;
		String sql = "select * from ingrediente where ingrediente.prodotID=?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, prodotto);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}
}
