package MariaDbDAO;

import application.dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

public class UtenteDAO implements UtenteDAOInterface {

	@Override
	public ResultSet InserisciUtente(String username, String password, Integer id, String ruolo, Integer IDSala)
			throws Exception {
		Connection con = null;
		String sql = "Insert into utente VALUES(?,?,?,?,?)";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, username);
		p1.setString(2, username);
		p1.setObject(3, id, Types.INTEGER);
		p1.setString(4, ruolo);
		p1.setObject(5, IDSala, Types.INTEGER);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet RimuoviUtente(String nome) throws Exception {
		Connection con = null;
		String sql = "delete from utente where utente.username = ? ";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, nome);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet ListaUtente(String nome) throws Exception {
		Connection con = null;
		String sql = "select * from utente";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		ResultSet rs1 = p1.executeQuery();
		while (rs1.next()) {
			System.out.println("" + rs1.getString(1));
		}
		con.close();
		return rs1;
	}

	@Override
	public ResultSet ListaUtenteAdmin(String nome) throws Exception {
		Connection con = null;
		String sql = "select * from utente where utente.username = ? AND utente.ruolo = ? ";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, nome.trim());
		p1.setString(2, "Amministratore".trim());
		ResultSet rs1 = p1.executeQuery();
		/*
		 * while(rs1.next()){ System.out.println(""+rs1.getString(1)); }
		 */
		con.close();
		return rs1;
	}

	@Override
	public ResultSet ListaUtenteNonAdmin(String nome) throws Exception {
		Connection con = null;
		String sql = "select * from utente where utente.username = ? AND utente.ruolo <> ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, nome.trim());
		p1.setString(2, "Amministratore".trim());
		ResultSet rs1 = p1.executeQuery();
		rs1.beforeFirst();
		// if(rs1.next()){
		// System.out.println(""+rs1.getString(1));
		// }
		con.close();
		return rs1;
	}
}
