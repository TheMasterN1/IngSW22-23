package MariaDbDAO;

import java.sql.ResultSet;

public interface UtenteDAOInterface {
	ResultSet InserisciUtente(String username, String password, Integer id, String ruolo, Integer IDSala)
			throws Exception;

	ResultSet RimuoviUtente(String nome) throws Exception;

	ResultSet ListaUtente(String nome) throws Exception;

	ResultSet ListaUtenteAdmin(String nome) throws Exception;

	ResultSet ListaUtenteNonAdmin(String nome) throws Exception;
}
