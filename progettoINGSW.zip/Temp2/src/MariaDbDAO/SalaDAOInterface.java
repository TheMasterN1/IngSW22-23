package MariaDbDAO;

import java.sql.ResultSet;

public interface SalaDAOInterface {
	ResultSet InserisciSala(int salaID, int quantitaTavoli, int tavoloID) throws Exception;

	ResultSet RimuoviSala(int id) throws Exception;

	ResultSet ListaSala(int salaID) throws Exception;
}
