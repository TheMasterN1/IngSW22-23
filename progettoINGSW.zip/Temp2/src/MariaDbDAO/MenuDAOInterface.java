package MariaDbDAO;

import java.sql.ResultSet;

public interface MenuDAOInterface {
	ResultSet InserisciMenu(int menuID, int prodID) throws Exception;

	ResultSet RimuoviMenu(int id) throws Exception;

	ResultSet UpdateMenu(int prodID, int menuID) throws Exception;

	ResultSet ListaMenu() throws Exception;
}
