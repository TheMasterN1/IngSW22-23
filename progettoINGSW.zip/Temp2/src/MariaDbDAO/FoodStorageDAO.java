package MariaDbDAO;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import application.dbConnection;

public class FoodStorageDAO implements FoodStorageDAOInterface {

	@Override
	public int InserisciProdotto(float costo, String nome, String allergeni, String descrizione, int quantita,
			String categoria) throws Exception {
		Connection con = null;
		String sql = "Insert into prodotto VALUES(?,?,?,?,?,?,?)";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setFloat(1, costo);
		p1.setString(2, nome);
		p1.setString(3, allergeni);
		p1.setString(4, descrizione);
		p1.setInt(5, 12355);
		p1.setInt(6, quantita);
		p1.setString(7, categoria);

		int rs1 = p1.executeUpdate();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet RimuoviProdotto(String nome) throws Exception {
		Connection con = null;
		String sql = "delete from prodotto where prodotto.nome=? ";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, nome);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet UpdateProdotti(String nome, int quantita) throws Exception {
		Connection con = null;
		String sql = "Update prodotto set quantita=? where prodotto.nome= ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, quantita);
		p1.setString(2, nome);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet ListaProdotti(String nome) throws Exception {
		Connection con = null;
		String sql = "select * from prodotto";
		try {
			con = dbConnection.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		PreparedStatement p1 = con.prepareStatement(sql);
		ResultSet rs1 = p1.executeQuery();

		// while (rs1.next()) {
		// String val1 = rs1.getString(2); // by column index
		// ... use val1 and val2 ...
		// }

		con.close();

		return rs1;
	}

}
