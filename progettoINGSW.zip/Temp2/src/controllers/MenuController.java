package controllers;

import java.io.IOException;

import application.AlertClass;
import application.CustomButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.layout.Pane;

public class MenuController extends ExtendedController {

	AlertClass alertClass = new AlertClass();
	MainController controller = new MainController();
	@FXML private Pane pane;
	@FXML private CustomButton addButton;

	@FXML
	public void initialize() {
		if(!isAdmin)
			pane.getChildren().remove(addButton);
	}
	
	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "HomePageScene");
	}

	@FXML
	public void backAdmin(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "HomePageAdminScene");
	}
	
	@FXML
	public void addDish(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "AddDishMenuScene");
	}
	
	@FXML
	public void cancelAdd(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "MenuAdminScene");
	}

	@FXML
	public void confirmAdd(ActionEvent event) throws IOException, InterruptedException {
		alertClass.notifyAdd();
		controller.changeScene(event, "MenuAdminScene");
	}
	
}
