package controllers;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import MariaDbDAO.FoodStorageDAO;
import application.AlertClass;
import application.CustomButton;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.util.Callback;

public class FoodStorageController extends ExtendedController{

	MainController controller = new MainController();
	private AlertClass alertClass = new AlertClass();
	@FXML private Pane pane;
	@FXML private CustomButton addButton;

	@FXML
	private TableView<ObservableList> tableMagazzino = new TableView<ObservableList>();
	private ObservableList<String> data;

	FoodStorageDAO foodStorageDAO = new FoodStorageDAO();
	

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "HomePageScene");
	}

	@FXML
	public void addIngredient(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "AddIngredientScene");
	}

	@FXML
	public void removeIngredient(ActionEvent event) throws IOException, InterruptedException {
		if (alertClass.alertRemoving("Rimuovere l'ingrediente //getingredienteselezionato ?").showAndWait()
				.get() == ButtonType.OK)
			controller.changeScene(event, "FoodStorageAdminScene");
	}

	@FXML
	public void cancelAdd(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "FoodStorageAdminScene");
	}

	@FXML
	public void confirmAdd(ActionEvent event) throws IOException, InterruptedException {
		alertClass.notifyAdd();
		controller.changeScene(event, "FoodStorageAdminScene");
	}
	
	private void addQtIngredient(ActionEvent event) throws IOException, InterruptedException  {
		alertClass.notifyAddQt();
		controller.changeScene(event, "FoodStorageAdminScene");
	}

	@FXML
	public void initialize() {
//		try {
//			foodStorageDAO.InserisciProdotto(15, "no", "als", "mso", 12, "Antipasto");
//		} catch (Exception e) {
//			e.printStackTrace();
//		}

		buildData();
		
		if(!isAdmin)
			pane.getChildren().remove(addButton);

	}

	public void rightClickEvent(MouseEvent event) {
		ContextMenu menu = new ContextMenu();
		MenuItem remove = new MenuItem("Rimuovi");
		MenuItem modify = new MenuItem("Modifica");
		menu.getItems().addAll(remove, modify);
		
		remove.setOnAction(e -> {
			try {removeIngredient(e);} catch (IOException e1) {} 
			catch (InterruptedException e1) {}
        });
		
		modify.setOnAction(e -> {
			try {addQtIngredient(e);} catch (IOException e1) {} 
			catch (InterruptedException e1) {}
        });
		
		tableMagazzino.setContextMenu(menu);
	}

	@FXML
	public void buildData() {
		data = FXCollections.observableArrayList();
		ResultSet rs;
		try {
			rs = controller.foodStorageDAO.ListaProdotti("");
			ObservableList<ObservableList> data = FXCollections.observableArrayList();

			tableMagazzino.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);
			for (int i = 0; i < rs.getMetaData().getColumnCount(); i++) {

				final int j = i;
				TableColumn col = new TableColumn(rs.getMetaData().getColumnName(i + 1));
				col.setCellValueFactory((Callback<TableColumn.CellDataFeatures<ObservableList, String>, ObservableValue<String>>) param -> {
					if (param.getValue().get(j) != null) {
						return new SimpleStringProperty(param.getValue().get(j).toString());
					} else {
						return null;
					}
				});

				tableMagazzino.getColumns().addAll(col);
				//     this.columnNames.add(col.getText());
			}

			while (rs.next()) {
				//Iterate Row
				ObservableList<String> row = FXCollections.observableArrayList();
				for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
					//Iterate Column
					row.add(rs.getString(i));
				}
				data.add(row);

			}

			//FINALLY ADDED TO TableView
			tableMagazzino.setItems(data);
		} catch (SQLException ex) {
			throw new RuntimeException(ex);
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
		//   }
		// System.out.println("Row [1] added "+row );
		//data.add(row);

		// }

		//FINALLY ADDED TO TableView
		// tableMagazzino.setItems(data);

	}

}
