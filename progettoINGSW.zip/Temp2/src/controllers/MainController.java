package controllers;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import MariaDbDAO.*;
import application.AlertClass;
import application.dbConnection;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.ImageCursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class MainController extends ExtendedController {
	
	dbConnection db = new dbConnection();
	
	@FXML private TextField usertext;
	@FXML private PasswordField passwordtext;
	
	private AlertClass alertClass = new AlertClass();
	
	FoodStorageDAO foodStorageDAO = new FoodStorageDAO();
	IngredienteDAO ingredienteDAO = new IngredienteDAO();
	MenuDAO menuDAO = new MenuDAO();
	OrdiniDAO ordiniDAO = new OrdiniDAO();
	SalaDAO salaDAO = new SalaDAO();
	TavoloDAO tavoloDAO = new TavoloDAO();
	UtenteDAO utenteDAO = new UtenteDAO();

	@FXML
	public void close(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.hide();
	}

	public void changeScene(ActionEvent event, String scenestring) throws IOException, InterruptedException {
		Image waitmouse = new Image(getClass().getResourceAsStream("../files/cooking-pot.png"));
		Image mouse = new Image(getClass().getResourceAsStream("../files/mitten.png"));
		FXMLLoader loader = new FXMLLoader(getClass().getResource("../scenes/" + scenestring + ".fxml"));
		Parent root = loader.load();

		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.setResizable(false);
		stage.getIcons().add(new Image(getClass().getResourceAsStream("../files/logochef.jpg")));

		Scene scene = new Scene(root);
		scene.setCursor(new ImageCursor(waitmouse));
		scene.setFill(Color.TRANSPARENT);
		stage.setScene(scene);
		stage.centerOnScreen();
		stage.show();

		
		new Thread(new Runnable() {
			public void run() {
				Platform.runLater(new Runnable() {
					public void run() {
						try {
							Thread.sleep(600);
							scene.setCursor(new ImageCursor(mouse));
						} catch (InterruptedException e) {
						}
					}
				});
			}
		}).start();

	}

	public String getTime(Locale local) {
		SimpleDateFormat sdf = new SimpleDateFormat("EEEE d MMMM yyyy HH:mm:ss", local);
		Date now = new Date();
		String strDate = sdf.format(now);
		return strDate;
	}

	@FXML
	public void checkLog(ActionEvent event) throws IOException, InterruptedException {
		try {
			if (utenteDAO.ListaUtenteAdmin(usertext.getText()).next()) {
				setIsAdmin(true);
				changeScene(event, "HomePageScene");
			} else if (usertext.getText().equals("admin") && passwordtext.getText().equals("admin")) {
				setIsAdmin(true);
				changeScene(event, "HomePageScene");
			} else if (utenteDAO.ListaUtenteNonAdmin(usertext.getText()).next()) {
				setIsAdmin(false);
				changeScene(event, "HomePageScene");
			} else {
				alertClass.alertlog("Wrong Username/Password").show();
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

}
