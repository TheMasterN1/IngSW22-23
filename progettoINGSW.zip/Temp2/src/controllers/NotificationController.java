package controllers;

import java.io.IOException;

import application.CustomButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.layout.Pane;

public class NotificationController extends ExtendedController {

	MainController controller = new MainController();
	@FXML private Pane pane;
	@FXML private CustomButton addButton;

	@FXML
	public void initialize() {
		if(!isAdmin)
			pane.getChildren().remove(addButton);
	}

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "HomePageScene");
	}

	@FXML
	public void create(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "SendNotificationScene");
	}
	
	@FXML
	public void cancel(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "NotificationScene");
	}
	
	@FXML
	public void send(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "NotificationScene");
	}
}
