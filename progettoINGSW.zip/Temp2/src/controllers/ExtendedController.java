package controllers;

public abstract class ExtendedController {
	protected static boolean isAdmin;
	
	public void setIsAdmin(boolean admin) {
		ExtendedController.isAdmin = admin;
	}
}
