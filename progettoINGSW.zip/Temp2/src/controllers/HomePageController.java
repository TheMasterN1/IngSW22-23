package controllers;

import java.io.IOException;
import java.util.Locale;

import application.CustomButton;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.util.Duration;

public class HomePageController extends ExtendedController {

	private MainController controller = new MainController();

	@FXML private Label datetime;
	@FXML private Label countLabel;
	@FXML private Pane image;
	@FXML private CustomButton dipendentButton;
	
	@FXML
	public void initialize() {
		if(isAdmin)
			image.getChildren().remove(countLabel);
		else
			image.getChildren().remove(dipendentButton);
	}

	public HomePageController() {
		KeyFrame update = new KeyFrame(Duration.seconds(1.0), event -> {
			datetime.setText(controller.getTime(Locale.ITALY));
		});
		Timeline timeline = new Timeline(update);
		timeline.setCycleCount(Animation.INDEFINITE);
		timeline.play();
	}

	@FXML
	private void register(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "RegisterDipendentScene");
	}
	
	@FXML
	private void seeProfile(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "ProfileScene");
	}

	@FXML
	public void logout(ActionEvent event) throws IOException, InterruptedException {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Logout");
		alert.setHeaderText("Stai per disconnetterti");
		alert.setContentText("Vuoi disconnetterti?");
		if (alert.showAndWait().get() == ButtonType.OK) {
			controller.changeScene(event, "LoginScene");
		}
	}

	@FXML
	public void openNotify(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "NotificationScene");
	}

	@FXML
	public void seeFood(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "FoodStorageScene");
	}
	
	@FXML
	public void seeMenu(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "MenuScene");
	}
	
	@FXML
	public void seeOrders(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "OrdersScene");
	}
	
	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "HomePageScene");
	}

}
