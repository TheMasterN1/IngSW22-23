package controllers;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;

public class OperationController extends ExtendedController {

	private MainController controller = new MainController();
	@FXML private Pane pane;
	@FXML private Label sala;
	@FXML private ChoiceBox<?> choicesala;
	
	@FXML
	public void initialize() {
		pane.getChildren().remove(sala);
		pane.getChildren().remove(choicesala);
	}
	
	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "HomePageScene");
	}
}
