package application;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class AlertClass {
	
	

	public void alertlog() {
		Alert alert = new Alert(AlertType.WARNING);
		alert.setContentText("Wrong Username/Password");
		alert.show();
	}

}
