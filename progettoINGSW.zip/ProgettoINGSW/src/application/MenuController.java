package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class MenuController {

	MainController controller = new MainController();

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "HomePageScene");
	}
	
	@FXML
	public void backAdmin(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "HomePageAdminScene");
	}
}
