package application;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.ImageCursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class MainController {

	@FXML private Button exit, register, login;
	@FXML private TextField usertext;
	@FXML private PasswordField passwordtext;
	private AlertClass alertClass = new AlertClass();

	@FXML
	public void close(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.hide();
	}
	

	public void changeScene(ActionEvent event, String scenestring) throws IOException, InterruptedException {
		Image waitmouse = new Image(getClass().getResourceAsStream("../files/cooking-pot.png"));
		Image mouse = new Image(getClass().getResourceAsStream("../files/blackspatula.png"));		
		Parent root = FXMLLoader.load(getClass().getResource("../scenes/" + scenestring + ".fxml"));
		
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.setResizable(false);
		stage.getIcons().add(new Image(getClass().getResourceAsStream("../files/logochef.jpg")));
		
		Scene scene = new Scene(root);
		scene.setCursor(new ImageCursor(waitmouse));
		scene.setFill(Color.TRANSPARENT);
		stage.setScene(scene);
		stage.centerOnScreen();
		stage.show();
		
		new Thread(new Runnable() {
		    public void run() {
		    	Platform.runLater(new Runnable() {
		    		public void run() {
		    			try {
							Thread.sleep(600);
							scene.setCursor(new ImageCursor(mouse));
						} catch (InterruptedException e) {}
		            }
		        });
		    }
		}).start(); 
		
	}


	public String getTime(Locale local) {
		SimpleDateFormat sdf = new SimpleDateFormat("EEEE d MMMM yyyy HH:mm:ss", local);
		Date now = new Date();
		String strDate = sdf.format(now);
		return strDate;
	}
	
	@FXML
	public void checkLog(ActionEvent event) throws IOException, InterruptedException {
		if (usertext.getText().equals("dio") && passwordtext.getText().equals("3333")) {
			changeScene(event, "HomePageScene");
		} else if (usertext.getText().equals("admin") && passwordtext.getText().equals("admin")) {
			changeScene(event, "HomePageAdminScene");
		} else {
			alertClass.alertlog();
		}
	}
	
}
