package application;

import javafx.event.EventHandler;
import javafx.scene.ImageCursor;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;

public class CustomButton extends Button {
	Image entermouse = new Image(getClass().getResourceAsStream("../files/spatula.png"));
	Image exitmouse = new Image(getClass().getResourceAsStream("../files/mitten.png"));

	public CustomButton() {
		super();
		CustomButton bt = this;
		
		EventHandler<MouseEvent> enter = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				Scene scene = bt.getScene();
				scene.setCursor(new ImageCursor(entermouse));
			}
		};
		
		EventHandler<MouseEvent> exit = new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent e) {
				Scene scene = bt.getScene();
				scene.setCursor(new ImageCursor(exitmouse));
			}
		};

		this.addEventHandler(MouseEvent.MOUSE_ENTERED, enter);
		this.addEventHandler(MouseEvent.MOUSE_EXITED, exit);
	}
}
