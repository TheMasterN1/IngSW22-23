package application;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class AlertClass {

	public Alert alertlog(String text) {
		Alert alert = new Alert(AlertType.WARNING);
		alert.setContentText(text);
		return alert;
	}

	public Alert alertRemoving(String text) {
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setContentText(text);
		return alert;
	}

	public void notifyAdd() {
		//se l'ingrediente gia esiste alertType.Warning altrimenti alertType.Info
	}

	public void notifyAddQt() {
		//aggiunta quantit� all'ingrediente selezionato
	}
	
}
