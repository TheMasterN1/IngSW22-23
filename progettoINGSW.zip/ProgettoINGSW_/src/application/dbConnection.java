package application;

import java.sql.Connection;

import java.sql.DriverManager;
import javax.swing.JOptionPane;


public class dbConnection {

	private static String jdbcURL = "jdbc:mariadb://localhost:3306/ratatouille";
	private static String username = "root";
	private static String password = "123";
	private static Connection con;

	public static Connection getConnection() throws Exception {
		try {
			con = DriverManager.getConnection(jdbcURL, username, password);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Database non trovato", "Attenzione", JOptionPane.WARNING_MESSAGE);
		}
		return con;
	}
}
