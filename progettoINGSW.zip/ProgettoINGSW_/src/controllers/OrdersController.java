package controllers;

import java.io.IOException;

import application.AlertClass;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class OrdersController {

	AlertClass alertClass = new AlertClass();
	MainController controller = new MainController();
	
	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "HomePageScene");
	}

	@FXML
	public void backAdmin(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "HomePageAdminScene");
	}

	@FXML
	public void addOrders(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "AddOrdersScene");
	}
	
	@FXML
	public void cancelAdd(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "OrdersAdminScene");
	}

	@FXML
	public void confirmAdd(ActionEvent event) throws IOException, InterruptedException {
		alertClass.notifyAdd();
		controller.changeScene(event, "OrdersAdminScene");
	}
	
}
