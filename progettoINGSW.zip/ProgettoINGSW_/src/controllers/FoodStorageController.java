package controllers;

import java.io.IOException;
import java.sql.ResultSet;

import MariaDbDAO.FoodStorageDAO;
import application.AlertClass;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;

public class FoodStorageController {

	MainController controller = new MainController();
	private AlertClass alertClass = new AlertClass();

	@FXML
	private TableView<String> tableMagazzino = new TableView<>();
	private ObservableList<String> data;

	FoodStorageDAO foodStorageDAO = new FoodStorageDAO();

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "HomePageScene");
	}

	@FXML
	public void backAdmin(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "HomePageAdminScene");
	}

	@FXML
	public void addIngredient(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "AddIngredientScene");
	}

	@FXML
	public void removeIngredient(ActionEvent event) throws IOException, InterruptedException {
		if (alertClass.alertRemoving("Rimuovere l'ingrediente //getingredienteselezionato ?").showAndWait()
				.get() == ButtonType.OK)
			controller.changeScene(event, "FoodStorageAdminScene");
	}

	@FXML
	public void cancelAdd(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "FoodStorageAdminScene");
	}

	@FXML
	public void confirmAdd(ActionEvent event) throws IOException, InterruptedException {
		alertClass.notifyAdd();
		controller.changeScene(event, "FoodStorageAdminScene");
	}
	
	private void addQtIngredient(ActionEvent event) throws IOException, InterruptedException  {
		alertClass.notifyAddQt();
		controller.changeScene(event, "FoodStorageAdminScene");
	}

	@FXML
	void initialize() {
//		try {
//			foodStorageDAO.InserisciProdotto(15, "no", "als", "mso", 12, "Antipasto");
//		} catch (Exception e) {
//			e.printStackTrace();
//		}

		buildData();

	}

	public void rightClickEvent(MouseEvent event) {
		ContextMenu menu = new ContextMenu();
		MenuItem remove = new MenuItem("Rimuovi");
		MenuItem modify = new MenuItem("Modifica");
		menu.getItems().addAll(remove, modify);
		
		remove.setOnAction(e -> {
			try {removeIngredient(e);} catch (IOException e1) {} 
			catch (InterruptedException e1) {}
        });
		
		modify.setOnAction(e -> {
			try {addQtIngredient(e);} catch (IOException e1) {} 
			catch (InterruptedException e1) {}
        });
		
		tableMagazzino.setContextMenu(menu);
	}

	@FXML
	public void buildData() {
		data = FXCollections.observableArrayList();
		ResultSet rs;
		try {
			rs = controller.foodStorageDAO.ListaProdotti("");
			/*
			 * for(int i=0 ; i<rs.getMetaData().getColumnCount(); i++){ //We are using non
			 * property style for making dynamic table final int j = i; TableColumn col =
			 * new TableColumn(rs.getMetaData().getColumnName(i+1));
			 * col.setCellValueFactory((Callback) new
			 * Callback<TableColumn.CellDataFeatures<ObservableList,String>,ObservableValue<
			 * String>>(){ public ObservableValue<String>
			 * call(TableColumn.CellDataFeatures<ObservableList, String> param) { return new
			 * SimpleStringProperty(param.getValue().get(j).toString()); } });
			 * 
			 * 
			 * tableMagazzino.getColumns().addAll(col);
			 * System.out.println("Column ["+i+"] "); }
			 */

			/********************************
			 * Data added to ObservableList *
			 ********************************/
			// while(rs.next()){
			// Iterate Row
			// ObservableList<String> row = FXCollections.observableArrayList();
			// for(int i=1 ; i<=rs1.getMetaData().getColumnCount(); i++){
			// Iterate Column
			rs.beforeFirst();
			while (rs.next()) {
				data.add(rs.getString(1));
				data.add(rs.getString(2));
				data.add(rs.getString(3));
				data.add(rs.getString(4));
				data.add(rs.getString(6));
				data.add(rs.getString(7));
			}
			// }
			// System.out.println("Row [1] added "+row );
			// data.add(row);

			// }

			// FINALLY ADDED TO TableView
			tableMagazzino.setItems(data);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Error on Building Data");
		}
	}

}
