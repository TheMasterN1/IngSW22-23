package controllers;

import java.io.IOException;
import java.util.Random;

import MariaDbDAO.UtenteDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class UtenteController {

	MainController controller = new MainController();
	private TableView<String> tableMagazzino;
	private ObservableList<ObservableList> data;

	UtenteDAO utenteDAO = new UtenteDAO();
	@FXML ChoiceBox<String> choice_box_ruoli;

	@FXML TextField txt_nome;
	@FXML TextField txt_cognome;

	@FXML TextField txt_username;

	@FXML TextField txt_password;

	@FXML Button exit_btn;

	@FXML Button ok_btn;
	
	@FXML ImageView profilepic;

	@FXML
	private void initialize() {
//		ObservableList<String> list = FXCollections.observableArrayList();
//		list.addAll("Amministratore", "Addetto Cucina", "Supervisore", "Addetto Sala");
//
//		choice_box_ruoli.setItems(list);
		
		Random random = new Random();
		int i = random.nextInt(4);
		if(i==0)
			profilepic.setImage(new Image(getClass().getResourceAsStream("../files/admin.png")));
		if(i==1)
			profilepic.setImage(new Image(getClass().getResourceAsStream("../files/supervisor.png")));
		if(i==2)
			profilepic.setImage(new Image(getClass().getResourceAsStream("../files/waiter.png")));
		if(i==3)
			profilepic.setImage(new Image(getClass().getResourceAsStream("../files/cooker.png")));
	}

	@FXML
	public void okBtn() {

		try {
			utenteDAO.InserisciUtente(txt_username.getText(), txt_password.getText(), null,
					choice_box_ruoli.getSelectionModel().getSelectedItem().toString(), null);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "HomePageScene");
	}
	
	@FXML
	public void backAdmin(ActionEvent event) throws IOException, InterruptedException {
		controller.changeScene(event, "HomePageAdminScene");
	}

}
