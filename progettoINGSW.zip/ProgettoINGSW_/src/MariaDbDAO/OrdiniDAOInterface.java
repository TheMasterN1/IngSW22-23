package MariaDbDAO;

import java.sql.ResultSet;

public interface OrdiniDAOInterface {
	ResultSet InserisciOrdine(int ordineID, int costOrdine, int prodID) throws Exception;

	ResultSet RimuoviOrdine(int id) throws Exception;

	ResultSet UpdateOrdini(int costOrdine, int costoNuovo) throws Exception;

	ResultSet ListaOrdini() throws Exception;
}
