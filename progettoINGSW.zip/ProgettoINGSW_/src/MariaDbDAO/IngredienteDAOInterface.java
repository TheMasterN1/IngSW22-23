package MariaDbDAO;

import java.sql.ResultSet;

public interface IngredienteDAOInterface {
	ResultSet InserisciIngrediente(String nome, int ingredienteID, int quantita, int prodID) throws Exception;

	ResultSet RimuoviIngrediente(String nome) throws Exception;

	ResultSet UpdateIngredienti(String nome, int quantita) throws Exception;

	ResultSet ListaIngredienti(String nome) throws Exception;

	ResultSet ListaIngredientiSpecifica(int prodotto) throws Exception;
}
