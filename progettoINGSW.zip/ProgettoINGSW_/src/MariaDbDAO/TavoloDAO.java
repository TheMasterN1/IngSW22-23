package MariaDbDAO;

import application.dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class TavoloDAO implements TavoloDAOInterface {
	@Override
	public ResultSet InserisciTavolo(int tavoloID, int numeroPosti, int salaID) throws Exception {
		Connection con = null;
		String sql = "Insert into tavolo VALUES(?,?,?)";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, tavoloID);
		p1.setInt(2, numeroPosti);
		p1.setInt(3, salaID);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet RimuoviTavolo(int id) throws Exception {
		Connection con = null;
		String sql = "delete from tavolo where tavolo.tavoloID=? ";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, id);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet ListaTavolo(int salaID) throws Exception {
		Connection con = null;
		String sql = "select * from tavolo where tavolo.salaID=?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, salaID);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

}
