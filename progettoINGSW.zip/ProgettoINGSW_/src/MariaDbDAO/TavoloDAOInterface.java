package MariaDbDAO;

import java.sql.ResultSet;

public interface TavoloDAOInterface {
	ResultSet InserisciTavolo(int tavoloID, int numeroPosti, int salaID) throws Exception;

	ResultSet RimuoviTavolo(int id) throws Exception;

	ResultSet ListaTavolo(int salaID) throws Exception;
}
