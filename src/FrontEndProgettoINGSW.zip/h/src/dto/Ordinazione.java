package dto;

public class Ordinazione {
	int idTavolo;
	int quantit�;
	String idProdotto;

	public Ordinazione(int idTavolo, int quantit�, String idProdotto) {
		this.idTavolo = idTavolo;
		this.quantit� = quantit�;
		this.idProdotto = idProdotto;
	}

	public int getIdTavolo() {
		return idTavolo;
	}

	public void setIdTavolo(int idTavolo) {
		this.idTavolo = idTavolo;
	}

	public int getQuantit�() {
		return quantit�;
	}

	public void setQuantit�(int quantit�) {
		this.quantit� = quantit�;
	}

	public String getIdProdotto() {
		return idProdotto;
	}

	public void setIdProdotto(String idProdotto) {
		this.idProdotto = idProdotto;
	}
}
