package dto;

import enumerations.TipoUtente;

public class Utente {
	String username;
	String password;
	int id;
	TipoUtente ruolo;
	Integer idSala;
	boolean isNew = false;

	public Utente(String username, String password, int id, TipoUtente ruolo, Integer idSala) {
		this.username = username;
		this.password = password;
		this.id = id;
		this.ruolo = ruolo;
		this.idSala = idSala;
	}

	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public TipoUtente getRuolo() {
		return ruolo;
	}

	public void setRuolo(TipoUtente ruolo) {
		this.ruolo = ruolo;
	}

	public int getIdSala() {
		return idSala;
	}

	public void setIdSala(int idSala) {
		this.idSala = idSala;
	}

	@Override
	public String toString() {
		return "Utente [username=" + username + ", password=" + password + ", id=" + id + ", ruolo=" + ruolo
				+ ", idSala=" + idSala + ", isNew=" + isNew + "]";
	}
}
