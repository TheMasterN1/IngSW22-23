package enumerations;

public enum TipoUtente {
	Amministratore, Addetto_Cucina, Supervisore, Addetto_Sala
}
