package controllers;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.IOException;

import dto.Utente;
import org.apache.log4j.Logger;

public class UtenteController<T> extends ExtendedController {

	@FXML
	TextField txt_nome;
	@FXML
	TextField txt_cognome;
	@FXML
	TextField txt_username;
	@FXML
	TextField txt_password;
	@FXML
	TextField txt_conferma_password;
	@FXML
	Button exit_btn;
	@FXML
	Button ok_btn;
	@FXML
	ImageView profilepic;
	@FXML
	TextField txt_ruolo;

	static Logger logger = Logger.getLogger(UtenteController.class);

	@FXML
	private void initialize() {
		int i = utente.getRuolo().ordinal();

		switch (i) {
		case 0: {
			profilepic.setImage(new Image(getClass().getResourceAsStream("../files/admin.png")));
		}
			break;
		case 1: {
			profilepic.setImage(new Image(getClass().getResourceAsStream("../files/cooker.png")));
		}
			break;
		case 2: {
			profilepic.setImage(new Image(getClass().getResourceAsStream("../files/supervisor.png")));
		}
			break;
		case 3: {
			profilepic.setImage(new Image(getClass().getResourceAsStream("../files/waiter.png")));
		}
			break;
		}

		if (utente != null) {
			if (utente.getUsername() != null) {
				txt_username.setText(utente.getUsername());
			}
			if (utente.getPassword() != null) {
				txt_password.setText(utente.getPassword());
			}

			if (utente.getRuolo() != null) {
				txt_ruolo.setText(utente.getRuolo().toString());
				txt_ruolo.setEditable(false);
			}
		}
		disableStage();
	}

	@FXML
	public void okBtn(ActionEvent event) {

		try {
			Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.IDENTITY).create();
			if (txt_username != null && txt_username.getText().length() > 0 && txt_password.getText().length() > 0
					&& txt_conferma_password.getText().length() > 0) {
				if (txt_password.getText().equals(txt_conferma_password.getText())) {
					askData("utente/", "PUT", gson.toJson(new Utente(txt_username.getText(), txt_password.getText(),
							utente.getId(), utente.getRuolo(), utente.getIdSala())));
					logger.info("RICHIESTA AGGIORNAMENTO DATI UTENTE : " + txt_username.getText() + " , "
							+ txt_password.getText() + ", " + utente.getRuolo() + " , " + utente.getIdSala());
					closeAndReEnable(event);
				} else {
					logger.error("errore, campi mancanti o sbagliati");
					alertClass.alertlog("errore, campi mancanti o sbagliati").showAndWait();
				}
			} else {
				logger.error("errore, campi mancanti o sbagliati");
				alertClass.alertlog("errore, campi mancanti o sbagliati").showAndWait();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		closeAndReEnable(event);
	}

}
