package controllers;

import application.CustomButton;
import dto.Notifiche;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import org.apache.log4j.Logger;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;

public class SendORViewMessageController extends ExtendedController {

	@FXML
	private Pane pane;
	@FXML
	private CustomButton confirmButton;
	@FXML
	private TextField txt_oggetto;
	@FXML
	private TextArea txt_testo_messaggio;

	static Logger logger = Logger.getLogger(SendORViewMessageController.class);
	int idNotifiche;
	int idUtente;
	Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.IDENTITY).create();
	Notifiche notifiche;

	@FXML
	public void initialize() {
		txt_testo_messaggio.setWrapText(true);

		try {
			if (!isAdmin)
				pane.getChildren().remove(confirmButton);

			if (NotificationController.notifiche != null) {
				txt_oggetto.setText(NotificationController.notifiche.getOggetto());
				txt_testo_messaggio.setText(NotificationController.notifiche.getTesto());
				idNotifiche = NotificationController.notifiche.getIDnotifiche();
				idUtente = NotificationController.notifiche.getIdUtente();
				askData("notifiche/", "PUT", gson.toJson(notifiche), String.valueOf(idUtente),
						String.valueOf(idNotifiche));
			}
		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
		}
	}

	@FXML
	public void send(ActionEvent event) throws IOException, InterruptedException {
		close(event);
		try {
			if (txt_oggetto != null && txt_testo_messaggio != null) {
				if (txt_oggetto.getText().length() == 0) {
					txt_oggetto.setText("<NO OGGETTO>");
				}
				if (txt_testo_messaggio.getText().length() == 0) {
					txt_testo_messaggio.setText("<TESTO MESSAGGIO VUOTO>");
				}

				if (idNotifiche > 0 && idUtente > 0) {
					notifiche = new Notifiche(idNotifiche, txt_oggetto.getText(), txt_testo_messaggio.getText(),
							utente.getId());
					askData("notifiche/", "PUT", gson.toJson(notifiche), String.valueOf(utente.getId()));
				} else {
					notifiche = new Notifiche(0, txt_oggetto.getText(), txt_testo_messaggio.getText(), utente.getId());
					System.out.println(gson.toJson(notifiche));
					askData("notifiche/", "PUT", gson.toJson(notifiche), String.valueOf(utente.getId()));
				}

				logger.info("NOTIFICA INVIATA : OGGETTO :" + txt_oggetto.getText() + " TESTO : "
						+ txt_testo_messaggio.getText());
			}
		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
			Alert a = new Alert(Alert.AlertType.ERROR);
			a.setTitle("ERRORE");
			a.setContentText("errore, controllare esistano utenti e verificare i campi immessi");
			a.show();
		}
	}

	@FXML
	public void close(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		enableStage();
		stage.hide();
	}
}
