package controllers;

import application.CustomButton;
import application.JsonReader;
import application.Translator;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;
import dto.Ingrediente;
import dto.Prodotto;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class AddFoodStorageController extends ExtendedController {

	@FXML
	private Pane pane;
	@FXML
	private CustomButton addButton;
	@FXML
	private TableView<ObservableList<String>> tableMagazzino = new TableView<ObservableList<String>>();
	@FXML
	private Spinner<Integer> spinner_qta = new Spinner<>();
	@FXML
	private TextField txt_nome_prodotto = new TextField();
	@FXML
	private TextField txt_cerca_prodotto;
	@FXML
	private ComboBox<String> comboBox_cerca_prod;

	static Logger logger = Logger.getLogger(AddFoodStorageController.class);

	@FXML
	public void cancelAdd(ActionEvent event) throws IOException, InterruptedException {
		closeAndReEnable(event);
	}

	@FXML
	private void addQtIngredient(ActionEvent event) throws IOException, InterruptedException {
		if (txt_nome_prodotto.getText().length() > 0 && Integer.parseInt(spinner_qta.getValue().toString()) > 0) {
			try {
				Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.IDENTITY).create();
				if (FoodStorageController.ingrediente.getIngredienteId() > 0) {
					Ingrediente ingrediente = new Ingrediente(txt_nome_prodotto.getText().toString(),
							FoodStorageController.ingrediente.getIngredienteId(),
							Integer.parseInt(spinner_qta.getValue().toString()));
					askData("ingredienti/", "PUT", gson.toJson(ingrediente),
							String.valueOf(ingrediente.getIngredienteId()));
					logger.info("aggiornamento del ingrediente : " + FoodStorageController.ingrediente.getNome());
					logger.info("nuovo nome ingrediente : " + txt_nome_prodotto.getText());
					logger.info("nuova qta : " + spinner_qta.getValue().toString());
				} else {
					Ingrediente ingrediente = new Ingrediente(txt_nome_prodotto.getText().toString(), 0,
							Integer.parseInt(spinner_qta.getValue().toString()));
					System.out.println(gson.toJson(ingrediente));
					askData("ingredienti/", "POST", gson.toJson(ingrediente));
					logger.info("inserimento nuovo ingrediente : " + txt_nome_prodotto.getText() + " qta : "
							+ spinner_qta.getValue().toString());
				}
				closeAndReEnable(event);
			} catch (Exception e) {
				logger.error(e);
			}
		} else {
			Alert a = new Alert(Alert.AlertType.ERROR);
			a.setTitle("ERRORE");
			a.setContentText("errore, campi mancanti o sbagliati");
			logger.error("errore, campi mancanti o sbagliati");
			a.show();
		}
	}

	@FXML
	void initialize() {
		if (!isAdmin)
			pane.getChildren().remove(addButton);

		if (FoodStorageController.ingrediente.getIngredienteId() != 0) {
			txt_nome_prodotto.setText(FoodStorageController.ingrediente.getNome());
			spinner_qta.getValueFactory().setValue(FoodStorageController.ingrediente.getQuantita());
		}

		txt_nome_prodotto.textProperty().addListener((observable, oldValue, newValue) -> {
			if (newValue.length() >= 3) {
				Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.IDENTITY).create();

				JsonReader jsonReader = new JsonReader();

				new Thread(new Runnable() {
					@Override
					public void run() {
						String url = jsonReader.readFromUrlProdotto(newValue);

						Map<ArrayList<LinkedTreeMap>, Object> map = new HashMap<ArrayList<LinkedTreeMap>, Object>();
						map = (Map<ArrayList<LinkedTreeMap>, Object>) gson.fromJson(url, map.getClass());

						if (map != null) {
							ArrayList<LinkedTreeMap> arr = (ArrayList<LinkedTreeMap>) map.get("meals");
							if (arr != null) {
								LinkedTreeMap linkedTreeMap = (LinkedTreeMap) arr.get(0);
								String nome = linkedTreeMap.get("strIngredient1").toString();

								try {
									nome = Translator.Translate("", "it", nome);
									logger.info("NOME TRADOTTO DA : " + txt_nome_prodotto.getText() + " A : " + nome);
									txt_nome_prodotto.setText(nome);
								} catch (IOException e) {
									logger.error(e);
									throw new RuntimeException(e);
								}
							}
						}
					}
				}).start();
			}

		});
	}
}