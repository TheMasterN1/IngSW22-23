package controllers;

import java.io.IOException;
import org.apache.log4j.Logger;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.json.JSONObject;

import dto.Utente;
import enumerations.TipoUtente;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.ButtonType;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class MainController<T> extends ExtendedController {

	@FXML
	private TextField usertext;
	@FXML
	private PasswordField passwordtext;
	@FXML
	private Pane pane;
	private static Logger logger = Logger.getLogger(MainController.class);

	@FXML
	public void initialize() {
		setPane(pane);
	}

	@FXML
	public void checkLog(ActionEvent event) throws IOException, InterruptedException {
		try {
			JSONObject json = askData("utente/", "GET", "", usertext.getText(), passwordtext.getText());
			logger.info("AGGIORNO UTENTE : " + usertext.getText() + "CON PASSWORD : " + passwordtext.getText());
			utente = new Utente(json.getString("username"), json.getString("password"), json.getInt("id"),
					TipoUtente.valueOf(json.getString("ruolo")), json.getInt("idSala"));

			setIsAdmin(utente.getRuolo().ordinal() == 0 ? true : false);
			changeSceneFullscreen(event, "HomePageScene");

			if (json.getBoolean("new")) {
				checkPassword();
			}

		} catch (Exception e) {
			logger.error(e);
			alertClass.alertlog(
					"I campi Username/Password sono errati. \nSi prega di controllare le credenziali e ritentare l'accesso ")
					.show();
		}

	}

	private void checkPassword() throws Exception {
		if (alertClass.askNewPassword().showAndWait().get() == ButtonType.OK) {
			utente.setPassword(alertClass.setNewPassword());
		}

		Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.IDENTITY).create();

		askData("utente/", "PUT", gson.toJson(new Utente(utente.getUsername(), utente.getPassword(), utente.getId(),
				utente.getRuolo(), utente.getIdSala())));

		logger.info("NUOVA PASSWORD DELL'UTENTE :" + utente.getPassword());
	}

	@FXML
	public void close(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.hide();
	}
}