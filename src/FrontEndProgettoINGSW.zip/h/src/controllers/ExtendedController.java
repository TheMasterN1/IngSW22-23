package controllers;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import application.MyAlert;
import dto.Utente;
import enumerations.TipoUtente;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.ImageCursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class ExtendedController {

	MyAlert alertClass = new MyAlert();

	protected static boolean isAdmin;
	protected static Utente utente;
	protected static Pane paneController;
	protected static int chosen_table;
	protected String token;

	Stage stage;
	Image waitmouse = new Image(getClass().getResourceAsStream("../files/cooking-pot.png"));
	Image mouse = new Image(getClass().getResourceAsStream("../files/mitten.png"));
	static Logger logger = Logger.getLogger(ExtendedController.class);

	public void setIsAdmin(boolean admin) {
		ExtendedController.isAdmin = admin;
	}

	public void setUtente(String username, String password, int id, TipoUtente ruolo, Integer idSala) {
		utente = new Utente(username, password, id, ruolo, idSala);
	}

	public void disableStage() {
		paneController.setDisable(true);
	}

	public void enableStage() {
		paneController.setDisable(false);
	}

	public void setPane(Pane pane) {
		ExtendedController.paneController = pane;
	}

	public static Pane getPane() {
		return paneController;
	}

	@FXML
	public void closeAndReEnable(ActionEvent event) {
		enableStage();
		stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.hide();
	}

	public void changeSceneFullscreen(Event event, String scenestring) throws IOException, InterruptedException {
		Parent root = FXMLLoader.load(getClass().getResource("../scenes/" + scenestring + ".fxml"));

		stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Scene scene = new Scene(root);

		setStageAndScene(scene);
		stage.show();

		waitMouseThread(scene);
	}

	public void changeSceneNotFullscreen(Event event, String scenestring) throws IOException, InterruptedException {
		Parent root = FXMLLoader.load(getClass().getResource("../scenes/" + scenestring + ".fxml"));

		if (!scenestring.equals("LoginScene"))
			disableStage();

		stage = new Stage();
		stage.initStyle(StageStyle.TRANSPARENT);

		Scene scene = new Scene(root);

		stage.sizeToScene();
		setStageAndScene(scene);
		stage.setAlwaysOnTop(true);
		stage.show();

		waitMouseThread(scene);

	}

	private void setStageAndScene(Scene scene) {
		stage.setResizable(false);
		stage.getIcons().add(new Image(getClass().getResourceAsStream("../files/logochef.jpg")));
		scene.setCursor(new ImageCursor(waitmouse));
		scene.setFill(Color.TRANSPARENT);
		stage.setScene(scene);
		stage.centerOnScreen();
	}

	private void waitMouseThread(Scene scene) {
		new Thread(new Runnable() {
			public void run() {
				Platform.runLater(new Runnable() {
					public void run() {
						try {
							Thread.sleep(600);
							scene.setCursor(new ImageCursor(mouse));
						} catch (InterruptedException e) {
						}
					}
				});
			}
		}).start();
	}

	JSONObject askData(String stringRequest, String typeRequest, String object, String... strings)
			throws IOException, InterruptedException {
		HttpClient http = HttpClient.newHttpClient();
		HttpResponse<String> response;
		HttpRequest request = null;
		if (token == "") {
			request = HttpRequest.newBuilder().uri(URI.create("http://localhost:8080/auth"))
					.headers("Content-Type", "application/json")
					.POST(HttpRequest.BodyPublishers.ofString("\"login\":\"123\", \"password\":\"123\"")).build();
			response = http.send(request, HttpResponse.BodyHandlers.ofString());
			JSONObject json = new JSONObject(response.body());
			token = json.getString("accesstoken");
		}
		HttpRequest.Builder builder = HttpRequest.newBuilder()
				.uri(URI.create("http://localhost:8080/" + stringRequest
						+ (typeRequest.equals("POST") ? "" : String.join("/", strings))))
				.headers("Authorization", "Bearer " + token);
		switch (typeRequest) {
		case ("GET"): // ottieni dati
			request = builder.GET().build();
			break;
		case ("PUT"): // update dati
			request = builder.PUT(HttpRequest.BodyPublishers.ofString(object))
					.setHeader("Content-Type", "application/json").build();
			break;
		case ("POST"):// aggiungi dati
			request = builder.POST(HttpRequest.BodyPublishers.ofString(object))
					.setHeader("Content-Type", "application/json").build();
			break;
		case ("DELETE"): // elimina dati
			request = builder.DELETE().build();
			break;
		}
		response = http.send(request, HttpResponse.BodyHandlers.ofString());
		logger.info("RICHIESTA : " + request);
		logger.info("RISPOSTA : " + response.body());
		if (response.body().isEmpty())
			return null;
		JSONObject json = new JSONObject(response.body());
		return json;
	}
}
