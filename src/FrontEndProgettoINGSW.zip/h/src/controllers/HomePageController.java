package controllers;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import application.CustomButton;
import enumerations.TipoUtente;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class HomePageController extends ExtendedController {

	@FXML
	private Label datetime = new Label();
	@FXML
	private Circle countNotify;
	@FXML
	private AnchorPane image;
	@FXML
	private CustomButton dipendentButton, ordersButton;

	static Logger logger = Logger.getLogger(HomePageController.class);

	@FXML
	public void initialize() {
		setPane(image);

		if (!isAdmin)
			image.getChildren().remove(dipendentButton);

		if (utente.getRuolo().equals(TipoUtente.Addetto_Sala))
			ordersButton.setText("Sala");

		try {
			JSONObject json = askData("notifiche/", "GET", "", String.valueOf(utente.getId()));
			logger.info("RISULTATO GET NOTIFICHE : " + json);
			int rs = Integer.valueOf(json.getString("count"));
			if (rs == 0)
				image.getChildren().remove(countNotify);
		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
		}

	}

	public HomePageController() {
		KeyFrame update = new KeyFrame(Duration.seconds(1.0), event -> {
			datetime.setText(getTime(Locale.ITALY));
		});
		Timeline timeline = new Timeline(update);
		timeline.setCycleCount(Animation.INDEFINITE);
		timeline.play();
	}

	@FXML
	private void register(ActionEvent event) throws IOException, InterruptedException {
		changeSceneNotFullscreen(event, "RegisterDipendentScene");
		logger.info("CAMBIATA SCENE IN : REGISTERDIPENDENTSCENE DA HOMEPAGECONTROLLER");
	}

	@FXML
	private void seeProfile(ActionEvent event) throws IOException, InterruptedException {
		changeSceneNotFullscreen(event, "ProfileScene");
		logger.info("CAMBIATA SCENE IN : PROFILESCENE DA HOMEPAGECONTROLLER");
	}

	@FXML
	public void logout(ActionEvent event) throws IOException, InterruptedException {
		Alert alert = alertClass.alertlog("Vuoi disconnetterti?");
		if (alert.showAndWait().get() == ButtonType.OK) {
			logger.info("UTENTE DISCONNESSO");
			close(event);
			changeSceneNotFullscreen(event, "LoginScene");
			logger.info("CAMBIATA SCENE IN : LOGINSCENE DA HOMEPAGECONTROLLER");
		}
	}

	@FXML
	public void openNotify(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "NotificationScene");
		logger.info("CAMBIATA SCENE IN : NOTIFICATIONSCENE DA HOMEPAGECONTROLLER");
	}

	@FXML
	public void seeFood(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "FoodStorageScene");
	}

	@FXML
	public void seeMenu(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "MenuScene");
	}

	@FXML
	public void seeOrders(ActionEvent event) throws IOException, InterruptedException {
		if (utente.getRuolo().equals(TipoUtente.Addetto_Sala)) {
			changeSceneFullscreen(event, "SalaScene");
			logger.info("CAMBIATA SCENE IN : SALASCENE DA HOMEPAGECONTROLLER");
		} else {
			changeSceneFullscreen(event, "OrdersScene");
			logger.info("CAMBIATA SCENE IN : ORDERSSCENE DA HOMEPAGECONTROLLER");
		}
	}

	public String getTime(Locale local) {
		SimpleDateFormat sdf = new SimpleDateFormat("EEEE d MMMM yyyy HH:mm:ss", local);
		Date now = new Date();
		String strDate = sdf.format(now);
		return strDate;
	}

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "HomePageScene");
		logger.info("CAMBIATA SCENE IN : HOMEPAGESCENE DA HOMEPAGECONTROLLER");
	}

	@FXML
	public void close(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.hide();
	}

}
