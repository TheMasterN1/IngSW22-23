package controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import dto.Utente;
import enumerations.TipoUtente;

public class OperationController extends ExtendedController {

	@FXML
	private Pane pane;
	@FXML
	private Label sala;
	@FXML
	private ChoiceBox<Integer> choicesala;
	@FXML
	private TextField txt_username;
	@FXML
	private PasswordField txt_password;
	@FXML
	private PasswordField txt_conferma_password;
	@FXML
	private ChoiceBox<TipoUtente> choiceRuolo;
	static Logger logger = Logger.getLogger(OperationController.class);

	@FXML
	public void initialize() {

		pane.getChildren().remove(sala);
		pane.getChildren().remove(choicesala);

		choiceRuolo.setItems(FXCollections.observableArrayList(TipoUtente.values()));

		if (choicesala != null) {
			ObservableList<Integer> items = FXCollections.observableArrayList();
			try {
				JSONObject json = askData("sale/", "GET", "");
				logger.info("RISULTATO GET SALE PER INITIALIZE");
				JSONArray resultSet = json.getJSONArray("values");
				for (Object sala : resultSet) {
					items.add(Integer.valueOf(String.valueOf(sala)));
				}

				choicesala.setItems(items);
			} catch (Exception e) {
				logger.error(e);
				e.printStackTrace();
			}

			choiceRuolo.setOnAction(event -> {
				if (choiceRuolo.getSelectionModel().getSelectedItem().equals(TipoUtente.Addetto_Sala)) {
					pane.getChildren().add(sala);
					pane.getChildren().add(choicesala);
				} else {
					pane.getChildren().remove(sala);
					pane.getChildren().remove(choicesala);
				}
			});

		}

	}

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		closeAndReEnable(event);
	}

	@FXML
	public void addUser(ActionEvent event) throws IOException, InterruptedException {
		Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.IDENTITY).create();
		try {
			if (txt_username != null && txt_username.getText().length() > 0 && txt_password != null
					&& txt_password.getText().length() > 0 && txt_conferma_password != null
					&& txt_conferma_password.getText().length() > 0 && choiceRuolo != null
					&& choiceRuolo.getSelectionModel().getSelectedItem() != null) {
				if (txt_password.getText().equals(txt_conferma_password.getText())) {
					if (choicesala != null && choicesala.getSelectionModel().getSelectedItem() != null) {
						askData("utente/", "POST",
								gson.toJson(new Utente(txt_username.getText(), txt_password.getText(), utente.getId(),
										choiceRuolo.getSelectionModel().getSelectedItem(),
										choicesala.getSelectionModel().getSelectedItem())));
						logger.info("INSERIMENTO CAMERIERE : " + txt_username.getText() + ", " + txt_password.getText()
								+ ", " + utente.getId() + " , " + choiceRuolo.getSelectionModel().getSelectedItem()
								+ ", " + choicesala.getSelectionModel().getSelectedItem());
					} else {
						askData("utente/", "POST",
								gson.toJson(new Utente(txt_username.getText(), txt_password.getText(), utente.getId(),
										choiceRuolo.getSelectionModel().getSelectedItem(), 0)));
						logger.info("INSERIMENTO UTENTE : " + txt_username.getText() + ", " + txt_password.getText()
								+ ", " + utente.getId() + " , " + choiceRuolo.getSelectionModel().getSelectedItem());
					}
					closeAndReEnable(event);
				} else {
					Alert a = new Alert(Alert.AlertType.ERROR);
					a.setTitle("ERRORE");
					a.setContentText("errore, campi mancanti o sbagliati");
					logger.error("errore, campi mancanti o sbagliati");
					a.show();
				}
			} else {
				Alert a = new Alert(Alert.AlertType.ERROR);
				a.setTitle("ERRORE");
				a.setContentText("errore, campi mancanti o sbagliati");
				logger.error("errore, campi mancanti o sbagliati");
				a.show();
			}
		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
		}
	}
}
