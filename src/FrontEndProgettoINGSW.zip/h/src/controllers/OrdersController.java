package controllers;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import application.CustomButton;
import dto.Ingrediente;
import dto.Ordine;
import dto.Tavolo;

public class OrdersController extends ExtendedController {

	@FXML
	private Pane pane;
	@FXML
	private FlowPane orders_box;

	static Logger logger = Logger.getLogger(OrdersController.class);

	@SuppressWarnings("static-access")
	@FXML
	public void initialize() {
		setPane(pane);

		try {
			JSONObject json = askData("ordini/", "GET", "");
			logger.info("RICHIESTA GET ORDINI INITIALIZE : " + json);
			JSONArray array = json.getJSONArray("values");
			String[] a = String.valueOf(array).split(",");
			ArrayList<Ordine> rs = new ArrayList<>();
			for (int i = 0; i < a.length; i += 3) {
				rs.add(new Ordine(Integer.valueOf(a[i].replace("\"", "").replace("[", "")),
						Float.valueOf(a[i + 1].replace("\"", "")),
						Integer.valueOf(a[i + 2].replace("\"", "").replace("]", ""))));
			}
			for (Ordine ordine : rs) {
				AnchorPane item = new AnchorPane();
				item.setPrefSize(600, 150);

				Text idOrdine = new Text("Ordine n�" + ordine.getiDordine());
				Text costoTotale = new Text("Costo totale degli ordini: " + ordine.getCosto());
				Text idTavolo = new Text("Tavolo n�" + ordine.getiDtavolo());
				CustomButton satisfy = new CustomButton();
				satisfy.setText("Soddisfa Ordine");
				idOrdine.setFont(
						Font.font("MontSerrat", ordine.getCosto() == 0.0 ? FontWeight.THIN : FontWeight.BOLD, 20));
				idOrdine.setFill(Color.WHITE);
				costoTotale.setFont(
						Font.font("MontSerrat", ordine.getCosto() == 0.0 ? FontWeight.THIN : FontWeight.BOLD, 20));
				costoTotale.setFill(Color.WHITE);
				idTavolo.setFont(
						Font.font("MontSerrat", ordine.getCosto() == 0.0 ? FontWeight.THIN : FontWeight.BOLD, 20));
				idTavolo.setFill(Color.WHITE);
				satisfy.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 20));
				satisfy.setTextFill(Color.WHITE);

				satisfy.setOnMouseClicked(new EventHandler<Event>() {
					@Override
					public void handle(Event arg0) {
						satisfyOrdine(arg0, idOrdine.getText().substring(9, idOrdine.getText().length()));
					}
				});

				item.getChildren().addAll(idOrdine, costoTotale, idTavolo, satisfy);
				item.setTopAnchor(idOrdine, 20.0);
				item.setLeftAnchor(idOrdine, 20.0);
				item.setTopAnchor(costoTotale, 20.0);
				item.setRightAnchor(costoTotale, 20.0);
				item.setBottomAnchor(idTavolo, 20.0);
				item.setLeftAnchor(idTavolo, 20.0);
				item.setBottomAnchor(satisfy, 20.0);
				item.setRightAnchor(satisfy, 20.0);
				if (ordine.getCosto() == 0.0) {
					item.getChildren().remove(satisfy);
				}
				orders_box.getChildren().add(item);
			}

			orders_box.setVgap(20);
			orders_box.setHgap(20);
			orders_box.setPadding(new Insets(20));
		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
		}
	}

	private void satisfyOrdine(Event arg0, String string) {
		if (alertClass.alertlog("Soddisfare l'ordine n� " + string + "?").showAndWait().get() == ButtonType.OK) {
			try {
				logger.info("SELEZIONATO SODDISFARE ORDINE OK");

				JSONObject json = askData("ordini/", "DELETE", "", string);
				logger.info("ORDINE ELIMINATO PERCHE SODDISFATTO : " + json);
				changeSceneFullscreen(arg0, "OrdersScene");
			} catch (Exception ex) {
				logger.error(ex);
				throw new RuntimeException(ex);
			}
		}
	}

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "HomePageScene");
		logger.info("CAMBIATA SCENE IN : HOMEPAGESCENE DA ORDERSCONTROLLER");
	}

}