package controllers;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import application.CustomButton;
import dto.Ingrediente;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class FoodStorageController extends ExtendedController {

	@FXML
	private Pane pane;
	@FXML
	private CustomButton addButton;
	@FXML
	private TextField txt_cerca_prodotto;
	@FXML
	private FlowPane ingredients_box;

	public static Ingrediente ingrediente = new Ingrediente();
	private ArrayList<Ingrediente> ingredienti = new ArrayList<Ingrediente>();

	static Logger logger = Logger.getLogger(FoodStorageController.class);

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "HomePageScene");
	}

	@FXML
	public void addIngredient(ActionEvent event) throws IOException, InterruptedException {
		try {
			ingrediente = new Ingrediente();
			changeSceneNotFullscreen(event, "AddIngredientScene");
			logger.info("CAMBIATA SCENE IN : ADDINGREDIENTSCENE DA FOODSTORAGECONTROLLER");
			new Thread(() -> {
				while (paneController.isDisable()) {
				}
				Platform.runLater(() -> {

					buildData("");
				});
			}).start();
		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
		}
	}

	@FXML
	public void removeIngredient(Event arg0) throws IOException, InterruptedException {
		if (alertClass.alertlog("Rimuovere l'ingrediente " + ingrediente.getNome() + "?").showAndWait()
				.get() == ButtonType.OK) {
			try {
				logger.info("RIMUOVO L'INGREDIENTE : " + ingrediente.getNome());
				askData("ingredienti/", "DELETE", "", String.valueOf(ingrediente.getIngredienteId()));
				new Thread(() -> {
					while (paneController.isDisable()) {
					}
					Platform.runLater(() -> {

						buildData("");
					});
				}).start();
			} catch (Exception e) {
				logger.error(e);
			}
		}
		buildData("");
	}

	@FXML
	void initialize() {
		try {
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e);
		}

		buildData("");
		setPane(pane);

		if (!isAdmin)
			pane.getChildren().remove(addButton);

		txt_cerca_prodotto.textProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> arg0, String arg1, String arg2) {
				buildData(arg2);
			}
		});
	}

	@SuppressWarnings("static-access")
	public void buildData(String searched) {
		try {
			ingredients_box.getChildren().removeAll(ingredients_box.getChildren());
			ingredienti.clear();
			JSONObject json = askData("ingredienti/", "GET", "");
			logger.info("RISULTATO GET DEI PRODOTTI PER TABELLA : " + json);
			JSONArray array = json.getJSONArray("values");
			String[] a = String.valueOf(array).split(",");
			for (int i = 0; i < a.length; i += 3) {
				ingredienti.add(new Ingrediente(a[i].replace("\"", "").replace("[", ""),
						Integer.valueOf(a[i + 1].replace("\"", "")),
						Integer.valueOf(a[i + 2].replace("\"", "").replace("]", ""))));
			}
			for (Ingrediente food : ingredienti) {
				if (!searched.equals("") && !food.getNome().contains(searched)) {
					continue;
				}
				AnchorPane item = new AnchorPane();
				item.setPrefSize(300, 200);

				Text nomeIngrediente = new Text(food.getNome());
				Text quantita = new Text("Disponibili in dispensa: " + food.getQuantita());
				item.setId(String.valueOf(food.getIngredienteId()));
				CustomButton removebutton = new CustomButton();
				removebutton.setId("removeButton");
				removebutton.setPrefSize(50, 50);
				CustomButton editbutton = new CustomButton();
				editbutton.setId("editButton");
				editbutton.setPrefSize(50, 50);

				nomeIngrediente.setFont(
						Font.font("MontSerrat", food.getQuantita() == 0 ? FontWeight.THIN : FontWeight.BOLD, 20));
				nomeIngrediente.setFill(Color.WHITE);
				quantita.setFont(
						Font.font("MontSerrat", food.getQuantita() == 0 ? FontWeight.THIN : FontWeight.BOLD, 20));
				quantita.setFill(Color.WHITE);

				removebutton.setOnMouseClicked(new EventHandler<Event>() {
					@Override
					public void handle(Event arg0) {
						try {
							ingrediente.setNome(nomeIngrediente.getText());
							ingrediente.setIngredienteId(Integer.valueOf(item.getId()));
							ingrediente.setQuantita(Integer.valueOf(quantita.getText().substring(25)));
							removeIngredient(arg0);
						} catch (Exception e) {
							logger.error(e);
							e.printStackTrace();
						}
					}
				});

				editbutton.setOnMouseClicked(new EventHandler<Event>() {
					@Override
					public void handle(Event arg0) {
						try {
							ingrediente.setNome(nomeIngrediente.getText());
							ingrediente.setIngredienteId(Integer.valueOf(item.getId()));
							ingrediente.setQuantita(Integer.valueOf(quantita.getText().substring(25)));
							changeSceneNotFullscreen(arg0, "AddIngredientScene");
						} catch (Exception e) {
							logger.error(e);
							e.printStackTrace();
						}
					}
				});

				item.getChildren().addAll(nomeIngrediente, quantita, removebutton, editbutton);
				item.setTopAnchor(nomeIngrediente, 20.0);
				item.setLeftAnchor(nomeIngrediente, 20.0);
				item.setTopAnchor(quantita, 50.0);
				item.setLeftAnchor(quantita, 20.0);
				item.setBottomAnchor(removebutton, 20.0);
				item.setLeftAnchor(removebutton, 20.0);
				item.setBottomAnchor(editbutton, 20.0);
				item.setRightAnchor(editbutton, 20.0);
				ingredients_box.getChildren().add(item);
			}

			ingredients_box.setVgap(20);
			ingredients_box.setHgap(20);
			ingredients_box.setPadding(new Insets(20));

		} catch (Exception ex) {
			logger.error(ex);
		}
	}
}