package controllers;

import java.io.IOException;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import application.CustomButton;
import application.Translator;
import dto.Ingrediente;
import dto.ProdottoEng;
import dto.ProdottoIta;
import enumerations.TipoProdottoEng;
import enumerations.TipoProdottoIta;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class MenuController extends ExtendedController {
	@FXML
	private Pane pane;
	@FXML
	private CustomButton addButton;
	@FXML
	private CustomButton button_language;
	@FXML
	private TextField txt_cerca_prodotto;
	@FXML
	private TextField txt_nome_prodotto = new TextField();
	@FXML
	private TextArea txt_descrizione_prodotto;
	@FXML
	private TextArea txt_allergeni;
	@FXML
	private TextField txt_costo;
	@FXML
	private FlowPane products_box;
	@FXML
	private ComboBox<Object> comboBox_cerca_prod = new ComboBox<>();
	@FXML
	private ComboBox<TipoProdottoIta> comboBox_categoria = new ComboBox<>();
	@FXML
	private Spinner<String> spinner_qta = new Spinner<>();

	private ImageView flag = new ImageView(new Image(getClass().getResourceAsStream("../files/italy.png")));
	private ImageView flag2 = new ImageView(new Image(getClass().getResourceAsStream("../files/united-kingdom.png")));
	private boolean italian = true;
	private ArrayList<ProdottoIta> prodottiIta = new ArrayList<>();
	private ArrayList<ProdottoEng> prodottiEng = new ArrayList<>();
	private Thread thread;
	public static ProdottoIta prodotto = new ProdottoIta();

	@FXML
	public void initialize() {
		try {
			thread = new Thread(() -> {
				try {
					for (ProdottoIta prodotto : prodottiIta) {
						prodottiEng.add(
								new ProdottoEng(prodotto.getCosto(), Translator.Translate("", "en", prodotto.getName()),
										Translator.Translate("", "en", prodotto.getAllergeni()),
										Translator.Translate("", "en", prodotto.getDescrizione()),
										prodotto.getProdottoID(), prodotto.getCategoria()));
						logger.info("INSERIMENTO PRODOTTO : " + prodottiEng);
					}
				} catch (Exception e) {
					e.printStackTrace();
					logger.error(e);
				}
			});
			thread.start();
		} catch (Exception e) {
			logger.error(e);
		}

		buildData("", null);
		setPane(pane);

		flag.setPreserveRatio(true);
		flag2.setPreserveRatio(true);
		flag.setFitHeight(50);
		flag2.setFitHeight(50);
		flag.setFitWidth(50);
		flag2.setFitWidth(50);

		comboBox_cerca_prod.setItems(
				FXCollections.observableArrayList(italian ? TipoProdottoIta.values() : TipoProdottoEng.values()));
		comboBox_cerca_prod.getSelectionModel().select(0);
		;
		comboBox_categoria.setItems(FXCollections.observableArrayList(TipoProdottoIta.values()));

		button_language.setGraphic(flag);
		button_language.setOnMouseClicked(arg0 -> {
			italian = !italian;
			button_language.setGraphic(italian ? flag : flag2);
			comboBox_cerca_prod.setItems(
					FXCollections.observableArrayList(italian ? TipoProdottoIta.values() : TipoProdottoEng.values()));
			comboBox_cerca_prod.getSelectionModel().select(0);
			;
		});

		if (!isAdmin)
			pane.getChildren().remove(addButton);

		txt_cerca_prodotto.textProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> arg0, String arg1, String arg2) {
				if (italian)
					buildData(arg2, comboBox_cerca_prod.getSelectionModel().getSelectedItem());
				else
					buildDataEng(arg2, comboBox_cerca_prod.getSelectionModel().getSelectedItem());
			}
		});

		comboBox_cerca_prod.valueProperty().addListener(new ChangeListener<Object>() {
			@Override
			public void changed(ObservableValue<? extends Object> arg0, Object arg1, Object arg2) {
				if (italian)
					buildData(txt_cerca_prodotto.getText(), arg2);
				else
					buildDataEng(txt_cerca_prodotto.getText(), arg2);
			}
		});
	}

	private void setProdotto(String id) throws Exception {
		JSONObject json = askData("prodotti/", "GET", "", id);
		logger.info("RISULTATO GET PRODOTTI : " + json);
		prodotto = new ProdottoIta(json.getFloat("costo"), json.getString("name"), json.getString("allergeni"),
				json.getString("descrizione"), json.getInt("prodottoID"),
				TipoProdottoIta.valueOf(json.getString("categoria")));
	}

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "HomePageScene");
		logger.info("CAMBIATA SCENE IN : HOMEPAGESCENE DA MENUCONTROLLER");
	}

	@FXML
	public void addDish(ActionEvent event) throws IOException, InterruptedException {
		changeSceneNotFullscreen(event, "AddDishMenuScene");
		logger.info("CAMBIATA SCENE IN : ADDINGREDIENTSCENE DA MENUCONTROLLER");
		new Thread(() -> {
			while (paneController.isDisable()) {
			}
			Platform.runLater(() -> {
				buildData("", comboBox_cerca_prod.getSelectionModel().getSelectedItem());
			});
		}).start();
	}

	@FXML
	public void removeProduct(Event arg0) throws IOException, InterruptedException {
		if (alertClass.alertlog("Rimuovere il prodotto " + prodotto.getName() + " ?").showAndWait()
				.get() == ButtonType.OK) {
			try {
				logger.info("RIMOSSO IL PRODOTTO : " + prodotto.getName());
				askData("prodotti/", "DELETE", "", String.valueOf(prodotto.getProdottoID()));
				prodotto = new ProdottoIta();
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}
	}

	@SuppressWarnings("static-access")
	public void buildData(String searched, Object type) {
		try {
			products_box.getChildren().clear();
			prodottiIta.clear();
			JSONObject json = askData("prodotti/", "GET", "");
			logger.info("RISULTATO GET PRODOTTI PER INITIALIZE : " + json);
			JSONArray array = json.getJSONArray("values");
			String[] a = String.valueOf(array).split(",");
			for (int i = 0; i < a.length; i += 6) {
				prodottiIta.add(new ProdottoIta(Float.valueOf(a[i].replace("\"", "").replace("[", "")),
						a[i + 1].replace("\"", ""), a[i + 2].replace("\"", ""), a[i + 3].replace("\"", ""),
						Integer.valueOf(a[i + 4].replace("\"", "")),
						TipoProdottoIta.valueOf(a[i + 5].replace("\"", "").replace("]", ""))));
			}
			for (ProdottoIta prod : prodottiIta) {
				if ((!searched.equals("") && !prod.getName().contains(searched)) || type!=null &&
						(prod.getCategoria() != TipoProdottoIta.valueOf(type.toString()))) {
					continue;
				}
				AnchorPane item = new AnchorPane();
				item.setPrefSize(400, 400);

				Text costoProdotto = new Text(prod.getCosto() + "�");
				Text nomeProdotto = new Text(prod.getName());
				Separator separator = new Separator(Orientation.HORIZONTAL);
				Text descrizioneProdotto = new Text(prod.getDescrizione());
				Separator separator2 = new Separator(Orientation.HORIZONTAL);
				item.setId(String.valueOf(prod.getProdottoID()));
				Text ricettaProdotto = new Text("RICETTA:\n");
				Separator separator3 = new Separator(Orientation.HORIZONTAL);
				Text categoriaProdotto = new Text(prod.getCategoria().toString());
				Text allergeniProdotto = new Text("*pu� contenere tracce di: " + prod.getAllergeni());

				CustomButton removebutton = new CustomButton();
				removebutton.setId("removeButton");
				removebutton.setPrefSize(50, 50);
				CustomButton editbutton = new CustomButton();
				editbutton.setId("editButton");
				editbutton.setPrefSize(50, 50);

				nomeProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 30));
				nomeProdotto.setFill(Color.WHITE);
				costoProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 20));
				costoProdotto.setFill(Color.WHITE);
				descrizioneProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 15));
				descrizioneProdotto.setFill(Color.WHITE);
				;
				ricettaProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 15));
				ricettaProdotto.setFill(Color.WHITE);
				allergeniProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 12));
				allergeniProdotto.setFill(Color.WHITE);
				categoriaProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 20));
				categoriaProdotto.setFill(Color.WHITE);

				json = askData("prodotti/", "GET", "", item.getId(), "ricetta");
				logger.info("RISULTATO RICHIESTA GET PRODOTTO PER BUILD DATA : " + json);
				array = json.getJSONArray("values");
				a = String.valueOf(array).split(",");
				ArrayList<Ingrediente> ingredienti = new ArrayList<Ingrediente>();
				for (int i = 0; i < a.length; i += 3) {
					ingredienti.add(new Ingrediente(a[i].replace("\"", "").replace("[", ""),
							Integer.valueOf(a[i + 1].replace("\"", "")),
							Integer.valueOf(a[i + 2].replace("\"", "").replace("]", ""))));
				}

				for (Ingrediente ingrediente : ingredienti) {
					JSONObject json2 = askData("ingredienti/", "GET", "",
							String.valueOf(ingrediente.getIngredienteId()));
					ricettaProdotto.setText(ricettaProdotto.getText() + " " + json2.get("nome") + ": "
							+ ingrediente.getQuantita() + ";\n");
				}

				removebutton.setOnMouseClicked(new EventHandler<Event>() {
					@Override
					public void handle(Event arg0) {
						try {
							setProdotto(item.getId());
							removeProduct(arg0);
							buildData(searched, comboBox_cerca_prod.getSelectionModel().getSelectedItem());
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});

				editbutton.setOnMouseClicked(new EventHandler<Event>() {
					@Override
					public void handle(Event arg0) {
						try {
							setProdotto(item.getId());
							changeSceneNotFullscreen(arg0, "AddDishMenuScene");
						} catch (IOException e1) {
						} catch (Exception e) {
							e.printStackTrace();
						}
						buildData(searched, comboBox_cerca_prod.getSelectionModel().getSelectedItem());
					}
				});

				item.getChildren().addAll(nomeProdotto, costoProdotto, descrizioneProdotto, ricettaProdotto,
						allergeniProdotto, categoriaProdotto, removebutton, editbutton, separator, separator2,
						separator3);
				item.setTopAnchor(nomeProdotto, 10.0);
				item.setTopAnchor(costoProdotto, 20.0);
				item.setRightAnchor(costoProdotto, 0.0);
				item.setTopAnchor(separator, 41.0);
				item.setLeftAnchor(separator, 0.0);
				item.setRightAnchor(separator, 0.0);
				item.setTopAnchor(categoriaProdotto, 42.0);
				item.setTopAnchor(separator2, 63.0);
				item.setLeftAnchor(separator2, 0.0);
				item.setRightAnchor(separator2, 0.0);
				item.setTopAnchor(descrizioneProdotto, 64.0);
				item.setTopAnchor(separator3, 125.0);
				item.setLeftAnchor(separator3, 0.0);
				item.setRightAnchor(separator3, 0.0);
				item.setTopAnchor(ricettaProdotto, 126.0);
				item.setBottomAnchor(allergeniProdotto, 100.0);
				item.setBottomAnchor(removebutton, 20.0);
				item.setLeftAnchor(removebutton, 20.0);
				item.setBottomAnchor(editbutton, 20.0);
				item.setRightAnchor(editbutton, 20.0);

				if (!isAdmin) {
					item.getChildren().removeAll(removebutton, editbutton);
				}
				products_box.getChildren().add(item);
			}

			products_box.setVgap(20);
			products_box.setHgap(20);
			products_box.setPadding(new Insets(20));
		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
		}
	}

	@SuppressWarnings("static-access")
	public void buildDataEng(String searched, Object type) {
		try {
			thread.join();
			products_box.getChildren().clear();
			prodottiEng.clear();
			JSONObject json = askData("prodotti/", "GET", "");
			logger.info("RISULTATO GET PRODOTTI PER INITIALIZE : " + json);
			JSONArray array = json.getJSONArray("values");
			String[] a = String.valueOf(array).split(",");
			for (int i = 0; i < a.length; i += 6) {
				prodottiIta.add(new ProdottoIta(Float.valueOf(a[i].replace("\"", "").replace("[", "")),
						a[i + 1].replace("\"", ""), a[i + 2].replace("\"", ""), a[i + 3].replace("\"", ""),
						Integer.valueOf(a[i + 4].replace("\"", "")),
						TipoProdottoIta.valueOf(a[i + 5].replace("\"", "").replace("]", ""))));
			}
			for (ProdottoEng prod : prodottiEng) {
				TipoProdottoEng tipo = TipoProdottoEng.valueOf(type.toString());
				if ((!searched.equals("") && !prod.getName().contains(searched)) || !(prod.getCategoria() == tipo)) {
					continue;
				}
				AnchorPane item = new AnchorPane();
				item.setPrefSize(400, 400);

				Text costoProdotto = new Text(prod.getCosto() + "�");
				Text nomeProdotto = new Text(prod.getName());
				Separator separator = new Separator(Orientation.HORIZONTAL);
				Text descrizioneProdotto = new Text(prod.getDescrizione());
				Separator separator2 = new Separator(Orientation.HORIZONTAL);
				item.setId(String.valueOf(prod.getProdottoID()));
				Text ricettaProdotto = new Text("RECEIPT:\n");
				Separator separator3 = new Separator(Orientation.HORIZONTAL);
				Text categoriaProdotto = new Text(prod.getCategoria().toString());
				Text allergeniProdotto = new Text("*may contains traces of:" + prod.getAllergeni());

				CustomButton removebutton = new CustomButton();
				removebutton.setId("removeButton");
				removebutton.setPrefSize(50, 50);
				CustomButton editbutton = new CustomButton();
				editbutton.setId("editButton");
				editbutton.setPrefSize(50, 50);

				nomeProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 30));
				nomeProdotto.setFill(Color.WHITE);
				costoProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 20));
				costoProdotto.setFill(Color.WHITE);
				descrizioneProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 15));
				descrizioneProdotto.setFill(Color.WHITE);
				;
				ricettaProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 15));
				ricettaProdotto.setFill(Color.WHITE);
				allergeniProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 12));
				allergeniProdotto.setFill(Color.WHITE);
				categoriaProdotto.setFont(Font.font("MontSerrat", FontWeight.NORMAL, 20));
				categoriaProdotto.setFill(Color.WHITE);

				json = askData("prodotti/", "GET", "", item.getId(), "ricetta");
				logger.info("RISULTATO RICHIESTA GET PER TABELLA PRODOTTI INGLESI : " + json);
				array = json.getJSONArray("values");
				a = String.valueOf(array).split(",");
				ArrayList<Ingrediente> ingredienti = new ArrayList<Ingrediente>();
				for (int i = 0; i < a.length; i += 3) {
					ingredienti.add(new Ingrediente(a[i].replace("\"", "").replace("[", ""),
							Integer.valueOf(a[i + 1].replace("\"", "")),
							Integer.valueOf(a[i + 2].replace("\"", "").replace("]", ""))));
				}

				for (Ingrediente ingrediente : ingredienti) {
					JSONObject json2 = askData("ingredienti/", "GET", "",
							String.valueOf(ingrediente.getIngredienteId()));
					ricettaProdotto.setText(
							ricettaProdotto.getText() + " " + Translator.Translate("", "en", json2.getString("nome"))
									+ ": " + ingrediente.getQuantita() + ";\n");
				}

				removebutton.setOnMouseClicked(new EventHandler<Event>() {
					@Override
					public void handle(Event arg0) {
						try {
							setProdotto(item.getId());
							removeProduct(arg0);
							buildDataEng(searched, comboBox_cerca_prod.getSelectionModel().getSelectedItem());
						} catch (Exception e) {
							logger.error(e);
							e.printStackTrace();
						}
					}
				});

				editbutton.setOnMouseClicked(new EventHandler<Event>() {
					@Override
					public void handle(Event arg0) {
						try {
							setProdotto(item.getId());
							changeSceneNotFullscreen(arg0, "AddDishMenuScene");
							buildDataEng(searched, comboBox_cerca_prod.getSelectionModel().getSelectedItem());
						} catch (Exception e) {
							logger.error(e);
							e.printStackTrace();
						}
					}
				});

				item.getChildren().addAll(nomeProdotto, costoProdotto, descrizioneProdotto, ricettaProdotto,
						allergeniProdotto, categoriaProdotto, removebutton, editbutton, separator, separator2,
						separator3);
				item.setTopAnchor(nomeProdotto, 10.0);
				item.setTopAnchor(costoProdotto, 20.0);
				item.setRightAnchor(costoProdotto, 0.0);
				item.setTopAnchor(separator, 41.0);
				item.setLeftAnchor(separator, 0.0);
				item.setRightAnchor(separator, 0.0);
				item.setTopAnchor(categoriaProdotto, 42.0);
				item.setTopAnchor(separator2, 63.0);
				item.setLeftAnchor(separator2, 0.0);
				item.setRightAnchor(separator2, 0.0);
				item.setTopAnchor(descrizioneProdotto, 64.0);
				item.setTopAnchor(separator3, 125.0);
				item.setLeftAnchor(separator3, 0.0);
				item.setRightAnchor(separator3, 0.0);
				item.setTopAnchor(ricettaProdotto, 126.0);
				item.setBottomAnchor(allergeniProdotto, 100.0);
				item.setBottomAnchor(removebutton, 20.0);
				item.setLeftAnchor(removebutton, 20.0);
				item.setBottomAnchor(editbutton, 20.0);
				item.setRightAnchor(editbutton, 20.0);

				if (!isAdmin) {
					item.getChildren().removeAll(removebutton, editbutton);
				}
				products_box.getChildren().add(item);
			}

			products_box.setVgap(20);
			products_box.setHgap(20);
			products_box.setPadding(new Insets(20));
		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
		}
	}
}
