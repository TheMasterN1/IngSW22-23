package controllers;

import application.CustomButton;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dto.Ordinazione;
import dto.ProdottoIta;
import dto.Tavolo;
import enumerations.TipoProdottoIta;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

public class AddOrdersController extends ExtendedController {

	@FXML
	private Pane pane;
	@FXML
	private CustomButton addButton;
	@FXML
	private ComboBox<Integer> choice_tables = new ComboBox<>();
	@FXML
	private FlowPane table_ordinazione;

	static Logger logger = Logger.getLogger(AddOrdersController.class);

	@FXML
	public void initialize() {

		if (!isAdmin)
			pane.getChildren().remove(addButton);

		buildComboBox();

		try {
			JSONObject json = askData("prodotti/", "GET", "");
			logger.info("RISULTATO DELLA RICHIESTA GET DEI PRODOTTI : " + json);
			JSONArray array = json.getJSONArray("values");
			String[] a = String.valueOf(array).split(",");
			ArrayList<ProdottoIta> rs = new ArrayList<ProdottoIta>();
			for (int i = 0; i < a.length; i += 6) {
				rs.add(new ProdottoIta(Float.valueOf(a[i].replace("\"", "").replace("[", "")),
						a[i + 1].replace("\"", ""), a[i + 2].replace("\"", ""), a[i + 3].replace("\"", ""),
						Integer.valueOf(a[i + 4].replace("\"", "")),
						TipoProdottoIta.valueOf(a[i + 5].replace("\"", "").replace("]", ""))));
			}
			for (ProdottoIta prodotto : rs) {

				Text nomeProdotto = new Text(prodotto.getName());
				nomeProdotto.setFont(Font.font("System", FontWeight.BOLD, 12));
				nomeProdotto.setFill(Color.WHITE);

				Spinner<Integer> quantitaProdotto = new Spinner<>(
						new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 5, 0, 1));

				GridPane stack = new GridPane();
				stack.add(nomeProdotto, 0, 0);
				stack.add(quantitaProdotto, 1, 0);
				stack.setHgap(20);
				table_ordinazione.getChildren().add(stack);
			}
		} catch (Exception ex) {
			logger.error(ex);
			throw new RuntimeException(ex);
		}

		table_ordinazione.setVgap(20);
		table_ordinazione.setHgap(20);
		table_ordinazione.setPadding(new Insets(20));

	}

	@FXML
	public void cancelAdd(ActionEvent event) throws IOException, InterruptedException {
		closeAndReEnable(event);
	}

	@SuppressWarnings("unchecked")
	@FXML
	public void confirmAdd(ActionEvent event) throws IOException, InterruptedException {
		try {
			Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.IDENTITY).create();
			for (Node ricetta : table_ordinazione.getChildren()) {
				GridPane pane = (GridPane) ricetta;

				Text nome = (Text) pane.getChildren().get(0);

				Spinner<Integer> quantit� = (Spinner<Integer>) pane.getChildren().get(1);

				Ordinazione ordinazione = new Ordinazione(choice_tables.getValue(), quantit�.getValue(),
						nome.getText());

				if (quantit�.getValue() == 0)
					continue;
				askData("ordini/", "POST", gson.toJson(ordinazione));
				logger.info("INSERIMENTO ORDINE. DATI INSERIMENTO : " + gson.toJson(ordinazione));
			}
		} catch (Exception e) {
			logger.error(e);
			throw new RuntimeException(e);
		}
		closeAndReEnable(event);
	}

	@FXML
	public void buildComboBox() {
		try {
			JSONObject json = askData("tavoli/", "GET", "", String.valueOf(utente.getIdSala()));
			logger.info("POPOLAMENTO COMBO BOX TAVOLI : " + json);
			JSONArray array = json.getJSONArray("values");
			String[] a = String.valueOf(array).split(",");
			ArrayList<Tavolo> tavoli = new ArrayList<Tavolo>();
			for (int i = 0; i < a.length; i += 3) {
				tavoli.add(new Tavolo(Integer.valueOf(a[i].replace("\"", "").replace("[", "")),
						Integer.valueOf(a[i + 1].replace("\"", "")),
						Integer.valueOf(a[i + 2].replace("\"", "").replace("]", ""))));
			}
			for (Tavolo tavolo : tavoli) {
				choice_tables.getItems().add(tavolo.getIDTavolo());
			}

			choice_tables.setValue(chosen_table);

		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e);
		}
	}
}
