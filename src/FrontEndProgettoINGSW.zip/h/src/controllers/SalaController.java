package controllers;

import java.io.IOException;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

import application.CustomButton;
import dto.Tavolo;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class SalaController extends ExtendedController {

	@FXML
	private FlowPane tables_box;
	@FXML
	private Label label_id;
	@FXML
	private Pane pane;
	private ArrayList<Tavolo> tavoli = new ArrayList<>();

	@FXML
	public void initialize() throws IOException, InterruptedException {
		setPane(pane);
		JSONObject json = askData("tavoli/", "GET", "", String.valueOf(utente.getIdSala()));
		logger.info("RISULTATO GET TAVOLI INITIALIZE : " + json);
		JSONArray array = json.getJSONArray("values");
		String[] a = String.valueOf(array).split(",");
		for (int i = 0; i < a.length; i += 3) {
			tavoli.add(new Tavolo(Integer.valueOf(a[i].replace("\"", "").replace("[", "")),
					Integer.valueOf(a[i + 1].replace("\"", "")),
					Integer.valueOf(a[i + 2].replace("\"", "").replace("]", ""))));
		}
		buildData();
	}

	private void buildData() {
		try {
			tables_box.getChildren().clear();
			for (Tavolo tavolo : tavoli) {
				ImageView img = new ImageView(new Image(getClass().getResourceAsStream(("../files/dining-table.png"))));
				img.setPreserveRatio(true);
				img.setFitWidth(250);
				img.setFitHeight(250);

				CustomButton table = new CustomButton();
				table.setGraphic(img);
				table.setPrefSize(250, 250);

				Text text = new Text(String.valueOf(tavolo.getIDTavolo()));
				text.setFont(Font.font(180));
				text.setOpacity(0.5);

				JSONObject json2 = askData("ordini/", "GET", "", String.valueOf(tavolo.getIDTavolo()));
				text.setFill((json2.getInt("count") > 0) ? Color.ORANGE : Color.DARKBLUE);

				StackPane stack = new StackPane();
				stack.getChildren().addAll(text, table);

				table.setOnMouseClicked(new EventHandler<Event>() {
					@Override
					public void handle(Event event) {
						try {
							chosen_table = tavolo.getIDTavolo();
							logger.info("CAMBIATA SCENE IN : ADDORDERSSCENE DA SALACONTROLLER");
							changeSceneNotFullscreen(event, "AddOrdersScene");
							new Thread(() -> {
								while (paneController.isDisable()) {
								}
								Platform.runLater(() -> {

									buildData();
								});
							}).start();
						} catch (IOException e) {
							logger.error(e);
							e.printStackTrace();
						} catch (InterruptedException e) {
							logger.error(e);
							e.printStackTrace();
						}
					}
				});

				tables_box.getChildren().add(stack);
			}
			tables_box.setVgap(20);
			tables_box.setHgap(20);
			tables_box.setPadding(new Insets(20));
			label_id.setText("Sala: " + utente.getIdSala());

		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
		}
	}

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "HomePageScene");
		logger.info("CAMBIATA SCENE IN : HOMEPAGESCENE DA SALACONTROLLER");
	}
}
