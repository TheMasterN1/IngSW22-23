package controllers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.internal.LinkedTreeMap;

import application.JsonReader;
import application.Translator;
import dto.Ingrediente;
import dto.Prodotto;
import dto.ProdottoIta;
import enumerations.Allergeni;
import enumerations.TipoProdottoIta;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class AddDishMenuController extends ExtendedController {

	@FXML
	private TextField txt_nome_prodotto = new TextField();
	@FXML
	private TextArea txt_descrizione_prodotto;
	@FXML
	private ListView<Allergeni> txt_allergeni;
	@FXML
	private Spinner<Double> txt_costo = new Spinner<>();
	@FXML
	private ComboBox<TipoProdottoIta> comboBox_categoria = new ComboBox<>();
	@FXML
	private FlowPane table_ricetta;
	static Logger log = Logger.getLogger(AddDishMenuController.class);

	@SuppressWarnings({ "rawtypes", "unchecked", "unlikely-arg-type" })
	@FXML
	public void initialize() {
		txt_allergeni.setItems(FXCollections.observableArrayList(Allergeni.values()));
		txt_allergeni.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		txt_allergeni.setTooltip(new Tooltip("Tenere premuto CTRL per la multi-selezione"));

		txt_descrizione_prodotto.setWrapText(true);

		comboBox_categoria.setItems(FXCollections.observableArrayList(TipoProdottoIta.values()));

		if (MenuController.prodotto.getProdottoID() != 0) {
			txt_nome_prodotto.setText(MenuController.prodotto.getName());
			txt_descrizione_prodotto.setText(MenuController.prodotto.getDescrizione());
			txt_costo.getValueFactory().setValue(Double.valueOf(MenuController.prodotto.getCosto()));
			comboBox_categoria.setValue(MenuController.prodotto.getCategoria());
		}

		try {
			JSONObject json = askData("ingredienti/", "GET", "");
			log.info("RISULTATO RICHIESTA DI GET PER GLI INGREDIENTI : " + json);
			JSONArray array = json.getJSONArray("values");
			String[] a = String.valueOf(array).split(",");
			ArrayList<Ingrediente> ingredienti = new ArrayList<Ingrediente>();
			for (int i = 0; i < a.length; i += 3) {
				ingredienti.add(new Ingrediente(a[i].replace("\"", "").replace("[", ""),
						Integer.valueOf(a[i + 1].replace("\"", "")),
						Integer.valueOf(a[i + 2].replace("\"", "").replace("]", ""))));
				log.info("ingrediente aggiunto : " + a[i]);
			}
			for (Ingrediente ingrediente : ingredienti) {

				Text nomeProdotto = new Text(ingrediente.getNome());
				nomeProdotto.setFont(Font.font("System", FontWeight.BOLD, 12));
				nomeProdotto.setFill(Color.WHITE);

				Spinner<Integer> quantitaProdotto = new Spinner<>(
						new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 5, 0, 1));

				GridPane stack = new GridPane();
				stack.add(nomeProdotto, 0, 0);
				stack.add(quantitaProdotto, 1, 0);
				stack.setHgap(20);
				table_ricetta.getChildren().add(stack);
			}
		} catch (Exception ex) {
			log.error("exception : " + ex);
			throw new RuntimeException(ex);
		}

		table_ricetta.setVgap(20);
		table_ricetta.setHgap(20);
		table_ricetta.setPadding(new Insets(20));

		txt_nome_prodotto.textProperty().addListener((observable, oldValue, newValue) -> {
			if (newValue.length() >= 3) {
				Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.IDENTITY).create();

				new Thread(new Runnable() {
					@Override
					public void run() {
						JsonReader jsonReader = new JsonReader();

						String url = jsonReader.readFromUrlProdotto(newValue);

						Map<ArrayList<LinkedTreeMap>, Object> map = new HashMap<ArrayList<LinkedTreeMap>, Object>();
						map = (Map<ArrayList<LinkedTreeMap>, Object>) gson.fromJson(url, map.getClass());

						if (map != null) {
							ArrayList<LinkedTreeMap> arr = (ArrayList<LinkedTreeMap>) map.get("meals");
							if (arr != null) {
								LinkedTreeMap linkedTreeMap = (LinkedTreeMap) arr.get(0);
								String nome = linkedTreeMap.get("strMeal").toString();

								try {
									nome = Translator.Translate("", "it", nome);
									log.info("PAROLA TRADOTTA, PRIMA : " + txt_nome_prodotto.getText() + "DOPO : "
											+ nome);
									txt_nome_prodotto.setText(nome);
								} catch (IOException e) {
									log.error(e);
									throw new RuntimeException(e);
								}
							}
						}
					}
				}).start();
			}

		});
	}

	@FXML
	public void cancelAdd(ActionEvent event) throws IOException, InterruptedException {
		closeAndReEnable(event);
	}

	@SuppressWarnings("unchecked")
	@FXML
	private void addQtProduct(ActionEvent event) throws IOException, InterruptedException {
		if (txt_nome_prodotto.getText().length() > 0 && txt_descrizione_prodotto.getText().length() > 0
				&& txt_nome_prodotto.getText().length() > 0 && Float.parseFloat(txt_costo.getValue().toString()) > 0
				&& comboBox_categoria.getValue() != null) {
			try {
				Gson gson = new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.IDENTITY).create();

				ProdottoIta prodottoIta = new ProdottoIta(Float.parseFloat(txt_costo.getValue().toString()),
						txt_nome_prodotto.getText().toString(),
						txt_allergeni.getSelectionModel().getSelectedItem().toString(),
						txt_descrizione_prodotto.getText(),
						TipoProdottoIta.valueOf(comboBox_categoria.getValue().toString()));

				log.info("INVIO DATI PER L'AGGIUNTA DI UN PRODOTTO (POST)");
				log.info("DATI INVIATI : " + gson.toJson(prodottoIta));
				askData("prodotti/", "POST", gson.toJson(prodottoIta));
				for (Node ricetta : table_ricetta.getChildren()) {
					GridPane pane = (GridPane) ricetta;

					Text nome = (Text) pane.getChildren().get(0);

					Spinner<Integer> quantita = (Spinner<Integer>) pane.getChildren().get(1);

					if (quantita.getValue() == 0)
						continue;
					askData("prodotti/", "PUT", "", txt_nome_prodotto.getText().replace(" ", "_"),
							nome.getText().replace(" ", "_"), String.valueOf(quantita.getValue().intValue()));
					log.info("prodotto cercato : " + txt_nome_prodotto.getText() + "quantit� : "
							+ quantita.getValue().toString());
				}
				closeAndReEnable(event);
			} catch (Exception e) {
				log.error(e);
				throw new RuntimeException(e);
			}
		} else {
			Alert a = new Alert(Alert.AlertType.ERROR);
			a.setTitle("ERRORE");
			a.setContentText("errore, campi mancanti o sbagliati");
			log.error("errore, campi mancanti o sbagliati");
			a.show();
		}
	}
}
