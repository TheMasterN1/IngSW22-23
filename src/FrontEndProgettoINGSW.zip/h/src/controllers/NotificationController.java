package controllers;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import application.CustomButton;
import dto.Notifiche;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;

public class NotificationController extends ExtendedController {

	@FXML
	private Pane pane;
	@FXML
	private CustomButton addButton;
	@FXML
	private TextField txt_cerca_testo;
	@FXML
	private TableView<Notifiche> tableNotifiche = new TableView<>();
	@FXML
	private RadioButton check_readen;
	public static Notifiche notifiche;
	private JSONObject json;
	static Logger logger = Logger.getLogger(NotificationController.class);

	@FXML
	public void initialize() {
		if (!isAdmin)
			pane.getChildren().remove(addButton);

		buildData();
		setPane(pane);

		tableNotifiche.setRowFactory(tv -> {
			TableRow<Notifiche> row = new TableRow<>();
			row.setOnMouseClicked(event -> {
				try {
					if (row.isEmpty())
						return;
					notifiche = row.getItem();
					logger.info("notifica selezionata : " + row.getItem());
					changeSceneNotFullscreen(event, "SendNotificationScene");
					new Thread(() -> {
						while (paneController.isDisable()) {
						}
						Platform.runLater(() -> {

							rebuildData();
						});
					}).start();
				} catch (IOException e) {
					logger.error(e);
					throw new RuntimeException(e);
				} catch (InterruptedException e) {
					logger.error(e);
					throw new RuntimeException(e);
				}
			});
			return row;
		});

		check_readen.setOnMouseClicked(arg0 -> {
			rebuildData();
		});
	}

	@FXML
	public void back(ActionEvent event) throws IOException, InterruptedException {
		changeSceneFullscreen(event, "HomePageScene");
		logger.info("CAMBIATA SCENE IN : HOMEPAGESCENE DA NOTIFICATIONCONTROLLER");
	}

	@FXML
	public void create(ActionEvent event) throws IOException, InterruptedException {
		setPane(pane);
		disableStage();
		notifiche = new Notifiche(0, "", "", 0);
		changeSceneNotFullscreen(event, "SendNotificationScene");
		logger.info("CAMBIATA SCENE IN : SENDNOTIFICATIONSCENE DA NOTIFICATIONCONTROLLER");
		new Thread(() -> {
			while (paneController.isDisable()) {
			}
			Platform.runLater(() -> {

				rebuildData();
			});
		}).start();
	}

	@FXML
	public void buildData() {
		try {
			json = askData("notifiche/", "GET", "", String.valueOf(utente.getId()), "N");
			logger.info("RISULTATO GET PER TABELLA NOTIFICHE " + json);
			JSONArray array = json.getJSONArray("values");
			String[] a = String.valueOf(array).split("\",");
			ArrayList<Notifiche> notifiche = new ArrayList<Notifiche>();
			for (int i = 0; i < a.length; i += 4) {
				if (a.length == 1)
					break;
				notifiche.add(new Notifiche(Integer.valueOf(a[i].replace("\"", "").replace("[", "")),
						a[i + 1].replace("\"", ""), a[i + 2].replace("\"", ""),
						Integer.valueOf(a[i + 3].replace("\"", "").replace("]", ""))));
			}
			ObservableList<Notifiche> data = FXCollections.observableArrayList();
			tableNotifiche.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);
			TableColumn<Notifiche, String> column1 = new TableColumn<>("Numero Notifica");
			TableColumn<Notifiche, String> column2 = new TableColumn<>("Oggetto");
			TableColumn<Notifiche, String> column3 = new TableColumn<>("Testo");
			TableColumn<Notifiche, String> column4 = new TableColumn<>("Inviato Da");
			column1.setCellValueFactory(new PropertyValueFactory<Notifiche, String>("IDnotifiche"));
			column2.setCellValueFactory(new PropertyValueFactory<Notifiche, String>("oggetto"));
			column3.setCellValueFactory(new PropertyValueFactory<Notifiche, String>("testo"));
			column4.setCellValueFactory(new PropertyValueFactory<Notifiche, String>("idUtente"));

			for (Notifiche notifica : notifiche) {
				data.add(notifica);
			}

			FilteredList<Notifiche> filteredData = new FilteredList<>(data, b -> true);

			txt_cerca_testo.textProperty().addListener((observable, oldValue, newValue) -> {
				filteredData.setPredicate(dato -> {
					if (newValue == null || newValue.isEmpty()) {
						return true;
					}

					String lowerCaseFilter = newValue.toLowerCase();

					if (dato.getOggetto().toLowerCase().indexOf(lowerCaseFilter) != -1) {
						return true;
					} else {
						return false;
					}
				});
			});

			SortedList<Notifiche> sortedList = new SortedList<>(filteredData);
			sortedList.comparatorProperty().bind(tableNotifiche.comparatorProperty());

			// FINALLY ADDED TO TableView
			tableNotifiche.getColumns().addAll(column1, column2, column3, column4);
			tableNotifiche.setItems(sortedList);

		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	@FXML
	public void rebuildData() {
		try {
			if (!check_readen.isSelected()) {
				json = askData("notifiche/", "GET", "", String.valueOf(utente.getId()), "N");
				logger.info("RISULTATO GET NOTIFICHE NON LETTE : " + json);
			} else {
				json = askData("notifiche/", "GET", "", String.valueOf(utente.getId()), "Y");
				logger.info("RISULTATO GET NOTIFICHE LETTE : " + json);
			}

			JSONArray array = json.getJSONArray("values");
			String[] a = String.valueOf(array).split("\",");
			ArrayList<Notifiche> notifiche = new ArrayList<Notifiche>();
			for (int i = 0; i < a.length; i += 4) {
				if (a.length == 1)
					break;
				notifiche.add(new Notifiche(Integer.valueOf(a[i].replace("\"", "").replace("[", "")),
						a[i + 1].replace("\"", ""), a[i + 2].replace("\"", ""),
						Integer.valueOf(a[i + 3].replace("\"", "").replace("]", ""))));
			}
			ObservableList<Notifiche> data = FXCollections.observableArrayList();

			tableNotifiche.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);

			for (Notifiche notifica : notifiche) {
				// Iterate Row
				data.add(notifica);
			}

			tableNotifiche.setItems(data);

		} catch (Exception ex) {
			logger.error(ex);
			throw new RuntimeException(ex);
		}
	}
}