package dto;

public class Tavolo {
	int iDTavolo;
	int nPosti;
	int iDsala;

	public Tavolo(int iDTavolo, int nPosti, int iDsala) {
		super();
		this.iDTavolo = iDTavolo;
		this.nPosti = nPosti;
		this.iDsala = iDsala;
	}

	public int getIDTavolo() {
		return iDTavolo;
	}

	public void setIDTavolo(int iDTavolo) {
		this.iDTavolo = iDTavolo;
	}

	public int getnPosti() {
		return nPosti;
	}

	public void setnPosti(int nPosti) {
		this.nPosti = nPosti;
	}

	public int getIDsala() {
		return iDsala;
	}

	public void setIDsala(int iDsala) {
		this.iDsala = iDsala;
	}
}
