package dto;

import enumerations.TipoProdottoIta;

import java.io.Serializable;

public class ProdottoIta extends Prodotto implements Serializable {
	TipoProdottoIta categoria;

	public ProdottoIta(float costo, String name, String allergeni, String descrizione, int prodottoID,
			TipoProdottoIta categoria) {
		super(costo, name, allergeni, descrizione, prodottoID);
		this.categoria = categoria;
	}

	public ProdottoIta(float costo, String name, String allergeni, String descrizione, TipoProdottoIta categoria) {
		super(costo, name, allergeni, descrizione);
		this.categoria = categoria;
	}

	public ProdottoIta() {
	}

	public TipoProdottoIta getCategoria() {
		return categoria;
	}

	public void setCategoria(TipoProdottoIta categoria) {
		this.categoria = categoria;
	}
}
