package enumerations;

public enum TipoProdottoEng {
	First, Second, SideDish, Sweet, Appetizer, Drink
}
