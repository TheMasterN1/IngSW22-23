package com.example.backendingsw.dao;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.example.backendingsw.dto.Tavolo;

public interface TavoloDAOInterface {
	ResultSet InserisciTavolo(int tavoloID, int numeroPosti, int salaID) throws Exception;

	ResultSet RimuoviTavolo(int id) throws Exception;

	ArrayList<Tavolo> ListaTavolo(int salaID) throws Exception;

	ArrayList<Tavolo> ListaTavoliSingoli(int salaID) throws Exception;
}
