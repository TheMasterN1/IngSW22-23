package com.example.backendingsw.dao;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.example.backendingsw.dto.Notifiche;

public interface NotificheDAOInterface {
	ResultSet InserisciMessaggio(Notifiche notifiche) throws Exception;

	ResultSet inserimentoMessaggioPerVisualizzazione(int idUtente, int idNotifica) throws Exception;

	ResultSet RimuoviMessaggio(int id) throws Exception;

	ResultSet RimuoviMessaggioVisualizzazione(int id) throws Exception;

	ResultSet UpdateTestoMessaggio(int id, int idUtente, String oggetto, String testo) throws Exception;

	ResultSet ListaMessaggi() throws Exception;

	ArrayList<Notifiche> ListaMessaggiSpecifici(int idUtente) throws Exception;

	ResultSet UpdateVisualizzazione(int idUtente, int idNotifiche) throws Exception ;

	ResultSet MaxIDMessaggi() throws Exception;
	
	int CheckDaVisualizzare(int idUtente) throws Exception;

	ArrayList<Notifiche> ListaNotificheVisualizzate(int idUtente) throws Exception;
}
