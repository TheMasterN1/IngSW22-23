package com.example.backendingsw.dto;

public class Prodotto {
    float costo;
    String name;
    String allergeni;
    String descrizione;
    int prodottoID;

    public Prodotto(float costo, String name, String allergeni, String descrizione, int prodottoID){
        this.costo = costo;
        this.name = name;
        this.allergeni = allergeni;
        this.descrizione = descrizione;
        this.prodottoID = prodottoID;
    }

    @Override
    public String toString() {
            return  "\"" + costo +
                    "\", \"" + name +
                    "\", \"" + allergeni +
                    "\", \"" + descrizione +
                    "\", \"" + prodottoID + "\"";
    }

    public Prodotto(){}

	public float getCosto() {
        return costo;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAllergeni() {
        return allergeni;
    }

    public void setAllergeni(String allergeni) {
        this.allergeni = allergeni;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public int getProdottoID() {
        return prodottoID;
    }

    public void setProdottoID(int prodottoID) {
        this.prodottoID = prodottoID;
    }
}
