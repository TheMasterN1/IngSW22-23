package com.example.backendingsw.dao;

import com.example.backendingsw.dto.Utente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UtenteDAO implements UtenteDAOInterface {

	@Override
	public ResultSet InserisciUtente(Utente utente)
			throws Exception {
		Connection con = null;
		String sql = "Insert into utente(username, password, ruolo, IDsala, nuovoUtente) VALUES(?,?,?,?,?)";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, utente.getUsername());
		p1.setString(2, utente.getPassword());
		p1.setString(3, utente.getRuolo());
		p1.setInt(4, utente.getId());
		p1.setString(5, "Y");
		ResultSet rs1 = p1.executeQuery();
		con.close();
		rs1.close();
		return rs1;
	}

	@Override
	public int UpdateUtente(Utente utente)
			throws Exception {
		Connection con = null;
		String sql = "Update utente set username=?, password=?, ruolo=?, nuovoUtente=? where utente.id= ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, utente.getUsername());
		p1.setString(2, utente.getPassword());
		p1.setString(3, utente.getRuolo());
		p1.setString(4, "N");
		p1.setInt(5, utente.getId());
		int rs1 = p1.executeUpdate();
		con.close();
		return rs1;
	}
	@Override
	public Utente autentificazioneUtente(String nome, String pass) throws Exception {
		Connection con = null;
		String sql = "select * from utente where username = ? AND password = ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, nome.trim());
		p1.setString(2, pass.trim());
		ResultSet rs = p1.executeQuery();
		rs.beforeFirst();
		con.close();
		Utente utente = null;
		while (rs.next()){
			utente = new Utente(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getInt(5));
			utente.setNew(!rs.getString(6).equals("N"));
		}
		return utente;
	}

	public ResultSet IDListaUtenti() throws Exception{
		Connection con = null;
		String sql = "select id from utente";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}
}
