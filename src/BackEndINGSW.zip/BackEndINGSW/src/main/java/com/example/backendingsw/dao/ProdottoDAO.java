package com.example.backendingsw.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.example.backendingsw.dto.Ingrediente;
import com.example.backendingsw.dto.ProdottoIta;
import com.example.backendingsw.enumerations.TipoProdottoIta;

public class ProdottoDAO implements ProdottoDAOInterface {

	@Override
	public ResultSet InserisciProdotto(ProdottoIta prodottoIta) throws Exception {
		Connection con = null;
		String sql = "Insert into prodotto(costo, nome, descrizione, categoria, allergeni) VALUES(?,?,?,?,?)";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setFloat(1, prodottoIta.getCosto());
		p1.setString(2, prodottoIta.getName());
		p1.setString(3, prodottoIta.getDescrizione());
		p1.setString(4, prodottoIta.getCategoria().toString());
		p1.setString(5, prodottoIta.getAllergeni().substring(1, prodottoIta.getAllergeni().length()-1));

		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet RimuoviProdotto(int id) throws Exception {
		Connection con = null;
		String sql = "delete from prodotto where prodottoID=? ";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, id);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet UpdateProdotti(String nome, int quantita) throws Exception {
		Connection con = null;
		String sql = "Update prodotto set quantita=? where prodotto.nome= ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, quantita);
		p1.setString(2, nome);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ArrayList<ProdottoIta> ListaProdotti() throws Exception {
		Connection con = null;
		String sql = "select * from prodotto";
		try {
			con = dbConnection.getConnection();
		} catch (Exception e) {
			e.printStackTrace();
		}
		PreparedStatement p1 = con.prepareStatement(sql);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		ArrayList<ProdottoIta> prodotti = new ArrayList<>();
		while(rs1.next()) {
			prodotti.add(new ProdottoIta(rs1.getFloat(1), rs1.getString(2), rs1.getString(6), rs1.getString(3), rs1.getInt(4), TipoProdottoIta.valueOf(rs1.getString(5))));
		}
		return prodotti;
	}
	
	@Override
	public ResultSet ListaProdottiPerNome(String nome) throws Exception {
		Connection con = null;
		String sql = "select prodottoID from prodotto where nome = ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, nome);
		ResultSet rs1 = p1.executeQuery();
		con.close();

		return rs1;
	}

	@Override
	public ProdottoIta ListaProdotti_specifica(String id) throws Exception {
		Connection con = null;
		String sql = "select * from prodotto where prodottoID = ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, id);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		rs1.next();
		return new ProdottoIta(rs1.getFloat(1), rs1.getString(2), rs1.getString(6), rs1.getString(3), rs1.getInt(4), TipoProdottoIta.valueOf(rs1.getString(5)));
	}
	
	@Override
	public ResultSet InserisciRicetta(String prodotto, String ingrediente, Integer quantita) throws Exception {
		Connection con = null;
		IngredienteDAO ingredienteDAO = new IngredienteDAO();
		ResultSet rs = ListaProdottiPerNome(prodotto);
		ResultSet rs2 = ingredienteDAO.ListaIngredientiSpecifica(ingrediente);
		rs2.next();
		rs.next();
		String sql = "Insert Into ricetta values(?,?,?)";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, rs.getInt(1));
		p1.setInt(2, rs2.getInt(2));
		p1.setInt(3, quantita);
		ResultSet rs1 = p1.executeQuery();
		con.close();

		return rs1;
	}
	
	public ResultSet UpdateProdottoNomeEDescrizione(String nome, String descrizione, int prodID) throws Exception{
		Connection con = null;
		String sql = "Update prodotto set nome=?, descrizione = ? where prodottoID= ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, nome);
		p1.setString(2, descrizione);
		p1.setInt(3, prodID);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	public ArrayList<Ingrediente> getRicetta(String string) throws Exception {
		Connection con = null;
		String sql = "Select * from ricetta where prodottoID = ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, string);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		ArrayList<Ingrediente> ingredienti = new ArrayList<>();
		while(rs1.next()) {
			ingredienti.add(new Ingrediente(rs1.getString(1), rs1.getInt(2), rs1.getInt(3)));
		}
		return ingredienti;
	}
}
