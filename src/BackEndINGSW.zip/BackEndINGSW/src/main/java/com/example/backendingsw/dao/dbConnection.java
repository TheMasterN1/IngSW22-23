package com.example.backendingsw.dao;

import java.sql.Connection;

import java.sql.DriverManager;
import javax.swing.JOptionPane;


public class dbConnection {

	private static String jdbcURL="jdbc:mariadb://localhost:3306/ratatouille";
	private static String username="root";
	private static String password="123";
	private static Connection con;

	public static Connection getConnection() {
		try {
			con = DriverManager.getConnection(jdbcURL, username, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}
}
