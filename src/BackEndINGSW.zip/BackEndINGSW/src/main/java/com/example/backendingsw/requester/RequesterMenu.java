package com.example.backendingsw.requester;

import com.example.backendingsw.dao.IngredienteDAO;
import com.example.backendingsw.dto.Ingrediente;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController()
@RequestMapping("/ingredienti")
public class RequesterMenu {//TODO cambiare in base al nome tutti i metodi
    //    IngredienteDAO dao = new IngredienteDAO();
//
//    @GetMapping("/")
//    public ArrayList<Ingrediente> getIngredienti() throws Exception {
//        return dao.ListaIngredienti();
//    }
//
//    @PostMapping("/")
//    public void addIngredient(@RequestBody Ingrediente ingrediente) throws Exception {
//        dao.InserisciIngrediente(ingrediente);
//    }
//
//    @PutMapping("/{id}")
//    public void updateIngrediente(@RequestBody Ingrediente ingrediente, @PathVariable int id) throws Exception {
//        dao.UpdateIngredienti(ingrediente, id);
//    }
//
//    @DeleteMapping("/{id}")
//    public void deleteIngrediente(@PathVariable int id) throws Exception {
//        dao.RimuoviIngrediente(id);
//    }
}
