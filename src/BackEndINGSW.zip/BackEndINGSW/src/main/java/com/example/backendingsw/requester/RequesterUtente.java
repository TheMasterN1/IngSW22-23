package com.example.backendingsw.requester;

import com.example.backendingsw.dao.UtenteDAO;
import com.example.backendingsw.dto.Utente;
import org.springframework.web.bind.annotation.*;

@RestController()
@RequestMapping("/utente")
public class RequesterUtente {
    UtenteDAO dao = new UtenteDAO();

    @PutMapping("/{user}/{pass}")
    public Utente getUtenti(@PathVariable("user") String user, @PathVariable("pass") String pass) throws Exception {
        return dao.autentificazioneUtente(user, pass);
    }

    @PostMapping("/")
    public void addUtente(@RequestBody Utente utente) throws Exception {
        dao.InserisciUtente(utente);
    }

    @PutMapping("/")
    public void updateUtente(@RequestBody Utente utente) throws Exception {
        dao.UpdateUtente(utente);
    }

}
