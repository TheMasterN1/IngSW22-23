package com.example.backendingsw.requester;

import com.example.backendingsw.dao.IngredienteDAO;
import com.example.backendingsw.dao.SalaDAO;
import com.example.backendingsw.dto.Ingrediente;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController()
@RequestMapping("/sale")
public class RequesterSala {//TODO cambiare in base al nome tutti i metodi
    SalaDAO dao = new SalaDAO();

    @GetMapping("/")
    public String getSale() throws Exception {
        return "{\"values\":"+dao.GetAllSale()+"}";
    }

//    @PostMapping("/")
//    public void addIngredient(@RequestBody Ingrediente ingrediente) throws Exception {
//        dao.InserisciIngrediente(ingrediente);
//    }
//
//    @PutMapping("/{id}")
//    public void updateIngrediente(@RequestBody Ingrediente ingrediente, @PathVariable int id) throws Exception {
//        dao.UpdateIngredienti(ingrediente, id);
//    }
//
//    @DeleteMapping("/{id}")
//    public void deleteIngrediente(@PathVariable int id) throws Exception {
//        dao.RimuoviIngrediente(id);
//    }
}
