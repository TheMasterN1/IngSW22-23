package com.example.backendingsw.dto;

public class Ordinazione {
    int idTavolo;
    int quantità;
    String idProdotto;

    public Ordinazione(int idTavolo, int quantità, String idProdotto) {
        this.idTavolo = idTavolo;
        this.quantità = quantità;
        this.idProdotto = idProdotto;
    }

    public int getIdTavolo() {
        return idTavolo;
    }

    public void setIdTavolo(int idTavolo) {
        this.idTavolo = idTavolo;
    }

    public int getQuantità() {
        return quantità;
    }

    public void setQuantità(int quantità) {
        this.quantità = quantità;
    }

    public String getIdProdotto() {
        return idProdotto;
    }

    public void setIdProdotto(String idProdotto) {
        this.idProdotto = idProdotto;
    }
}
