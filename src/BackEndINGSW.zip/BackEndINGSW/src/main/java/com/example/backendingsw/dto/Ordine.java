package com.example.backendingsw.dto;

public class Ordine {
	int iDordine;
	float costo;
	int iDtavolo;
	
	public Ordine(int iDordine, float costo, int iDtavolo) {
		super();
		this.iDordine = iDordine;
		this.costo = costo;
		this.iDtavolo = iDtavolo;
	}

	@Override
	public String toString() {
		return  "\"" + iDordine +
				"\", \"" + costo +
				"\", \"" + iDtavolo +"\"";
	}

	public int getiDordine() {
		return iDordine;
	}
	public void setiDordine(int iDordine) {
		this.iDordine = iDordine;
	}
	public float getCosto() {
		return costo;
	}
	public void setCosto(float costo) {
		this.costo = costo;
	}
	public int getiDtavolo() {
		return iDtavolo;
	}
	public void setiDtavolo(int iDtavolo) {
		this.iDtavolo = iDtavolo;
	}
}
