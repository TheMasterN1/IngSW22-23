package com.example.backendingsw.dao;

import java.sql.ResultSet;

import com.example.backendingsw.dto.Utente;

public interface UtenteDAOInterface {
	ResultSet InserisciUtente(Utente utente) throws Exception;
	int UpdateUtente(Utente utente) throws Exception;
	Utente autentificazioneUtente(String nome, String pass) throws Exception;
	ResultSet IDListaUtenti()throws Exception;
}
