package com.example.backendingsw.dao;

import com.example.backendingsw.dto.Ingrediente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class IngredienteDAO implements IngredienteDAOInterface {

	@Override
	public ResultSet InserisciIngrediente(Ingrediente ingrediente) throws Exception {
		Connection con = null;
		String sql = "Insert into ingrediente VALUES(?,?,?)";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, ingrediente.getNome());
		p1.setInt(2, 0);
		p1.setInt(3, ingrediente.getQuantita());
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet RimuoviIngrediente(int id) throws Exception {
		Connection con = null;
		String sql = "delete from ingrediente where ingrediente.ingredienteId=? ";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, id);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet UpdateIngredienti(Ingrediente ingrediente, int id) throws Exception {
		Connection con = null;
		String sql = "Update ingrediente set quantita=? , nome = ? where ingredienteId= ?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, ingrediente.getQuantita());
		p1.setString(2, ingrediente.getNome());
		p1.setInt(3, id);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ArrayList<Ingrediente> ListaIngredienti() throws Exception {
		Connection con = null;
		String sql = "select * from ingrediente";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		ArrayList<Ingrediente> ingredienti = new ArrayList<Ingrediente>();
		while(rs1.next()) {
			ingredienti.add(new Ingrediente(rs1.getString(1), rs1.getInt(2), rs1.getInt(3)));
		}
		return ingredienti;
	}

	@Override
	public ResultSet ListaIngredientiSpecifica(String nome) throws Exception {
		Connection con = null;
		String sql = "select * from ingrediente where nome=?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, nome);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}
	
	@Override
	public Ingrediente ListaIngredientiSpecificaID(String id) throws Exception {
		Connection con = null;
		String sql = "select * from ingrediente where ingredienteId=?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setString(1, id);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		rs1.next();
		return new Ingrediente(rs1.getString(1), rs1.getInt(2), rs1.getInt(3));
	}
}
