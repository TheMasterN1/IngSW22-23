package com.example.backendingsw.dao;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.example.backendingsw.dto.Ordinazione;
import com.example.backendingsw.dto.Ordine;

public interface OrdiniDAOInterface {
    ResultSet InserisciOrdinazione(Ordinazione ordinazione) throws Exception;

    ResultSet RimuoviOrdine(int id) throws Exception;

	ResultSet UpdateOrdini(int costOrdine, int costoNuovo) throws Exception;

	ArrayList<Ordine> ListaOrdini() throws Exception;

	ResultSet ListaOrdiniSpecifica(int id, int comboBoxChoice) throws Exception;

	ResultSet IdProdottiOrdine() throws Exception;

	int CountOrdinazioniTavolo(int idTavolo) throws Exception;

	ResultSet ListaOrdiniPerTavolo(int tavoloID) throws Exception;
}
