package com.example.backendingsw.requester;

import com.example.backendingsw.dao.IngredienteDAO;
import com.example.backendingsw.dao.ProdottoDAO;
import com.example.backendingsw.dto.Ingrediente;
import com.example.backendingsw.dto.ProdottoIta;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController()
@RequestMapping("/prodotti")
public class RequesterProdotti {//TODO cambiare in base al nome tutti i metodi
    ProdottoDAO dao = new ProdottoDAO();

    @GetMapping("/")
    public String getProdotti() throws Exception {
        return "{\"values\":"+dao.ListaProdotti()+ "}";
    }

    @GetMapping("/{id}")
    public ProdottoIta getProdottoSpecifico(@PathVariable("id") String id) throws Exception {
        return dao.ListaProdotti_specifica(id);
    }

    @GetMapping("/{id}/{ricetta}")
    public String getRicetta(@PathVariable("id") String id) throws Exception {
        return "{\"values\":"+dao.getRicetta(id)+ "}";
    }

    @PostMapping("/")
    public void addProdotto(@RequestBody ProdottoIta prodottoIta) throws Exception {
        dao.InserisciProdotto(prodottoIta);
    }

    @PostMapping("/{prod}/{id}/{qt}")
    public void addRicetta(@PathVariable("prod") String prod, @PathVariable("id") String id, @PathVariable("qt") int qt) throws Exception {
        dao.InserisciRicetta(prod, id, qt);
    }


    @DeleteMapping("/{id}")
    public void deleteProdotto(@PathVariable int id) throws Exception {
        dao.RimuoviProdotto(id);
    }
}
