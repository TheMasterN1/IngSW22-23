package com.example.backendingsw.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class SalaDAO implements SalaDAOInterface {

	@Override
	public ResultSet RimuoviSala(int id) throws Exception {
		Connection con = null;
		String sql = "delete from sala where sala.salaID=? ";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, id);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet ListaSala(int salaID) throws Exception {
		Connection con = null;
		String sql = "select * from sala where sala.salaID=?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, salaID);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ArrayList<Integer> GetAllSale() throws Exception {
		Connection con = null;
		String sql = "select salaID from sala";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		ArrayList<Integer> sale = new ArrayList<Integer>();
			while(rs1.next())
				sale.add(rs1.getInt(1));
		return sale;
	}
}
