package com.example.backendingsw.dto;

import com.example.backendingsw.enumerations.TipoProdottoIta;

public class ProdottoIta extends Prodotto {
    TipoProdottoIta categoria;

    public ProdottoIta(float costo, String name, String allergeni, String descrizione, int prodottoID, TipoProdottoIta categoria){
        super(costo, name, allergeni, descrizione, prodottoID);
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return  super.toString() +
                ", \"" + categoria + "\"";
    }

    public ProdottoIta() {}

	public TipoProdottoIta getCategoria() {
        return categoria;
    }

    public void setCategoria(TipoProdottoIta categoria) {
        this.categoria = categoria;
    }
}
