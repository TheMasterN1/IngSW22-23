package com.example.backendingsw.dto;

import com.example.backendingsw.enumerations.TipoProdottoEng;
import com.example.backendingsw.enumerations.TipoProdottoIta;

public class ProdottoEng extends Prodotto {
    TipoProdottoEng categoria;

    public ProdottoEng(float costo, String name, String allergeni, String descrizione, int prodottoID, TipoProdottoIta categoria){
        super(costo, name, allergeni, descrizione, prodottoID);
        this.categoria = TipoProdottoEng.values()[categoria.ordinal()];
    }
    
    public TipoProdottoEng getCategoria() {
        return categoria;
    }

    public void setCategoria(TipoProdottoEng categoria) {
        this.categoria = categoria;
    }
}

