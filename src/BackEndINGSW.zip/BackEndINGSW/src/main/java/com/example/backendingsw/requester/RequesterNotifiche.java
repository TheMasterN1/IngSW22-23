package com.example.backendingsw.requester;

import com.example.backendingsw.dao.IngredienteDAO;
import com.example.backendingsw.dao.NotificheDAO;
import com.example.backendingsw.dto.Ingrediente;
import com.example.backendingsw.dto.Notifiche;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController()
@RequestMapping("/notifiche")
public class RequesterNotifiche {//TODO cambiare in base al nome tutti i metodi
    NotificheDAO dao = new NotificheDAO();

    @GetMapping("/{id}")
    public String getCheckVisualizzare(@PathVariable("id") int id) throws Exception {
        return "{\"count\":\""+dao.CheckDaVisualizzare(id)+"\"}";
    }

    @GetMapping("/{id}/{visualizzato}")
    public String getNotifiche(@PathVariable("id") int id, @PathVariable("visualizzato") String visualizzato) throws Exception {
        return "{\"values\":"+(visualizzato.equals("Y") ? dao.ListaNotificheVisualizzate(id) : dao.ListaMessaggiSpecifici(id) )+ "}";
    }

    @PostMapping("/")
    public void addNotifiche(@RequestBody Notifiche notifiche) throws Exception {
        dao.InserisciMessaggio(notifiche);
    }

    @PutMapping("/{id1}/{id2}")
    public void updateVisualizzato(@PathVariable("id1") int idutente, @PathVariable("id2") int idnotifica) throws Exception {
        dao.UpdateVisualizzazione(idutente, idnotifica);
    }
}
