package com.example.backendingsw.dao;

import java.sql.ResultSet;
import java.util.ArrayList;

public interface SalaDAOInterface {

	ResultSet RimuoviSala(int id) throws Exception;

	ResultSet ListaSala(int salaID) throws Exception;

	ArrayList<Integer> GetAllSale() throws Exception;
}
