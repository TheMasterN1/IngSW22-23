package com.example.backendingsw.requester;

import com.example.backendingsw.dao.OrdiniDAO;
import com.example.backendingsw.dto.Ordinazione;
import org.springframework.web.bind.annotation.*;

@RestController()
@RequestMapping("/ordini")
public class RequesterOrdini {//TODO cambiare in base al nome tutti i metodi
          OrdiniDAO dao = new OrdiniDAO();

    @GetMapping("/{id}")
    public String getOrdiniSpecifici(@PathVariable("id") int id) throws Exception {
        return "{\"count\":\""+dao.CountOrdinazioniTavolo(id)+"\"}";
    }

    @GetMapping("/")
    public String getOrdini() throws Exception {
        return "{\"values\":"+dao.ListaOrdini()+ "}";
    }

    @PostMapping("/")
    public void addOrdinazione(@RequestBody Ordinazione ordinazione) throws Exception {
        dao.InserisciOrdinazione(ordinazione);
    }

    @DeleteMapping("/{id}")
    public void deleteOrdine(@PathVariable String id) throws Exception {
        dao.RimuoviOrdinazioni(id);
    }
}
