package com.example.backendingsw.dao;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.example.backendingsw.dto.ProdottoIta;

public interface ProdottoDAOInterface {
	ResultSet RimuoviProdotto(int id) throws Exception;

	ResultSet UpdateProdotti(String nome, int quantita) throws Exception;

	ArrayList<ProdottoIta> ListaProdotti() throws Exception;

	ResultSet InserisciRicetta(String prodotto, String ingrediente, Integer quantita) throws Exception;

	ResultSet ListaProdottiPerNome(String nome) throws Exception;

	ProdottoIta ListaProdotti_specifica(String nome) throws Exception;

	ResultSet InserisciProdotto(ProdottoIta prodottoIta) throws Exception;
}
