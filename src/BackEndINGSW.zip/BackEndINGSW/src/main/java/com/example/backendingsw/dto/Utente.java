package com.example.backendingsw.dto;

import java.util.Objects;

public class Utente {
    String username;
    String password;
    int id;
    String ruolo;
    Integer idSala;
    boolean isNew = false;

    public Utente(String username, String password, int id, String ruolo, Integer idSala){
        this.username = username;
        this.password = password;
        this.id = id;
        this.ruolo = ruolo;
        this.idSala = idSala;
    }

    public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRuolo() {
        return ruolo;
    }

    public void setRuolo(String ruolo) {
        this.ruolo = ruolo;
    }

    public int getIdSala() {
        return idSala;
    }

    public void setIdSala(int idSala) {
        this.idSala = idSala;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Utente utente = (Utente) o;
        return id == utente.id && isNew == utente.isNew && Objects.equals(username, utente.username) && Objects.equals(password, utente.password) && Objects.equals(ruolo, utente.ruolo) && Objects.equals(idSala, utente.idSala);
    }

    @Override
    public int hashCode() {
        return Objects.hash(username, password, id, ruolo, idSala, isNew);
    }
}
