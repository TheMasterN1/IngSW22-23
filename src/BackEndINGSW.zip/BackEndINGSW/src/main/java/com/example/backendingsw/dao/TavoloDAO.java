package com.example.backendingsw.dao;

import com.example.backendingsw.dto.Tavolo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class TavoloDAO implements TavoloDAOInterface {
	@Override
	public ResultSet InserisciTavolo(int tavoloID, int numeroPosti, int salaID) throws Exception {
		Connection con = null;
		String sql = "Insert into tavolo VALUES(?,?,?)";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, tavoloID);
		p1.setInt(2, numeroPosti);
		p1.setInt(3, salaID);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ResultSet RimuoviTavolo(int id) throws Exception {
		Connection con = null;
		String sql = "delete from tavolo where tavolo.tavoloID=? ";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, id);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		return rs1;
	}

	@Override
	public ArrayList<Tavolo> ListaTavolo(int salaID) throws Exception {
		Connection con = null;
		String sql = "select * from tavolo where tavolo.salaID=?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, salaID);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		ArrayList<Tavolo> tavoli = new ArrayList<>();
		while(rs1.next())
			tavoli.add(new Tavolo(rs1.getInt(1), rs1.getInt(2), rs1.getInt(3)));
		return tavoli;
	}

	@Override
	public ArrayList<Tavolo> ListaTavoliSingoli(int salaID) throws Exception {
		Connection con = null;
		String sql = "select tavoloID from tavolo where tavolo.salaID=?";
		con = dbConnection.getConnection();
		PreparedStatement p1 = con.prepareStatement(sql);
		p1.setInt(1, salaID);
		ResultSet rs1 = p1.executeQuery();
		con.close();
		ArrayList<Tavolo> tavoli = new ArrayList<>();
		while(rs1.next())
			tavoli.add(new Tavolo(rs1.getInt(1), rs1.getInt(2), rs1.getInt(3)));
		return tavoli;
	}



}
