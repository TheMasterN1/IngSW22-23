package com.example.backendingsw.dao;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.example.backendingsw.dto.Ingrediente;

public interface IngredienteDAOInterface {
	ResultSet InserisciIngrediente(Ingrediente ingrediente) throws Exception;

	ResultSet RimuoviIngrediente(int nome) throws Exception;

	ResultSet UpdateIngredienti(Ingrediente ingrediente, int id) throws Exception;

	ArrayList<Ingrediente> ListaIngredienti() throws Exception;

	ResultSet ListaIngredientiSpecifica(String prodotto) throws Exception;

	Ingrediente ListaIngredientiSpecificaID(String id) throws Exception;
}
